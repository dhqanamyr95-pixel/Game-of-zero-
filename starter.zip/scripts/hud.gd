extends Control

# Touch controls drawn entirely in code (no emoji, no images).
# mode 0/1 (first / third person): COD-style layout.
#   left side  = floating joystick (push to the edge to sprint)
#   right side = drag to look, buttons: FIRE, AIM, JUMP, CROUCH, TORCH, CAMERA
# mode 2 (strategy view): Clash-style layout.
#   one finger drag = pan, two fingers = pinch zoom, tap = walk there

signal jump_pressed
signal crouch_pressed
signal attack_pressed
signal aim_pressed
signal interact_pressed
signal build_pressed
signal camera_pressed
signal menu_pressed
signal recenter_pressed
signal map_tap(pos: Vector2)

const JOY_R := 120.0
const I18n = preload("res://scripts/i18n.gd")

var mode := 1
var move := Vector2.ZERO
var sprint := false
var crouching := false
var aiming := false
var cam_name := ""
var stamina := 1.0
var time_text := ""
var season_text := ""
var health := 1.0
var hunger := 1.0
var thirst := 1.0
var prompt_text := ""
var message := ""
var message_t := 0.0
var ui_scale := 1.0
var look_total := 0.0
var tutorial_text := ""
var message_col := Color(0.9, 0.2, 0.15)
var message_size := 56
var wood := 0
var items := {}
var stone := 0
var saved_t := 0.0

var look_accum := Vector2.ZERO
var pan_accum := Vector2.ZERO
var zoom_accum := 0.0

var joy_id := -1
var joy_origin := Vector2.ZERO
var joy_pos := Vector2.ZERO
var look_id := -1
var touches := {}
var held := {}
var pinch_last := -1.0


func _ready() -> void:
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    _fit()
    get_viewport().size_changed.connect(_fit)


func _fit() -> void:
    position = Vector2.ZERO
    size = get_viewport().get_visible_rect().size / ui_scale


func set_mode(m: int) -> void:
    mode = m
    joy_id = -1
    look_id = -1
    move = Vector2.ZERO
    sprint = false
    touches.clear()
    held.clear()
    pinch_last = -1.0
    queue_redraw()


func consume_look() -> Vector2:
    var l := look_accum
    look_accum = Vector2.ZERO
    return l


func consume_pan() -> Vector2:
    var l := pan_accum
    pan_accum = Vector2.ZERO
    return l


func consume_zoom() -> float:
    var z := zoom_accum
    zoom_accum = 0.0
    return z


func _process(delta: float) -> void:
    if message_t > 0.0:
        message_t -= delta
    if saved_t > 0.0:
        saved_t -= delta
    if visible:
        queue_redraw()


# ---------- buttons ----------

func _buttons() -> Array:
    var w := size.x
    var h := size.y
    var arr: Array = []
    arr.append({"id": "camera", "pos": Vector2(w - 80.0, 76.0), "r": 44.0})
    arr.append({"id": "menu", "pos": Vector2(w * 0.5, 40.0), "r": 30.0})
    if mode == 2:
        arr.append({"id": "recenter", "pos": Vector2(w - 80.0, 190.0), "r": 44.0})
    else:
        arr.append({"id": "attack", "pos": Vector2(w - 250.0, h - 250.0), "r": 70.0})
        arr.append({"id": "jump", "pos": Vector2(w - 110.0, h - 140.0), "r": 62.0})
        arr.append({"id": "crouch", "pos": Vector2(w - 260.0, h - 95.0), "r": 48.0})
        arr.append({"id": "aim", "pos": Vector2(w - 110.0, h - 290.0), "r": 48.0})
        arr.append({"id": "interact", "pos": Vector2(w - 390.0, h - 170.0), "r": 46.0})
        arr.append({"id": "build", "pos": Vector2(w - 400.0, h - 300.0), "r": 44.0})
    return arr


func _hit_button(p: Vector2) -> String:
    for b in _buttons():
        if p.distance_to(b["pos"]) <= float(b["r"]) * 1.12:
            return String(b["id"])
    return ""


func _is_held(id: String) -> bool:
    return held.values().has(id)


func _press(id: String) -> void:
    match id:
        "jump":
            jump_pressed.emit()
        "crouch":
            crouch_pressed.emit()
        "attack":
            attack_pressed.emit()
        "aim":
            aim_pressed.emit()
        "interact":
            interact_pressed.emit()
        "build":
            build_pressed.emit()
        "camera":
            camera_pressed.emit()
        "menu":
            menu_pressed.emit()
        "recenter":
            recenter_pressed.emit()


# ---------- input ----------

func _input(event: InputEvent) -> void:
    if not visible:
        return
    if event is InputEventScreenTouch:
        _on_touch(make_input_local(event) as InputEventScreenTouch)
    elif event is InputEventScreenDrag:
        _on_drag(make_input_local(event) as InputEventScreenDrag)


func _on_touch(event: InputEventScreenTouch) -> void:
    var p := event.position
    if event.pressed:
        var bid := _hit_button(p)
        if bid != "":
            held[event.index] = bid
            _press(bid)
            return
        touches[event.index] = {"pos": p, "t0": Time.get_ticks_msec(), "moved": 0.0}
        if mode != 2:
            if p.x < size.x * 0.42 and joy_id == -1:
                joy_id = event.index
                joy_origin = p
                joy_pos = p
            elif look_id == -1:
                look_id = event.index
    else:
        if held.has(event.index):
            held.erase(event.index)
        elif touches.has(event.index):
            var t = touches[event.index]
            var quick: bool = Time.get_ticks_msec() - int(t["t0"]) < 350
            if mode == 2 and float(t["moved"]) < 14.0 and quick and touches.size() == 1:
                map_tap.emit(p)
        touches.erase(event.index)
        if event.index == joy_id:
            joy_id = -1
            move = Vector2.ZERO
            sprint = false
        if event.index == look_id:
            look_id = -1
        if touches.size() < 2:
            pinch_last = -1.0
    queue_redraw()


func _on_drag(event: InputEventScreenDrag) -> void:
    if touches.has(event.index):
        var t = touches[event.index]
        t["pos"] = event.position
        t["moved"] = float(t["moved"]) + event.relative.length()
    if mode == 2:
        if touches.size() == 1:
            pan_accum += event.relative
        elif touches.size() >= 2:
            var keys := touches.keys()
            var a: Vector2 = touches[keys[0]]["pos"]
            var b: Vector2 = touches[keys[1]]["pos"]
            var d := a.distance_to(b)
            if pinch_last > 0.0:
                zoom_accum += pinch_last - d
            pinch_last = d
    else:
        if event.index == joy_id:
            var off := event.position - joy_origin
            if off.length() > JOY_R * 1.4:
                joy_origin = event.position - off.normalized() * JOY_R * 1.4
                off = event.position - joy_origin
            joy_pos = event.position
            move = (off / JOY_R).limit_length(1.0)
            if move.length() < 0.10:
                move = Vector2.ZERO
            sprint = move.length() > 0.92
        elif event.index == look_id:
            look_accum += event.relative
            look_total += event.relative.length()
    queue_redraw()


# ---------- drawing ----------

func _draw() -> void:
    var font := ThemeDB.fallback_font
    draw_string(font, Vector2(20, 34), "%d FPS    %s" % [Engine.get_frames_per_second(), cam_name], HORIZONTAL_ALIGNMENT_LEFT, -1, 20, Color(1, 1, 1, 0.85))
    draw_string(font, Vector2(20, 60), time_text, HORIZONTAL_ALIGNMENT_LEFT, -1, 20, Color(1.0, 0.9, 0.6, 0.85))
    draw_string(font, Vector2(210, 60), season_text, HORIZONTAL_ALIGNMENT_LEFT, -1, 20, Color(0.8, 1.0, 0.8, 0.85))
    if mode != 2 and stamina < 0.995:
        draw_rect(Rect2(20.0, size.y - 34.0, 220.0, 8.0), Color(0, 0, 0, 0.35), true)
        draw_rect(Rect2(20.0, size.y - 34.0, 220.0 * stamina, 8.0), Color(0.95, 0.8, 0.35, 0.85), true)
    _draw_stat(86.0, health, Color(0.85, 0.2, 0.2), "health")
    _draw_stat(106.0, hunger, Color(0.9, 0.6, 0.15), "hunger")
    _draw_stat(126.0, thirst, Color(0.25, 0.6, 0.95), "thirst")
    if prompt_text != "":
        draw_string(font, Vector2(0.0, size.y - 120.0), "[E]  " + prompt_text, HORIZONTAL_ALIGNMENT_CENTER, size.x, 26, Color(1, 1, 1, 0.95))
    if tutorial_text != "":
        var tw := size.x * 0.62
        draw_rect(Rect2((size.x - tw) * 0.5, 84.0, tw, 54.0), Color(0, 0, 0, 0.55), true)
        draw_string(font, Vector2((size.x - tw) * 0.5, 120.0), tutorial_text, HORIZONTAL_ALIGNMENT_CENTER, tw, 24, Color(1.0, 0.92, 0.65))
    if message_t > 0.0:
        draw_string(font, Vector2(0.0, size.y * 0.42), message, HORIZONTAL_ALIGNMENT_CENTER, size.x, message_size, Color(message_col.r, message_col.g, message_col.b, clampf(message_t, 0.0, 1.0)))
    var ix := 20.0
    var iy := 150.0
    for id in ["wood", "stone", "fiber", "sapling", "arrow"]:
        var cnt := int(items.get(id, 0))
        if cnt <= 0 and id != "wood" and id != "stone":
            continue
        _draw_item_icon(id, Vector2(ix + 8.0, iy + 4.0))
        draw_string(font, Vector2(ix + 28.0, iy + 9.0), str(cnt), HORIZONTAL_ALIGNMENT_LEFT, -1, 20, Color(1, 1, 1, 0.9))
        ix += 76.0
    if saved_t > 0.0:
        draw_string(font, Vector2(size.x - 330.0, 34.0), I18n.t("saved"), HORIZONTAL_ALIGNMENT_RIGHT, 220.0, 20, Color(0.7, 1.0, 0.7, clampf(saved_t, 0.0, 1.0)))

    if mode != 2:
        if joy_id != -1:
            draw_circle(joy_origin, JOY_R, Color(1, 1, 1, 0.07))
            draw_arc(joy_origin, JOY_R, 0.0, TAU, 48, Color(1, 1, 1, 0.35), 3.0)
            var knob := joy_origin + (joy_pos - joy_origin).limit_length(JOY_R)
            draw_circle(knob, 46.0, Color(1, 1, 1, 0.26))
            draw_arc(knob, 46.0, 0.0, TAU, 32, Color(1, 1, 1, 0.65), 3.0)
            if sprint:
                var top := joy_origin + Vector2(0, -JOY_R - 34.0)
                for i in 3:
                    var y := top.y - i * 16.0
                    draw_polyline(PackedVector2Array([Vector2(top.x - 16.0, y + 8.0), Vector2(top.x, y), Vector2(top.x + 16.0, y + 8.0)]), Color(1.0, 0.85, 0.4, 0.9), 4.0)
        else:
            draw_arc(Vector2(190.0, size.y - 170.0), 80.0, 0.0, TAU, 40, Color(1, 1, 1, 0.14), 3.0)
    else:
        draw_string(font, Vector2(0.0, size.y - 22.0), I18n.t("hint_strategy"), HORIZONTAL_ALIGNMENT_CENTER, size.x, 20, Color(1, 1, 1, 0.7))

    for b in _buttons():
        _draw_button(b)


func _draw_button(b: Dictionary) -> void:
    var c: Vector2 = b["pos"]
    var r: float = b["r"]
    var id: String = b["id"]
    var active := _is_held(id) or (id == "crouch" and crouching) or (id == "aim" and aiming)
    var fill := Color(0.0, 0.0, 0.0, 0.34)
    var ring := Color(1, 1, 1, 0.55)
    if id == "attack":
        fill = Color(0.70, 0.12, 0.08, 0.42)
        ring = Color(1.0, 0.55, 0.45, 0.9)
    if active:
        fill = Color(1.0, 1.0, 1.0, 0.30)
        ring = Color(1.0, 0.85, 0.4, 1.0)
    draw_circle(c, r, fill)
    draw_arc(c, r, 0.0, TAU, 48, ring, 3.5)
    _draw_icon(id, c, r * 0.5, ring)


func _draw_icon(id: String, c: Vector2, s: float, col: Color) -> void:
    var w := 5.0
    match id:
        "jump":
            draw_polyline(PackedVector2Array([c + Vector2(-s, s * 0.25), c + Vector2(0, -s * 0.55), c + Vector2(s, s * 0.25)]), col, w)
            draw_polyline(PackedVector2Array([c + Vector2(-s, s * 0.95), c + Vector2(0, s * 0.15), c + Vector2(s, s * 0.95)]), col, w)
        "crouch":
            draw_polyline(PackedVector2Array([c + Vector2(-s, -s * 0.25), c + Vector2(0, s * 0.55), c + Vector2(s, -s * 0.25)]), col, w)
            draw_line(c + Vector2(-s, s * 0.95), c + Vector2(s, s * 0.95), col, w)
        "attack":
            draw_line(c + Vector2(-s, s), c + Vector2(s * 0.6, -s * 0.6), col, 9.0)
            draw_circle(c + Vector2(s * 0.75, -s * 0.75), s * 0.42, col)
        "aim":
            draw_arc(c, s * 0.7, 0.0, TAU, 28, col, w)
            draw_line(c + Vector2(-s * 1.15, 0), c + Vector2(-s * 0.4, 0), col, w)
            draw_line(c + Vector2(s * 0.4, 0), c + Vector2(s * 1.15, 0), col, w)
            draw_line(c + Vector2(0, -s * 1.15), c + Vector2(0, -s * 0.4), col, w)
            draw_line(c + Vector2(0, s * 0.4), c + Vector2(0, s * 1.15), col, w)
        "interact":
            draw_string(ThemeDB.fallback_font, c + Vector2(-s * 0.45, s * 0.55), "E", HORIZONTAL_ALIGNMENT_LEFT, -1, int(s * 1.7), col)
        "build":
            draw_line(c + Vector2(-s * 0.8, s * 0.95), c + Vector2(s * 0.45, -s * 0.45), col, 8.0)
            draw_colored_polygon(PackedVector2Array([c + Vector2(s * 0.05, -s * 1.0), c + Vector2(s * 1.0, -s * 0.2), c + Vector2(s * 0.7, s * 0.15), c + Vector2(-s * 0.25, -s * 0.65)]), col)
        "camera":
            draw_rect(Rect2(c + Vector2(-s, -s * 0.55), Vector2(s * 2.0, s * 1.3)), col, false, w)
            draw_rect(Rect2(c + Vector2(-s * 0.35, -s * 0.9), Vector2(s * 0.7, s * 0.35)), col, true)
            draw_arc(c + Vector2(0, s * 0.1), s * 0.38, 0.0, TAU, 20, col, w)
        "recenter":
            draw_arc(c, s * 0.75, 0.0, TAU, 28, col, w)
            draw_circle(c, 4.0, col)
            draw_line(c + Vector2(-s * 1.15, 0), c + Vector2(-s * 0.9, 0), col, w)
            draw_line(c + Vector2(s * 0.9, 0), c + Vector2(s * 1.15, 0), col, w)
            draw_line(c + Vector2(0, -s * 1.15), c + Vector2(0, -s * 0.9), col, w)
            draw_line(c + Vector2(0, s * 0.9), c + Vector2(0, s * 1.15), col, w)
        "menu":
            draw_rect(Rect2(c + Vector2(-s * 0.55, -s * 0.7), Vector2(s * 0.35, s * 1.4)), col, true)
            draw_rect(Rect2(c + Vector2(s * 0.2, -s * 0.7), Vector2(s * 0.35, s * 1.4)), col, true)


func _draw_stat(y: float, frac: float, col: Color, kind: String) -> void:
    var x := 20.0
    var c := Vector2(x + 8.0, y + 4.0)
    match kind:
        "health":
            draw_line(c + Vector2(-6, 0), c + Vector2(6, 0), col, 3.0)
            draw_line(c + Vector2(0, -6), c + Vector2(0, 6), col, 3.0)
        "hunger":
            draw_circle(c + Vector2(0, 1), 6.0, col)
            draw_line(c + Vector2(0, -5), c + Vector2(3, -9), Color(0.4, 0.8, 0.3), 2.0)
        "thirst":
            draw_colored_polygon(PackedVector2Array([c + Vector2(0, -8), c + Vector2(-5, 2), c + Vector2(0, 7), c + Vector2(5, 2)]), col)
    draw_rect(Rect2(x + 24.0, y, 150.0, 8.0), Color(0, 0, 0, 0.35), true)
    var f := clampf(frac, 0.0, 1.0)
    var bar_col := col
    if f < 0.25:
        bar_col = Color(1.0, 0.3, 0.2)
    draw_rect(Rect2(x + 24.0, y, 150.0 * f, 8.0), bar_col, true)


func _draw_item_icon(id: String, c: Vector2) -> void:
    match id:
        "wood":
            draw_line(c + Vector2(-8, 7), c + Vector2(8, -6), Color(0.62, 0.42, 0.24), 5.0)
        "stone":
            draw_circle(c, 8.0, Color(0.62, 0.62, 0.64))
        "fiber":
            draw_line(c + Vector2(0, 8), c + Vector2(-6, -8), Color(0.55, 0.78, 0.3), 3.0)
            draw_line(c + Vector2(0, 8), c + Vector2(0, -9), Color(0.55, 0.78, 0.3), 3.0)
            draw_line(c + Vector2(0, 8), c + Vector2(6, -8), Color(0.55, 0.78, 0.3), 3.0)
        "sapling":
            draw_line(c + Vector2(0, 9), c + Vector2(0, -1), Color(0.5, 0.35, 0.2), 3.0)
            draw_circle(c + Vector2(0, -5), 6.0, Color(0.35, 0.75, 0.3))
        "arrow":
            draw_line(c + Vector2(-9, 6), c + Vector2(8, -7), Color(0.85, 0.8, 0.7), 3.0)
            draw_colored_polygon(PackedVector2Array([c + Vector2(10, -9), c + Vector2(3, -6), c + Vector2(7, -2)]), Color(0.75, 0.75, 0.78))
