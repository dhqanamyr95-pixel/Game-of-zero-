extends "res://scripts/humanoid.gd"

# A more human character built on the same skeleton (so the walk, run, attack and
# held-tool code keeps working): shaped torso with chest and waist, muscular arms
# and legs, hands with fingers, a real face (eyes, brows, nose, ears), 6 hair styles,
# 4 beards, 6 skin tones, and clothing pieces (see outfits.gd) that can be swapped.

const Meshes = preload("res://scripts/meshes.gd")
const Outfits = preload("res://scripts/outfits.gd")

const TORSO := [[0.0, 0.19, 0.13], [0.20, 0.16, 0.11], [0.38, 0.205, 0.135], [0.50, 0.225, 0.14], [0.585, 0.185, 0.12]]

var look := {"skin": 1, "hair": 3, "hair_color": 2, "beard": 2}
var outfit := {}
var vmat: StandardMaterial3D
var body_nodes: Array = []
var outfit_nodes := {}


func build() -> void:
    super.build()
    _strip_old()
    vmat = StandardMaterial3D.new()
    vmat.vertex_color_use_as_albedo = true
    vmat.roughness = 0.9
    vmat.cull_mode = BaseMaterial3D.CULL_DISABLED
    Settings.tune(vmat)
    _build_body()


# Removes the simple blocky body of the base class (the pivots and held tools stay).
func _strip_old() -> void:
    var pivots: Array = [hips, spine, head, arm_l, arm_r, elbow_l, elbow_r, hand_l, hand_r, leg_l, leg_r, knee_l, knee_r]
    for pv in pivots:
        var node: Node3D = pv
        for ch in node.get_children():
            if ch is MeshInstance3D:
                node.remove_child(ch)
                ch.queue_free()


# ---------- geometry helpers ----------

func loft(b: Meshes.Builder, rings: Array, segs: int, c0: Color, c1: Color, ox: float, oz: float) -> void:
    var count := rings.size()
    for r in range(count - 1):
        var a: Array = rings[r]
        var n: Array = rings[r + 1]
        var ya: float = a[0]
        var yn: float = n[0]
        var rxa: float = a[1]
        var rza: float = a[2]
        var rxn: float = n[1]
        var rzn: float = n[2]
        var center := Vector3(ox, (ya + yn) * 0.5, oz)
        var ca := c0.lerp(c1, float(r) / float(count - 1))
        var cn := c0.lerp(c1, float(r + 1) / float(count - 1))
        for i in segs:
            var t0 := TAU * float(i) / float(segs)
            var t1 := TAU * float(i + 1) / float(segs)
            var p00 := Vector3(ox + cos(t0) * rxa, ya, oz + sin(t0) * rza)
            var p01 := Vector3(ox + cos(t1) * rxa, ya, oz + sin(t1) * rza)
            var p10 := Vector3(ox + cos(t0) * rxn, yn, oz + sin(t0) * rzn)
            var p11 := Vector3(ox + cos(t1) * rxn, yn, oz + sin(t1) * rzn)
            b.tri(p00, p01, p10, ca, ca, cn, center)
            b.tri(p01, p11, p10, ca, cn, cn, center)


func box(b: Meshes.Builder, c: Vector3, s: Vector3, col: Color) -> void:
    var h := s * 0.5
    var p: Array = []
    for i in 8:
        var sx := h.x
        var sy := h.y
        var sz := h.z
        if (i & 1) != 0:
            sx = -h.x
        if (i & 2) != 0:
            sy = -h.y
        if (i & 4) != 0:
            sz = -h.z
        p.append(c + Vector3(sx, sy, sz))
    var faces := [[0, 1, 3, 2], [4, 6, 7, 5], [0, 2, 6, 4], [1, 5, 7, 3], [0, 4, 5, 1], [2, 3, 7, 6]]
    for f in faces:
        var a: Vector3 = p[f[0]]
        var bb: Vector3 = p[f[1]]
        var cc: Vector3 = p[f[2]]
        var dd: Vector3 = p[f[3]]
        b.tri(a, bb, cc, col, col, col, c)
        b.tri(a, cc, dd, col, col, col, c)


func _part(parent: Node3D, b: Meshes.Builder, list: Array) -> void:
    var mi := MeshInstance3D.new()
    mi.mesh = b.to_mesh()
    mi.material_override = vmat
    parent.add_child(mi)
    list.append(mi)


func _piece(cat: String, parent: Node3D, b: Meshes.Builder) -> void:
    if not outfit_nodes.has(cat):
        outfit_nodes[cat] = []
    var arr: Array = outfit_nodes[cat]
    _part(parent, b, arr)


# ---------- the body ----------

func _build_body() -> void:
    for n in body_nodes:
        if is_instance_valid(n):
            (n as Node).queue_free()
    body_nodes.clear()
    var skin_i := clampi(int(look["skin"]), 0, Outfits.SKINS.size() - 1)
    var skin: Color = Outfits.SKINS[skin_i]
    var rng := RandomNumberGenerator.new()
    rng.seed = 4242

    var tb := Meshes.Builder.new()
    loft(tb, [[-0.12, 0.165, 0.105], [0.02, 0.17, 0.11], [0.20, 0.145, 0.095], [0.38, 0.185, 0.115], [0.50, 0.205, 0.12], [0.58, 0.17, 0.10], [0.62, 0.065, 0.065]], 10, skin, skin, 0.0, 0.0)
    Meshes.frustum(tb, Vector3(0.0, 0.58, 0.0), Vector3(0.0, 0.72, 0.0), 0.058, 0.05, 8, skin, skin, false)
    _part(spine, tb, body_nodes)

    var sides: Array = [-1.0, 1.0]
    for sv in sides:
        var side: float = sv
        var arm: Node3D = arm_l
        var elbow: Node3D = elbow_l
        var hand: Node3D = hand_l
        var leg: Node3D = leg_l
        var knee: Node3D = knee_l
        if side > 0.0:
            arm = arm_r
            elbow = elbow_r
            hand = hand_r
            leg = leg_r
            knee = knee_r
        var ab := Meshes.Builder.new()
        loft(ab, [[0.02, 0.062, 0.062], [-0.10, 0.058, 0.058], [-0.30, 0.044, 0.044]], 8, skin, skin, 0.0, 0.0)
        _part(arm, ab, body_nodes)
        var fb := Meshes.Builder.new()
        loft(fb, [[0.0, 0.046, 0.046], [-0.12, 0.05, 0.05], [-0.28, 0.032, 0.032]], 8, skin, skin, 0.0, 0.0)
        _part(elbow, fb, body_nodes)
        var hb := Meshes.Builder.new()
        box(hb, Vector3(0.0, -0.05, 0.0), Vector3(0.08, 0.09, 0.035), skin)
        for k in 4:
            var fx := -0.027 + 0.018 * float(k)
            box(hb, Vector3(fx, -0.115, 0.0), Vector3(0.016, 0.06, 0.02), skin)
        box(hb, Vector3(-side * 0.05, -0.06, -0.012), Vector3(0.022, 0.06, 0.022), skin)
        _part(hand, hb, body_nodes)
        var lb := Meshes.Builder.new()
        loft(lb, [[0.04, 0.09, 0.09], [-0.12, 0.085, 0.085], [-0.44, 0.06, 0.06]], 8, skin, skin, 0.0, 0.0)
        _part(leg, lb, body_nodes)
        var sb := Meshes.Builder.new()
        loft(sb, [[0.0, 0.062, 0.062], [-0.10, 0.066, 0.066], [-0.42, 0.04, 0.04]], 8, skin, skin, 0.0, 0.0)
        box(sb, Vector3(0.0, -0.41, -0.05), Vector3(0.09, 0.05, 0.24), skin)
        _part(knee, sb, body_nodes)

    var hd := Meshes.Builder.new()
    _face(hd, skin, rng)
    var hair_col: Color = Outfits.HAIR_COLORS[clampi(int(look["hair_color"]), 0, Outfits.HAIR_COLORS.size() - 1)]
    _hair(hd, int(look["hair"]), hair_col, rng)
    _beard(hd, int(look["beard"]), hair_col, skin, rng)
    _part(head, hd, body_nodes)


func _face(b: Meshes.Builder, skin: Color, rng: RandomNumberGenerator) -> void:
    Meshes.blob(b, Vector3(0.0, 0.01, 0.0), Vector3(0.092, 0.108, 0.10), skin, rng, 0.03, 1)
    Meshes.blob(b, Vector3(0.0, -0.07, -0.02), Vector3(0.072, 0.06, 0.078), skin, rng, 0.03, 0)
    Meshes.blob(b, Vector3(0.0, -0.025, -0.1), Vector3(0.017, 0.032, 0.03), skin.darkened(0.04), rng, 0.05, 0)
    box(b, Vector3(0.0, 0.03, -0.094), Vector3(0.13, 0.02, 0.035), skin.darkened(0.06))
    for sv in [-1.0, 1.0]:
        var s: float = sv
        Meshes.blob(b, Vector3(s * 0.098, -0.005, 0.0), Vector3(0.016, 0.03, 0.02), skin, rng, 0.05, 0)
        Meshes.blob(b, Vector3(s * 0.038, 0.0, -0.089), Vector3(0.017, 0.012, 0.01), Color(0.95, 0.95, 0.95), rng, 0.0, 0)
        Meshes.blob(b, Vector3(s * 0.038, 0.0, -0.097), Vector3(0.008, 0.008, 0.006), Color(0.10, 0.07, 0.05), rng, 0.0, 0)
        box(b, Vector3(s * 0.038, 0.042, -0.099), Vector3(0.046, 0.009, 0.012), Color(0.12, 0.08, 0.05))
    box(b, Vector3(0.0, -0.072, -0.092), Vector3(0.042, 0.007, 0.01), skin.darkened(0.35))


func _hair(b: Meshes.Builder, style: int, col: Color, rng: RandomNumberGenerator) -> void:
    if style == 0:
        return
    Meshes.blob(b, Vector3(0.0, 0.05, 0.012), Vector3(0.102, 0.088, 0.112), col, rng, 0.06, 1)
    if style == 2:
        Meshes.frustum(b, Vector3(0.0, 0.06, 0.09), Vector3(0.0, -0.30, 0.12), 0.10, 0.07, 6, col, col.darkened(0.12), false)
        Meshes.frustum(b, Vector3(-0.09, 0.02, 0.02), Vector3(-0.1, -0.2, 0.04), 0.03, 0.015, 4, col, col.darkened(0.1), false)
        Meshes.frustum(b, Vector3(0.09, 0.02, 0.02), Vector3(0.1, -0.2, 0.04), 0.03, 0.015, 4, col, col.darkened(0.1), false)
    elif style == 3:
        for i in 14:
            var a := TAU * float(i) / 14.0
            var x := sin(a) * 0.1
            var z := cos(a) * 0.11
            if z < -0.07:
                continue
            var ln := rng.randf_range(0.14, 0.32)
            Meshes.frustum(b, Vector3(x, 0.06, z), Vector3(x * 1.25, 0.06 - ln, z * 1.25 + 0.03), 0.034, 0.008, 4, col, col.darkened(0.15), false)
        for k in 3:
            var fx := -0.05 + 0.05 * float(k)
            Meshes.frustum(b, Vector3(fx, 0.085, -0.09), Vector3(fx * 1.1, 0.045, -0.105), 0.022, 0.004, 4, col, col.darkened(0.1), false)
    elif style == 4:
        Meshes.frustum(b, Vector3(0.0, 0.05, 0.10), Vector3(0.0, -0.18, 0.20), 0.04, 0.015, 5, col, col.darkened(0.1), false)
        Meshes.blob(b, Vector3(0.0, 0.04, 0.105), Vector3(0.03, 0.03, 0.03), Color(0.7, 0.2, 0.15), rng, 0.0, 0)
    elif style == 5:
        for i in 7:
            var zz := -0.07 + 0.026 * float(i)
            Meshes.blob(b, Vector3(0.0, 0.13, zz), Vector3(0.018, 0.05, 0.025), col, rng, 0.1, 0)


func _beard(b: Meshes.Builder, style: int, col: Color, skin: Color, rng: RandomNumberGenerator) -> void:
    if style == 0:
        return
    if style == 1:
        Meshes.blob(b, Vector3(0.0, -0.075, -0.03), Vector3(0.082, 0.062, 0.085), skin.darkened(0.25), rng, 0.03, 1)
        return
    Meshes.blob(b, Vector3(0.0, -0.08, -0.035), Vector3(0.088, 0.075, 0.09), col, rng, 0.05, 1)
    box(b, Vector3(0.0, -0.05, -0.105), Vector3(0.07, 0.016, 0.02), col)
    if style == 3:
        Meshes.frustum(b, Vector3(0.0, -0.1, -0.07), Vector3(0.0, -0.30, -0.06), 0.07, 0.015, 6, col, col.darkened(0.1), false)


# ---------- look and outfit ----------

func set_look(d: Dictionary) -> void:
    look = d.duplicate()
    _build_body()


func set_outfit(d: Dictionary) -> void:
    outfit = d.duplicate()
    for cat in Outfits.CATS:
        _build_piece(String(cat), String(d.get(cat, "")))


func set_outfit_part(cat: String, id: String) -> void:
    outfit[cat] = id
    _build_piece(cat, id)


func _clear_cat(cat: String) -> void:
    var arr: Array = outfit_nodes.get(cat, [])
    for n in arr:
        if is_instance_valid(n):
            (n as Node).queue_free()
    outfit_nodes[cat] = []


func _build_piece(cat: String, id: String) -> void:
    _clear_cat(cat)
    if id == "":
        return
    var item: Dictionary = Outfits.find(id)
    if item.is_empty():
        return
    var col: Color = Outfits.color_of(item)
    var trim: Color = Outfits.trim_of(item)
    var premium: bool = bool(item["premium"])
    var shape: int = int(item["shape"])
    match cat:
        "shirt":
            _shirt(shape, col, trim, premium)
        "pants":
            _pants(shape, col, trim, premium)
        "shoes":
            _shoes(shape, col, trim, premium)
        "hat":
            _hat(shape, col, trim, premium)
        "mask":
            _mask(shape, col, trim, premium)


func _shirt(shape: int, col: Color, trim: Color, premium: bool) -> void:
    var dark := col.darkened(0.15)
    var rings: Array = TORSO.duplicate()
    if shape == 1:
        rings = [[0.06, 0.185, 0.125], [0.20, 0.16, 0.11], [0.38, 0.205, 0.135], [0.50, 0.225, 0.14], [0.585, 0.185, 0.12]]
    var b := Meshes.Builder.new()
    loft(b, rings, 10, dark, col, 0.0, 0.0)
    if premium:
        var r0: Array = rings[0]
        var y0: float = r0[0]
        var rx: float = r0[1]
        var rz: float = r0[2]
        loft(b, [[y0 - 0.006, rx + 0.006, rz + 0.006], [y0 + 0.035, rx + 0.004, rz + 0.004]], 10, trim, trim, 0.0, 0.0)
    if shape == 3:
        Meshes.blob(b, Vector3(0.0, 0.64, 0.07), Vector3(0.13, 0.10, 0.12), col, RandomNumberGenerator.new(), 0.0, 0)
    if shape == 4:
        loft(b, [[0.62, 0.27, 0.10], [0.45, 0.29, 0.12], [0.0, 0.31, 0.14], [-0.42, 0.34, 0.17]], 10, col, dark, 0.0, 0.05)
        Meshes.blob(b, Vector3(0.0, 0.58, -0.12), Vector3(0.03, 0.03, 0.02), trim if premium else Color(0.7, 0.6, 0.3), RandomNumberGenerator.new(), 0.0, 0)
    _piece("shirt", spine, b)
    var arms: Array = [arm_l, arm_r]
    var elbows: Array = [elbow_l, elbow_r]
    for a in arms:
        var sb := Meshes.Builder.new()
        var used := false
        if shape == 0:
            loft(sb, [[0.012, 0.07, 0.07], [-0.14, 0.062, 0.062]], 8, col, dark, 0.0, 0.0)
            used = true
        elif shape == 2 or shape == 3:
            loft(sb, [[0.012, 0.07, 0.07], [-0.30, 0.052, 0.052]], 8, col, dark, 0.0, 0.0)
            used = true
        if used:
            _piece("shirt", a, sb)
    if shape == 2 or shape == 3:
        for e in elbows:
            var eb := Meshes.Builder.new()
            loft(eb, [[0.0, 0.056, 0.056], [-0.26, 0.044, 0.044]], 8, dark, col, 0.0, 0.0)
            if premium:
                loft(eb, [[-0.25, 0.046, 0.046], [-0.28, 0.045, 0.045]], 8, trim, trim, 0.0, 0.0)
            _piece("shirt", e, eb)


func _pants(shape: int, col: Color, trim: Color, premium: bool) -> void:
    var dark := col.darkened(0.15)
    var legs: Array = [leg_l, leg_r]
    var knees: Array = [knee_l, knee_r]
    var b := Meshes.Builder.new()
    if shape == 1:
        loft(b, [[-0.02, 0.175, 0.115], [0.08, 0.17, 0.11]], 10, col, col, 0.0, 0.0)
        box(b, Vector3(0.0, -0.24, -0.125), Vector3(0.20, 0.32, 0.02), col)
        box(b, Vector3(0.0, -0.24, 0.115), Vector3(0.20, 0.32, 0.02), dark)
        if premium:
            box(b, Vector3(0.0, -0.40, -0.127), Vector3(0.20, 0.03, 0.02), trim)
    else:
        loft(b, [[-0.12, 0.18, 0.12], [0.10, 0.175, 0.115]], 10, col, col, 0.0, 0.0)
    if premium:
        loft(b, [[0.08, 0.178, 0.118], [0.115, 0.176, 0.116]], 10, trim, trim, 0.0, 0.0)
    _piece("pants", spine, b)
    if shape == 1:
        return
    var wide := 1.0
    if shape == 3:
        wide = 1.25
    if shape == 4:
        wide = 0.96
    for lg in legs:
        var tb := Meshes.Builder.new()
        var low := -0.44
        if shape == 0:
            low = -0.26
        loft(tb, [[0.04, 0.098 * wide, 0.098 * wide], [low, 0.07 * wide, 0.07 * wide]], 8, col, dark, 0.0, 0.0)
        _piece("pants", lg, tb)
    if shape != 0:
        for kn in knees:
            var kb := Meshes.Builder.new()
            loft(kb, [[0.0, 0.07 * wide, 0.07 * wide], [-0.38, 0.052 * wide, 0.052 * wide]], 8, dark, col, 0.0, 0.0)
            if shape == 3:
                loft(kb, [[-0.36, 0.07, 0.07], [-0.40, 0.065, 0.065]], 8, trim if premium else dark, dark, 0.0, 0.0)
            _piece("pants", kn, kb)


func _shoes(shape: int, col: Color, trim: Color, premium: bool) -> void:
    var dark := col.darkened(0.25)
    var knees: Array = [knee_l, knee_r]
    for kn in knees:
        var b := Meshes.Builder.new()
        box(b, Vector3(0.0, -0.438, -0.055), Vector3(0.105, 0.02, 0.28), dark)
        if shape == 0:
            box(b, Vector3(0.0, -0.425, -0.1), Vector3(0.012, 0.012, 0.12), col)
            box(b, Vector3(0.0, -0.405, -0.02), Vector3(0.10, 0.012, 0.02), col)
            box(b, Vector3(0.0, -0.405, -0.1), Vector3(0.10, 0.012, 0.02), col)
        elif shape == 1 or shape == 3:
            box(b, Vector3(0.0, -0.405, -0.055), Vector3(0.105, 0.065, 0.265), col)
            var top := -0.16
            if shape == 3:
                top = -0.04
            loft(b, [[top, 0.062, 0.062], [-0.40, 0.052, 0.052]], 8, col, dark, 0.0, 0.0)
            if premium:
                loft(b, [[top - 0.002, 0.064, 0.064], [top - 0.03, 0.063, 0.063]], 8, trim, trim, 0.0, 0.0)
        else:
            box(b, Vector3(0.0, -0.405, -0.055), Vector3(0.10, 0.056, 0.25), col)
            for k in 4:
                loft(b, [[-0.22 - 0.045 * float(k), 0.056, 0.056], [-0.245 - 0.045 * float(k), 0.055, 0.055]], 8, dark, col, 0.0, 0.0)
        _piece("shoes", kn, b)


func _hat(shape: int, col: Color, trim: Color, premium: bool) -> void:
    var rng := RandomNumberGenerator.new()
    var b := Meshes.Builder.new()
    var dark := col.darkened(0.2)
    if shape == 0:
        Meshes.blob(b, Vector3(0.0, 0.055, 0.01), Vector3(0.108, 0.075, 0.118), col, rng, 0.02, 1)
        box(b, Vector3(0.0, 0.048, -0.115), Vector3(0.15, 0.012, 0.075), dark)
    elif shape == 1:
        loft(b, [[0.07, 0.26, 0.26], [0.085, 0.24, 0.24]], 12, col, dark, 0.0, 0.0)
        Meshes.blob(b, Vector3(0.0, 0.10, 0.0), Vector3(0.125, 0.075, 0.125), col, rng, 0.03, 1)
    elif shape == 2:
        loft(b, [[0.03, 0.098, 0.108], [0.075, 0.096, 0.106]], 12, col, col, 0.0, 0.01)
        Meshes.blob(b, Vector3(0.1, 0.05, 0.03), Vector3(0.03, 0.03, 0.03), dark, rng, 0.0, 0)
    elif shape == 3:
        Meshes.blob(b, Vector3(0.0, 0.07, 0.01), Vector3(0.14, 0.095, 0.15), col, rng, 0.1, 1)
        Meshes.blob(b, Vector3(-0.115, -0.01, 0.01), Vector3(0.04, 0.07, 0.05), dark, rng, 0.08, 0)
        Meshes.blob(b, Vector3(0.115, -0.01, 0.01), Vector3(0.04, 0.07, 0.05), dark, rng, 0.08, 0)
    else:
        var metal := col.lerp(Color(0.6, 0.62, 0.66), 0.5)
        Meshes.blob(b, Vector3(0.0, 0.05, 0.01), Vector3(0.112, 0.092, 0.122), metal, rng, 0.0, 1)
        box(b, Vector3(0.0, -0.02, -0.12), Vector3(0.016, 0.075, 0.012), metal.darkened(0.1))
        box(b, Vector3(0.0, 0.14, 0.0), Vector3(0.012, 0.04, 0.16), dark)
    if premium:
        loft(b, [[0.04, 0.1, 0.11], [0.06, 0.099, 0.109]], 12, trim, trim, 0.0, 0.01)
    _piece("hat", head, b)


func _mask(shape: int, col: Color, trim: Color, premium: bool) -> void:
    var rng := RandomNumberGenerator.new()
    var b := Meshes.Builder.new()
    var dark := Color(0.06, 0.05, 0.05)
    var accent := trim if premium else col.darkened(0.3)
    if shape == 0 or shape == 4:
        Meshes.blob(b, Vector3(0.0, 0.0, -0.108), Vector3(0.088, 0.104, 0.03), col, rng, 0.03, 1)
        Meshes.blob(b, Vector3(-0.035, 0.015, -0.135), Vector3(0.022, 0.026, 0.01), dark, rng, 0.0, 0)
        Meshes.blob(b, Vector3(0.035, 0.015, -0.135), Vector3(0.022, 0.026, 0.01), dark, rng, 0.0, 0)
        box(b, Vector3(0.0, -0.065, -0.133), Vector3(0.07, 0.02, 0.01), Color(0.95, 0.95, 0.9))
        box(b, Vector3(0.0, -0.025, -0.136), Vector3(0.012, 0.03, 0.008), dark)
        if shape == 4:
            Meshes.blob(b, Vector3(-0.075, -0.03, -0.12), Vector3(0.02, 0.03, 0.015), col.darkened(0.1), rng, 0.0, 0)
            Meshes.blob(b, Vector3(0.075, -0.03, -0.12), Vector3(0.02, 0.03, 0.015), col.darkened(0.1), rng, 0.0, 0)
    elif shape == 1:
        Meshes.blob(b, Vector3(0.0, 0.0, -0.108), Vector3(0.09, 0.108, 0.028), col, rng, 0.03, 1)
        for k in 3:
            box(b, Vector3(-0.04 + 0.04 * float(k), 0.035, -0.137), Vector3(0.014, 0.05, 0.008), accent)
        box(b, Vector3(0.0, -0.045, -0.137), Vector3(0.07, 0.012, 0.008), accent)
        Meshes.blob(b, Vector3(-0.034, 0.012, -0.136), Vector3(0.016, 0.016, 0.008), dark, rng, 0.0, 0)
        Meshes.blob(b, Vector3(0.034, 0.012, -0.136), Vector3(0.016, 0.016, 0.008), dark, rng, 0.0, 0)
        for k in 3:
            var fx := -0.05 + 0.05 * float(k)
            Meshes.frustum(b, Vector3(fx, 0.1, -0.09), Vector3(fx * 1.3, 0.24, -0.07), 0.012, 0.003, 4, accent, col, false)
    elif shape == 2:
        Meshes.blob(b, Vector3(0.0, 0.0, -0.108), Vector3(0.086, 0.104, 0.032), col, rng, 0.03, 1)
        box(b, Vector3(-0.034, 0.014, -0.138), Vector3(0.03, 0.01, 0.008), dark)
        box(b, Vector3(0.034, 0.014, -0.138), Vector3(0.03, 0.01, 0.008), dark)
        box(b, Vector3(0.0, -0.05, -0.138), Vector3(0.04, 0.014, 0.008), dark)
        box(b, Vector3(0.0, -0.01, -0.14), Vector3(0.012, 0.05, 0.01), col.darkened(0.15))
    else:
        Meshes.frustum(b, Vector3(0.0, -0.03, -0.1), Vector3(0.0, -0.045, -0.2), 0.05, 0.014, 6, col, col.lightened(0.2), true)
        Meshes.blob(b, Vector3(0.0, -0.045, -0.2), Vector3(0.012, 0.012, 0.012), dark, rng, 0.0, 0)
        Meshes.frustum(b, Vector3(-0.06, 0.08, -0.04), Vector3(-0.08, 0.2, -0.02), 0.035, 0.004, 4, col, accent, true)
        Meshes.frustum(b, Vector3(0.06, 0.08, -0.04), Vector3(0.08, 0.2, -0.02), 0.035, 0.004, 4, col, accent, true)
        Meshes.blob(b, Vector3(0.0, 0.0, -0.098), Vector3(0.07, 0.07, 0.02), col.lightened(0.35), rng, 0.02, 0)
        Meshes.blob(b, Vector3(-0.034, 0.014, -0.12), Vector3(0.012, 0.012, 0.006), dark, rng, 0.0, 0)
        Meshes.blob(b, Vector3(0.034, 0.014, -0.12), Vector3(0.012, 0.012, 0.006), dark, rng, 0.0, 0)
    _piece("mask", head, b)
