extends Node3D

# The player's inventory (materials, tools), crafting, campfires (respawn points)
# and the bag that stays where the player died.

const I18n = preload("res://scripts/i18n.gd")
const Items = preload("res://scripts/items.gd")

var map: Dictionary = {}
var player = null
var terrain = null
var audio = null
var hud = null
var daynight = null

var items := {"wood": 0, "stone": 0, "fiber": 0, "sapling": 0, "arrow": 0}
var tools := {}
var equipped := "club"

var wood: int:
    get:
        return int(items["wood"])
    set(value):
        items["wood"] = value

var stone: int:
    get:
        return int(items["stone"])
    set(value):
        items["stone"] = value

var fires: Array = []
var fire_lights: Array = []
var bag_node: Node3D = null
var bag_pos := Vector3.ZERO
var bag_items := {}

var near_bag := false
var scan_t := 0.0
var t := 0.0


func setup(m: Dictionary, p, tr, a) -> void:
    map = m
    player = p
    terrain = tr
    audio = a


# ---------- inventory ----------

func add_item(id: String, n: int) -> void:
    items[id] = int(items.get(id, 0)) + n


func has_cost(cost: Dictionary) -> bool:
    for k in cost.keys():
        if int(items.get(k, 0)) < int(cost[k]):
            return false
    return true


func pay(cost: Dictionary) -> void:
    for k in cost.keys():
        items[k] = int(items.get(k, 0)) - int(cost[k])


func _day() -> int:
    if daynight != null:
        return int(daynight.day_number())
    return 1


# Returns the translation key of the message to show.
func craft(id: String) -> String:
    var r := Items.recipe(id)
    if r.is_empty():
        return ""
    if _day() < int(r["day"]):
        return "craft_missing"
    var cost: Dictionary = r["cost"]
    if not has_cost(cost):
        return "craft_missing"
    if id == "campfire":
        var spot: Variant = _fire_spot()
        if spot == null:
            return "cant_build"
        pay(cost)
        _place_fire(spot)
        return "fire_built"
    pay(cost)
    if id == "arrow":
        add_item("arrow", 3)
    else:
        tools[id] = true
        equip_best()
    return "crafted"


func equip_best() -> void:
    if tools.has("sword"):
        equipped = "sword"
    elif tools.has("axe"):
        equipped = "axe"
    elif tools.has("pickaxe"):
        equipped = "pickaxe"
    elif tools.has("bow"):
        equipped = "bow"
    else:
        equipped = "club"
    if player != null and player.model != null:
        player.model.set_held(equipped)


func tool_power(kind: String) -> int:
    if kind == "rock":
        if tools.has("pickaxe"):
            return 4
        return 0
    if tools.has("axe"):
        return 4
    if tools.has("sword"):
        return 2
    return 1


func msg(text: String, col: Color = Color(1.0, 0.9, 0.6)) -> void:
    if hud != null:
        hud.message = text
        hud.message_t = 2.5
        hud.message_col = col
        hud.message_size = 34


func msg_key(key: String) -> void:
    if key != "":
        msg(I18n.t(key))


# ---------- campfire ----------

func _fire_spot() -> Variant:
    var fwd: Vector3 = -player.model.global_transform.basis.z
    var pos: Vector3 = player.global_position + fwd * 1.6
    pos.y = terrain.height_at(pos.x, pos.z)
    if pos.y < 0.6:
        return null
    return pos


func _place_fire(pos: Vector3) -> void:
    _spawn_fire(pos)
    var sp := pos + Vector3(0.0, 0.0, 1.4)
    sp.y = terrain.height_at(sp.x, sp.z) + 0.5
    player.spawn_pos = sp
    if audio != null:
        audio.ignite()


func _spawn_fire(pos: Vector3) -> void:
    var root := Node3D.new()
    root.position = pos
    add_child(root)

    var stone_mat := StandardMaterial3D.new()
    stone_mat.albedo_color = Color(0.45, 0.45, 0.47)
    stone_mat.roughness = 1.0
    var sm := SphereMesh.new()
    sm.radius = 0.16
    sm.height = 0.24
    sm.radial_segments = 6
    sm.rings = 3
    sm.material = stone_mat
    for k in 7:
        var a := TAU * float(k) / 7.0
        var mi := MeshInstance3D.new()
        mi.mesh = sm
        mi.position = Vector3(cos(a) * 0.55, 0.1, sin(a) * 0.55)
        root.add_child(mi)

    var log_mat := StandardMaterial3D.new()
    log_mat.albedo_color = Color(0.25, 0.16, 0.09)
    log_mat.roughness = 1.0
    var lm := CylinderMesh.new()
    lm.top_radius = 0.06
    lm.bottom_radius = 0.07
    lm.height = 0.8
    lm.radial_segments = 6
    lm.rings = 1
    lm.material = log_mat
    for k in 3:
        var li := MeshInstance3D.new()
        li.mesh = lm
        li.basis = Basis(Vector3.UP, TAU * float(k) / 3.0) * Basis(Vector3.RIGHT, deg_to_rad(75.0))
        li.position = Vector3(0.0, 0.14, 0.0)
        root.add_child(li)

    var flame_mat := StandardMaterial3D.new()
    flame_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    flame_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    flame_mat.albedo_color = Color(1.0, 0.55, 0.15, 0.8)
    var fm := SphereMesh.new()
    fm.radius = 0.09
    fm.height = 0.18
    fm.radial_segments = 5
    fm.rings = 3
    fm.material = flame_mat
    var fp := CPUParticles3D.new()
    fp.position = Vector3(0.0, 0.3, 0.0)
    fp.mesh = fm
    fp.amount = 40
    fp.lifetime = 0.9
    fp.direction = Vector3(0.0, 1.0, 0.0)
    fp.spread = 14.0
    fp.initial_velocity_min = 0.8
    fp.initial_velocity_max = 1.6
    fp.gravity = Vector3(0.0, 0.6, 0.0)
    fp.scale_amount_min = 0.5
    fp.scale_amount_max = 1.3
    fp.emission_shape = CPUParticles3D.EMISSION_SHAPE_SPHERE
    fp.emission_sphere_radius = 0.18
    fp.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    root.add_child(fp)
    fp.emitting = true

    var light := OmniLight3D.new()
    light.light_color = Color(1.0, 0.6, 0.25)
    light.light_energy = 3.0
    light.omni_range = 16.0
    light.position = Vector3(0.0, 0.9, 0.0)
    root.add_child(light)

    fires.append(pos)
    fire_lights.append(light)


# ---------- death bag ----------

func drop_bag(pos: Vector3) -> void:
    var total := 0
    var content := {}
    for k in items.keys():
        var n := int(items[k])
        if n > 0:
            content[k] = n
            total += n
    if total <= 0:
        return
    _clear_bag()
    bag_items = content
    for k in items.keys():
        items[k] = 0
    var p := pos
    p.y = maxf(terrain.height_at(pos.x, pos.z), 0.0)
    _make_bag(p)


func _make_bag(pos: Vector3) -> void:
    bag_pos = pos
    var root := Node3D.new()
    root.position = pos
    add_child(root)
    var sack_mat := StandardMaterial3D.new()
    sack_mat.albedo_color = Color(0.45, 0.32, 0.18)
    sack_mat.roughness = 1.0
    var sack := SphereMesh.new()
    sack.radius = 0.3
    sack.height = 0.5
    sack.radial_segments = 8
    sack.rings = 4
    sack.material = sack_mat
    var mi := MeshInstance3D.new()
    mi.mesh = sack
    mi.position = Vector3(0.0, 0.22, 0.0)
    root.add_child(mi)
    var beam_mat := StandardMaterial3D.new()
    beam_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    beam_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    beam_mat.albedo_color = Color(1.0, 0.85, 0.3, 0.22)
    var beam := CylinderMesh.new()
    beam.top_radius = 0.06
    beam.bottom_radius = 0.06
    beam.height = 8.0
    beam.radial_segments = 6
    beam.rings = 1
    beam.material = beam_mat
    var bi := MeshInstance3D.new()
    bi.mesh = beam
    bi.position = Vector3(0.0, 4.0, 0.0)
    bi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    root.add_child(bi)
    bag_node = root


func _clear_bag() -> void:
    if bag_node != null:
        bag_node.queue_free()
        bag_node = null


func try_interact() -> bool:
    if near_bag:
        for k in bag_items.keys():
            add_item(String(k), int(bag_items[k]))
        bag_items = {}
        _clear_bag()
        near_bag = false
        if audio != null:
            audio.pickup()
        return true
    return false


func prompt() -> String:
    if near_bag:
        return I18n.t("loot_bag")
    return ""


# ---------- save / load ----------

func to_dict() -> Dictionary:
    var fl: Array = []
    for f in fires:
        fl.append([f.x, f.y, f.z])
    var d := {"items": items, "tools": tools.keys(), "fires": fl}
    if bag_node != null:
        d["bag"] = {"pos": [bag_pos.x, bag_pos.y, bag_pos.z], "items": bag_items}
    return d


func from_dict(d: Dictionary) -> void:
    var saved: Dictionary = d.get("items", {})
    for k in saved.keys():
        items[String(k)] = int(saved[k])
    tools = {}
    for tl in d.get("tools", []):
        tools[String(tl)] = true
    equip_best()
    for f in d.get("fires", []):
        _spawn_fire(Vector3(float(f[0]), float(f[1]), float(f[2])))
    var b = d.get("bag", null)
    if b != null:
        bag_items = {}
        var bi: Dictionary = b.get("items", {})
        for k in bi.keys():
            bag_items[String(k)] = int(bi[k])
        var bp = b["pos"]
        _make_bag(Vector3(float(bp[0]), float(bp[1]), float(bp[2])))


# ---------- per frame ----------

func _process(delta: float) -> void:
    if player == null:
        return
    t += delta
    scan_t -= delta
    if scan_t <= 0.0:
        scan_t = 0.2
        var pp0: Vector3 = player.global_position
        near_bag = bag_node != null and Vector2(pp0.x - bag_pos.x, pp0.z - bag_pos.z).length() < 2.6
    var nearest := 9999.0
    var pp: Vector3 = player.global_position
    for i in fire_lights.size():
        var l: OmniLight3D = fire_lights[i]
        l.light_energy = 3.0 + sin(t * 13.0 + float(i)) * 0.5 + sin(t * 7.3) * 0.3
        nearest = minf(nearest, pp.distance_to(fires[i]))
    if audio != null:
        audio.set_fire(clampf(1.0 - nearest / 16.0, 0.0, 1.0) * 0.5)
    if hud != null:
        hud.items = items
