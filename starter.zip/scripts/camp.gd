extends Node3D

# Gatherable wood and stone, campfires (also the respawn point) and the
# loot bag that stays at the place where the player died.

const I18n = preload("res://scripts/i18n.gd")
const Settings = preload("res://scripts/settings.gd")

const WOOD_COUNT := {"savanna": 40, "forest": 90, "iceage": 40, "desert": 15, "volcanic": 10}
const STONE_COUNT := {"savanna": 30, "forest": 25, "iceage": 35, "desert": 40, "volcanic": 50}

var map: Dictionary = {}
var player = null
var terrain = null
var audio = null
var hud = null

var wood := 0
var stone := 0
var wood_pos: Array = []
var stone_pos: Array = []
var wood_xf: Array = []
var stone_xf: Array = []
var wood_taken := {}
var stone_taken := {}
var wood_mm: MultiMesh
var stone_mm: MultiMesh

var fires: Array = []
var fire_lights: Array = []
var bag_node: Node3D = null
var bag_pos := Vector3.ZERO
var bag_wood := 0
var bag_stone := 0

var near_kind := ""
var near_idx := -1
var scan_t := 0.0
var t := 0.0


func setup(m: Dictionary, p, tr, a) -> void:
    map = m
    player = p
    terrain = tr
    audio = a
    var id := String(map["id"])
    wood_pos = _scatter(int(WOOD_COUNT.get(id, 20)), int(map["seed"]) * 17 + 1)
    stone_pos = _scatter(int(STONE_COUNT.get(id, 20)), int(map["seed"]) * 19 + 2)
    wood_mm = _make_mm(wood_pos, true)
    stone_mm = _make_mm(stone_pos, false)


func _scatter(count: int, seed_val: int) -> Array:
    var out: Array = []
    var rng := RandomNumberGenerator.new()
    rng.seed = seed_val
    var tries := 0
    while out.size() < count and tries < count * 80:
        tries += 1
        var x := 0.0
        var z := 0.0
        if out.size() < 4:
            var ang := rng.randf() * TAU
            var rad := rng.randf_range(8.0, 30.0)
            x = cos(ang) * rad
            z = sin(ang) * rad
        else:
            x = rng.randf_range(-160.0, 160.0)
            z = rng.randf_range(-160.0, 160.0)
        if absf(x) < 6.5 and absf(z + 6.0) < 6.5:
            continue
        var h: float = terrain.height_at(x, z)
        if h < 0.8 or h > 10.0:
            continue
        out.append(Vector3(x, h, z))
    return out


func _make_mm(positions: Array, is_wood: bool) -> MultiMesh:
    var rng := RandomNumberGenerator.new()
    rng.seed = positions.size() * 13 + (5 if is_wood else 9)
    var mesh: Mesh
    var mat := StandardMaterial3D.new()
    mat.roughness = 1.0
    Settings.tune(mat)
    if is_wood:
        var cm := CylinderMesh.new()
        cm.top_radius = 0.035
        cm.bottom_radius = 0.05
        cm.height = 1.0
        cm.radial_segments = 5
        cm.rings = 1
        mat.albedo_color = Color(0.36, 0.25, 0.14)
        cm.material = mat
        mesh = cm
    else:
        var sm := SphereMesh.new()
        sm.radius = 0.2
        sm.height = 0.3
        sm.radial_segments = 6
        sm.rings = 3
        mat.albedo_color = Color(0.5, 0.5, 0.52)
        sm.material = mat
        mesh = sm
    var mm := MultiMesh.new()
    mm.transform_format = MultiMesh.TRANSFORM_3D
    mm.mesh = mesh
    mm.instance_count = positions.size()
    for i in positions.size():
        var p: Vector3 = positions[i]
        var yaw := rng.randf() * TAU
        var xf := Transform3D()
        if is_wood:
            var b := Basis(Vector3.UP, yaw) * Basis(Vector3.RIGHT, PI * 0.5)
            xf = Transform3D(b, p + Vector3(0.0, 0.06, 0.0))
            wood_xf.append(xf)
        else:
            var s := rng.randf_range(0.7, 1.3)
            var b2 := Basis(Vector3.UP, yaw).scaled(Vector3(s, s * 0.8, s))
            xf = Transform3D(b2, p + Vector3(0.0, 0.08 * s, 0.0))
            stone_xf.append(xf)
        mm.set_instance_transform(i, xf)
    var mmi := MultiMeshInstance3D.new()
    mmi.multimesh = mm
    add_child(mmi)
    return mm


# ---------- interaction ----------

func try_interact() -> bool:
    match near_kind:
        "bag":
            _loot()
            return true
        "wood":
            _take(true, near_idx)
            return true
        "stone":
            _take(false, near_idx)
            return true
    return false


func prompt() -> String:
    match near_kind:
        "bag":
            return I18n.t("loot_bag")
        "wood":
            return I18n.t("pickup_wood")
        "stone":
            return I18n.t("pickup_stone")
    return ""


func _take(is_wood: bool, i: int) -> void:
    var tiny := Basis().scaled(Vector3(0.0001, 0.0001, 0.0001))
    if is_wood:
        wood += 1
        wood_taken[i] = true
        wood_mm.set_instance_transform(i, Transform3D(tiny, wood_pos[i]))
    else:
        stone += 1
        stone_taken[i] = true
        stone_mm.set_instance_transform(i, Transform3D(tiny, stone_pos[i]))
    near_kind = ""
    near_idx = -1
    if audio != null:
        audio.pickup()


func _scan() -> void:
    var pp: Vector3 = player.global_position
    near_kind = ""
    near_idx = -1
    if bag_node != null and Vector2(pp.x - bag_pos.x, pp.z - bag_pos.z).length() < 2.6:
        near_kind = "bag"
        return
    var best := 2.0
    for i in wood_pos.size():
        if wood_taken.has(i):
            continue
        var d := Vector2(pp.x - wood_pos[i].x, pp.z - wood_pos[i].z).length()
        if d < best:
            best = d
            near_kind = "wood"
            near_idx = i
    for i in stone_pos.size():
        if stone_taken.has(i):
            continue
        var d2 := Vector2(pp.x - stone_pos[i].x, pp.z - stone_pos[i].z).length()
        if d2 < best:
            best = d2
            near_kind = "stone"
            near_idx = i


func _msg(text: String) -> void:
    if hud != null:
        hud.message = text
        hud.message_t = 2.5
        hud.message_col = Color(1.0, 0.9, 0.6)
        hud.message_size = 34


# ---------- campfire ----------

func build_fire() -> void:
    if wood < 3 or stone < 2:
        _msg(I18n.t("need_materials"))
        return
    var fwd: Vector3 = -player.model.global_transform.basis.z
    var pos: Vector3 = player.global_position + fwd * 1.6
    pos.y = terrain.height_at(pos.x, pos.z)
    if pos.y < 0.6:
        _msg(I18n.t("cant_build"))
        return
    wood -= 3
    stone -= 2
    _spawn_fire(pos)
    var sp := pos + Vector3(0.0, 0.0, 1.4)
    sp.y = terrain.height_at(sp.x, sp.z) + 0.5
    player.spawn_pos = sp
    if audio != null:
        audio.ignite()
    _msg(I18n.t("fire_built"))


func _spawn_fire(pos: Vector3) -> void:
    var root := Node3D.new()
    root.position = pos
    add_child(root)

    var stone_mat := StandardMaterial3D.new()
    stone_mat.albedo_color = Color(0.45, 0.45, 0.47)
    stone_mat.roughness = 1.0
    var sm := SphereMesh.new()
    sm.radius = 0.16
    sm.height = 0.24
    sm.radial_segments = 6
    sm.rings = 3
    sm.material = stone_mat
    for k in 7:
        var a := TAU * float(k) / 7.0
        var mi := MeshInstance3D.new()
        mi.mesh = sm
        mi.position = Vector3(cos(a) * 0.55, 0.1, sin(a) * 0.55)
        root.add_child(mi)

    var log_mat := StandardMaterial3D.new()
    log_mat.albedo_color = Color(0.25, 0.16, 0.09)
    log_mat.roughness = 1.0
    var lm := CylinderMesh.new()
    lm.top_radius = 0.06
    lm.bottom_radius = 0.07
    lm.height = 0.8
    lm.radial_segments = 6
    lm.rings = 1
    lm.material = log_mat
    for k in 3:
        var li := MeshInstance3D.new()
        li.mesh = lm
        li.basis = Basis(Vector3.UP, TAU * float(k) / 3.0) * Basis(Vector3.RIGHT, deg_to_rad(75.0))
        li.position = Vector3(0.0, 0.14, 0.0)
        root.add_child(li)

    var flame_mat := StandardMaterial3D.new()
    flame_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    flame_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    flame_mat.albedo_color = Color(1.0, 0.55, 0.15, 0.8)
    var fm := SphereMesh.new()
    fm.radius = 0.09
    fm.height = 0.18
    fm.radial_segments = 5
    fm.rings = 3
    fm.material = flame_mat
    var fp := CPUParticles3D.new()
    fp.position = Vector3(0.0, 0.3, 0.0)
    fp.mesh = fm
    fp.amount = 40
    fp.lifetime = 0.9
    fp.direction = Vector3(0.0, 1.0, 0.0)
    fp.spread = 14.0
    fp.initial_velocity_min = 0.8
    fp.initial_velocity_max = 1.6
    fp.gravity = Vector3(0.0, 0.6, 0.0)
    fp.scale_amount_min = 0.5
    fp.scale_amount_max = 1.3
    fp.emission_shape = CPUParticles3D.EMISSION_SHAPE_SPHERE
    fp.emission_sphere_radius = 0.18
    fp.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    root.add_child(fp)
    fp.emitting = true

    var light := OmniLight3D.new()
    light.light_color = Color(1.0, 0.6, 0.25)
    light.light_energy = 3.0
    light.omni_range = 16.0
    light.position = Vector3(0.0, 0.9, 0.0)
    root.add_child(light)

    fires.append(pos)
    fire_lights.append(light)


# ---------- death bag ----------

func drop_bag(pos: Vector3) -> void:
    if wood + stone <= 0:
        return
    _clear_bag()
    bag_wood = wood
    bag_stone = stone
    wood = 0
    stone = 0
    var p := pos
    p.y = maxf(terrain.height_at(pos.x, pos.z), 0.0)
    _make_bag(p)


func _make_bag(pos: Vector3) -> void:
    bag_pos = pos
    var root := Node3D.new()
    root.position = pos
    add_child(root)
    var sack_mat := StandardMaterial3D.new()
    sack_mat.albedo_color = Color(0.45, 0.32, 0.18)
    sack_mat.roughness = 1.0
    var sack := SphereMesh.new()
    sack.radius = 0.3
    sack.height = 0.5
    sack.radial_segments = 8
    sack.rings = 4
    sack.material = sack_mat
    var mi := MeshInstance3D.new()
    mi.mesh = sack
    mi.position = Vector3(0.0, 0.22, 0.0)
    root.add_child(mi)
    var beam_mat := StandardMaterial3D.new()
    beam_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    beam_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    beam_mat.albedo_color = Color(1.0, 0.85, 0.3, 0.22)
    var beam := CylinderMesh.new()
    beam.top_radius = 0.06
    beam.bottom_radius = 0.06
    beam.height = 8.0
    beam.radial_segments = 6
    beam.rings = 1
    beam.material = beam_mat
    var bi := MeshInstance3D.new()
    bi.mesh = beam
    bi.position = Vector3(0.0, 4.0, 0.0)
    bi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    root.add_child(bi)
    bag_node = root


func _clear_bag() -> void:
    if bag_node != null:
        bag_node.queue_free()
        bag_node = null


func _loot() -> void:
    wood += bag_wood
    stone += bag_stone
    bag_wood = 0
    bag_stone = 0
    _clear_bag()
    near_kind = ""
    if audio != null:
        audio.pickup()


# ---------- save / load ----------

func to_dict() -> Dictionary:
    var fl: Array = []
    for f in fires:
        fl.append([f.x, f.y, f.z])
    var d := {
        "wood": wood,
        "stone": stone,
        "wood_taken": wood_taken.keys(),
        "stone_taken": stone_taken.keys(),
        "fires": fl,
    }
    if bag_node != null:
        d["bag"] = {"pos": [bag_pos.x, bag_pos.y, bag_pos.z], "wood": bag_wood, "stone": bag_stone}
    return d


func from_dict(d: Dictionary) -> void:
    wood = int(d.get("wood", 0))
    stone = int(d.get("stone", 0))
    var tiny := Basis().scaled(Vector3(0.0001, 0.0001, 0.0001))
    for k in d.get("wood_taken", []):
        var i := int(k)
        if i >= 0 and i < wood_pos.size():
            wood_taken[i] = true
            wood_mm.set_instance_transform(i, Transform3D(tiny, wood_pos[i]))
    for k in d.get("stone_taken", []):
        var j := int(k)
        if j >= 0 and j < stone_pos.size():
            stone_taken[j] = true
            stone_mm.set_instance_transform(j, Transform3D(tiny, stone_pos[j]))
    for f in d.get("fires", []):
        _spawn_fire(Vector3(float(f[0]), float(f[1]), float(f[2])))
    var b = d.get("bag", null)
    if b != null:
        bag_wood = int(b["wood"])
        bag_stone = int(b["stone"])
        var bp = b["pos"]
        _make_bag(Vector3(float(bp[0]), float(bp[1]), float(bp[2])))


# ---------- per frame ----------

func _process(delta: float) -> void:
    if player == null:
        return
    t += delta
    scan_t -= delta
    if scan_t <= 0.0:
        scan_t = 0.2
        _scan()
    var nearest := 9999.0
    var pp: Vector3 = player.global_position
    for i in fire_lights.size():
        var l: OmniLight3D = fire_lights[i]
        l.light_energy = 3.0 + sin(t * 13.0 + float(i)) * 0.5 + sin(t * 7.3) * 0.3
        nearest = minf(nearest, pp.distance_to(fires[i]))
    if audio != null:
        audio.set_fire(clampf(1.0 - nearest / 16.0, 0.0, 1.0) * 0.5)
    if hud != null:
        hud.wood = wood
        hud.stone = stone
