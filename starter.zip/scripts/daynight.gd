extends Node3D

# Full day/night cycle (10 real minutes per day). Drives the sun, moon, stars,
# sky, fog and ambient light. Weather values (dim, fog_mul, ...) come from weather.gd.

const DAY_LEN := 600.0
const I18n = preload("res://scripts/i18n.gd")
const NIGHT_TOP := Color(0.012, 0.018, 0.055)
const NIGHT_HOR := Color(0.035, 0.045, 0.09)
const NIGHT_FOG := Color(0.025, 0.035, 0.07)
const NIGHT_AMB := Color(0.10, 0.13, 0.22)
const DUSK_HOR := Color(1.0, 0.50, 0.25)
const DUSK_FOG := Color(0.62, 0.42, 0.36)
const WEATHER_GREY := Color(0.5, 0.55, 0.6)

var map: Dictionary = {}
var player = null
var env: Environment
var sky_mat: ProceduralSkyMaterial
var sun: DirectionalLight3D
var weather = null
var audio = null
var hud = null

var moon_light: DirectionalLight3D
var sun_mesh: MeshInstance3D
var moon_mesh: MeshInstance3D
var star_mmi: MultiMeshInstance3D
var star_mat: StandardMaterial3D

var day_t := 0.32
var sky_t := 0.0
var elapsed := 0.0
var sun_mul := 1.0
var season_fog := 1.0
var base_sun_energy := 1.0
var base_amb := 1.0
var base_fog_d := 0.004
var max_elev := 55.0
var azimuth := 0.0
var sun_col_day := Color(1, 1, 1)
var day_amb := Color(0.6, 0.65, 0.75)


func setup(m: Dictionary, p, e: Environment, sm: ProceduralSkyMaterial, s: DirectionalLight3D, w, a) -> void:
    map = m
    player = p
    env = e
    sky_mat = sm
    sun = s
    weather = w
    audio = a
    base_sun_energy = float(map["sun_energy"])
    base_amb = env.ambient_light_energy
    base_fog_d = env.fog_density
    sun_col_day = map["sun_color"]
    var rot: Vector3 = map["sun_rot"]
    max_elev = clampf(absf(rot.x) + 15.0, 30.0, 80.0)
    azimuth = rot.y
    var top: Color = map["sky_top"]
    var hor: Color = map["sky_hor"]
    day_amb = top.lerp(hor, 0.5).lightened(0.15)

    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR

    moon_light = DirectionalLight3D.new()
    moon_light.light_color = Color(0.55, 0.65, 1.0)
    moon_light.shadow_enabled = false
    moon_light.light_energy = 0.0
    add_child(moon_light)

    sun_mesh = _glow_sphere(25.0, Color(1.0, 0.93, 0.75))
    moon_mesh = _glow_sphere(18.0, Color(0.85, 0.9, 1.0))
    _build_stars()


func _glow_sphere(radius: float, col: Color) -> MeshInstance3D:
    var mesh := SphereMesh.new()
    mesh.radius = radius
    mesh.height = radius * 2.0
    mesh.radial_segments = 16
    mesh.rings = 8
    var mat := StandardMaterial3D.new()
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    mat.albedo_color = col
    mat.disable_fog = true
    mesh.material = mat
    var mi := MeshInstance3D.new()
    mi.mesh = mesh
    mi.top_level = true
    mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    add_child(mi)
    return mi


func _build_stars() -> void:
    var rng := RandomNumberGenerator.new()
    rng.seed = 424242
    var mesh := SphereMesh.new()
    mesh.radius = 1.0
    mesh.height = 2.0
    mesh.radial_segments = 4
    mesh.rings = 2
    star_mat = StandardMaterial3D.new()
    star_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    star_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    star_mat.albedo_color = Color(1.0, 1.0, 1.0, 0.0)
    star_mat.disable_fog = true
    mesh.material = star_mat
    var mm := MultiMesh.new()
    mm.transform_format = MultiMesh.TRANSFORM_3D
    mm.mesh = mesh
    mm.instance_count = 320
    for i in 320:
        var d := Vector3(rng.randf_range(-1.0, 1.0), rng.randf_range(0.05, 1.0), rng.randf_range(-1.0, 1.0)).normalized()
        var s := rng.randf_range(1.0, 2.6)
        mm.set_instance_transform(i, Transform3D(Basis().scaled(Vector3(s, s, s)), d * 640.0))
    star_mmi = MultiMeshInstance3D.new()
    star_mmi.multimesh = mm
    star_mmi.top_level = true
    star_mmi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    add_child(star_mmi)


func _process(delta: float) -> void:
    if player == null or weather == null:
        return
    day_t = fposmod(day_t + delta / DAY_LEN, 1.0)
    elapsed += delta
    var elev := sin((day_t - 0.25) * TAU)
    var daylight := smoothstep(-0.12, 0.35, elev)
    var tw := clampf(1.0 - absf(elev) / 0.3, 0.0, 1.0)
    var dim: float = weather.dim
    var cloud: float = weather.cloud
    var flash: float = weather.flash_amt

    # sun and moon lights
    var elev_deg := elev * max_elev
    sun.rotation_degrees = Vector3(-elev_deg, azimuth, 0.0)
    moon_light.rotation_degrees = Vector3(elev_deg, azimuth + 180.0, 0.0)
    sun.light_energy = base_sun_energy * sun_mul * smoothstep(-0.02, 0.3, elev) * dim + flash * 2.0
    sun.light_color = sun_col_day.lerp(Color(1.0, 0.55, 0.3), tw * 0.8)
    moon_light.light_energy = 0.28 * (1.0 - smoothstep(-0.1, 0.15, elev)) * (1.0 - cloud * 0.6)

    # ambient light
    var amb := NIGHT_AMB.lerp(day_amb, daylight).lerp(DUSK_HOR * 0.5, tw * 0.35)
    env.ambient_light_color = amb
    env.ambient_light_energy = lerpf(1.0, base_amb, daylight) * (0.6 + 0.4 * dim) + flash * 2.5

    # sky and fog
    sky_t -= delta
    if sky_t <= 0.0:
        sky_t = 0.25
        var day_top: Color = map["sky_top"]
        var day_hor: Color = map["sky_hor"]
        var day_fog: Color = map["fog"]
        var top := NIGHT_TOP.lerp(day_top, daylight)
        var hor := NIGHT_HOR.lerp(day_hor, daylight).lerp(DUSK_HOR, tw * 0.7)
        var fog := NIGHT_FOG.lerp(day_fog, daylight).lerp(DUSK_FOG, tw * 0.6)
        var grey_col := Color(WEATHER_GREY.r, WEATHER_GREY.g, WEATHER_GREY.b) * (0.15 + 0.85 * daylight)
        hor = hor.lerp(grey_col, float(weather.grey))
        fog = fog.lerp(grey_col, float(weather.grey) * 0.8)
        top = top.darkened(float(weather.sky_dark) * daylight)
        sky_mat.sky_top_color = top
        sky_mat.sky_horizon_color = hor
        sky_mat.ground_horizon_color = hor
        sky_mat.ground_bottom_color = hor.darkened(0.6)
        env.fog_light_color = fog
        env.fog_density = base_fog_d * float(weather.fog_mul) * season_fog * (1.0 + 0.5 * (1.0 - daylight))

    # sun, moon and stars in the sky
    var pp: Vector3 = player.camera.global_position
    sun_mesh.global_position = pp + sun.global_transform.basis.z * 650.0
    sun_mesh.visible = elev > -0.06 and cloud < 0.5
    moon_mesh.global_position = pp + moon_light.global_transform.basis.z * 640.0
    moon_mesh.visible = (-elev) > -0.06 and cloud < 0.6
    star_mmi.global_position = pp
    var star_a := (1.0 - smoothstep(-0.15, 0.1, elev)) * (1.0 - cloud)
    star_mat.albedo_color = Color(1.0, 1.0, 1.0, star_a)
    star_mmi.visible = star_a > 0.01

    # clock and ambience
    if hud != null:
        var hour := day_t * 24.0
        hud.time_text = (I18n.t("locked_day") % day_number()) + ("  %02d:%02d" % [int(hour), int(fmod(hour, 1.0) * 60.0)])
    if audio != null:
        audio.set_day(daylight)


# Game day number (1, 2, 3...). One day lasts 10 real minutes.
func day_number() -> int:
    return int(elapsed / DAY_LEN) + 1
