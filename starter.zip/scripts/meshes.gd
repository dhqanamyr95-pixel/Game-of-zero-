extends RefCounted

# Procedural mesh library. Every tree, rock, bush and small item is generated from
# code once and shared by all instances (MultiMesh).
# Vertex colour alpha = 1 marks a "leaf" vertex (seasonal colour and wind sway),
# alpha = 0 is wood, rock or anything that never changes colour.

const TREE_OAK := 0
const TREE_WILLOW := 1
const TREE_SPRUCE := 2
const TREE_BANYAN := 3
const TREE_BLOSSOM := 4
const TREE_DEAD := 5
const TREE_CACTUS := 6
const TREE_COUNT := 7

const ICO_V := [
    Vector3(-1.0, 1.618034, 0.0), Vector3(1.0, 1.618034, 0.0), Vector3(-1.0, -1.618034, 0.0),
    Vector3(1.0, -1.618034, 0.0), Vector3(0.0, -1.0, 1.618034), Vector3(0.0, 1.0, 1.618034),
    Vector3(0.0, -1.0, -1.618034), Vector3(0.0, 1.0, -1.618034), Vector3(1.618034, 0.0, -1.0),
    Vector3(1.618034, 0.0, 1.0), Vector3(-1.618034, 0.0, -1.0), Vector3(-1.618034, 0.0, 1.0),
]
const ICO_F := [
    [0, 11, 5], [0, 5, 1], [0, 1, 7], [0, 7, 10], [0, 10, 11],
    [1, 5, 9], [5, 11, 4], [11, 10, 2], [10, 7, 6], [7, 1, 8],
    [3, 9, 4], [3, 4, 2], [3, 2, 6], [3, 6, 8], [3, 8, 9],
    [4, 9, 5], [2, 4, 11], [6, 2, 10], [8, 6, 7], [9, 8, 1],
]

static var _cache: Dictionary = {}


class Builder:
    var verts := PackedVector3Array()
    var norms := PackedVector3Array()
    var cols := PackedColorArray()
    var idx := PackedInt32Array()

    # One flat-shaded triangle. "center" is a point inside the shape, used to make
    # sure the normal points outwards and the winding is right.
    func tri(a: Vector3, b: Vector3, c: Vector3, ca: Color, cb: Color, cc: Color, center: Vector3) -> void:
        var cr := (b - a).cross(c - a)
        if cr.length_squared() < 0.0000001:
            return
        var n := -cr.normalized()
        var mid := (a + b + c) / 3.0
        if n.dot(mid - center) < 0.0:
            var tp := b
            b = c
            c = tp
            var tcol := cb
            cb = cc
            cc = tcol
            n = -n
        var base := verts.size()
        verts.append(a)
        verts.append(b)
        verts.append(c)
        norms.append(n)
        norms.append(n)
        norms.append(n)
        cols.append(ca)
        cols.append(cb)
        cols.append(cc)
        idx.append(base)
        idx.append(base + 1)
        idx.append(base + 2)

    func to_mesh() -> ArrayMesh:
        var arrays := []
        arrays.resize(Mesh.ARRAY_MAX)
        arrays[Mesh.ARRAY_VERTEX] = verts
        arrays[Mesh.ARRAY_NORMAL] = norms
        arrays[Mesh.ARRAY_COLOR] = cols
        arrays[Mesh.ARRAY_INDEX] = idx
        var m := ArrayMesh.new()
        m.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
        return m


# ---------- geometry helpers ----------

static func frustum(b: Builder, p0: Vector3, p1: Vector3, r0: float, r1: float, segs: int, c0: Color, c1: Color, cap: bool) -> void:
    var axis := p1 - p0
    if axis.length() < 0.001:
        return
    var up := axis.normalized()
    var side := up.cross(Vector3.RIGHT)
    if side.length() < 0.2:
        side = up.cross(Vector3.FORWARD)
    side = side.normalized()
    var fwd := up.cross(side)
    var center := (p0 + p1) * 0.5
    for i in segs:
        var a0 := TAU * float(i) / float(segs)
        var a1 := TAU * float(i + 1) / float(segs)
        var d0 := side * cos(a0) + fwd * sin(a0)
        var d1 := side * cos(a1) + fwd * sin(a1)
        var b0 := p0 + d0 * r0
        var b1 := p0 + d1 * r0
        var t0 := p1 + d0 * r1
        var t1 := p1 + d1 * r1
        b.tri(b0, b1, t0, c0, c0, c1, center)
        if r1 > 0.002:
            b.tri(b1, t1, t0, c0, c1, c1, center)
            if cap:
                b.tri(p1, t0, t1, c1, c1, c1, center)


static func _mid(v: Array, cache: Dictionary, i: int, j: int) -> int:
    var key := mini(i, j) * 10000 + maxi(i, j)
    if cache.has(key):
        return int(cache[key])
    var a: Vector3 = v[i]
    var b: Vector3 = v[j]
    v.append(((a + b) * 0.5).normalized())
    var n := v.size() - 1
    cache[key] = n
    return n


static func icosphere(level: int) -> Dictionary:
    var key := "ico%d" % level
    if _cache.has(key):
        return _cache[key]
    var v: Array = []
    for p in ICO_V:
        var q: Vector3 = p
        v.append(q.normalized())
    var faces: Array = []
    for f in ICO_F:
        faces.append([int(f[0]), int(f[1]), int(f[2])])
    for l in level:
        var mid_cache := {}
        var nf: Array = []
        for f in faces:
            var a: int = f[0]
            var b: int = f[1]
            var c: int = f[2]
            var ab := _mid(v, mid_cache, a, b)
            var bc := _mid(v, mid_cache, b, c)
            var ca := _mid(v, mid_cache, c, a)
            nf.append([a, ab, ca])
            nf.append([b, bc, ab])
            nf.append([c, ca, bc])
            nf.append([ab, bc, ca])
        faces = nf
    var result := {"v": v, "f": faces}
    _cache[key] = result
    return result


# A lumpy ellipsoid (leaf cluster, bush, berry...).
static func blob(b: Builder, center: Vector3, radii: Vector3, col: Color, rng: RandomNumberGenerator, jitter: float, level: int) -> void:
    var ico := icosphere(level)
    var v: Array = ico["v"]
    var faces: Array = ico["f"]
    var pts: Array = []
    for p in v:
        var q: Vector3 = p
        var j := 1.0 + rng.randf_range(-jitter, jitter)
        pts.append(center + Vector3(q.x * radii.x, q.y * radii.y, q.z * radii.z) * j)
    for f in faces:
        var a: Vector3 = pts[f[0]]
        var bb: Vector3 = pts[f[1]]
        var c: Vector3 = pts[f[2]]
        var fy := ((a.y + bb.y + c.y) / 3.0 - center.y) / maxf(radii.y, 0.01)
        var k := fy * 0.18 + rng.randf_range(-0.05, 0.05)
        var fc := col
        if k >= 0.0:
            fc = col.lightened(minf(k, 0.35))
        else:
            fc = col.darkened(minf(-k, 0.35))
        b.tri(a, bb, c, fc, fc, fc, center)


static func _leaf(rng: RandomNumberGenerator, list: Array) -> Color:
    var c: Color = list[rng.randi() % list.size()]
    return Color(c.r, c.g, c.b, 1.0)


static func _wood(r: float, g: float, bl: float) -> Color:
    return Color(r, g, bl, 0.0)


# ---------- rocks ----------

static func rock(kind: int) -> ArrayMesh:
    var key := "rock%d" % kind
    if _cache.has(key):
        return _cache[key]
    var rng := RandomNumberGenerator.new()
    rng.seed = 9100 + kind * 37
    var noise := FastNoiseLite.new()
    noise.seed = 31 + kind * 11
    noise.noise_type = FastNoiseLite.TYPE_SIMPLEX
    noise.frequency = 0.9
    var radii := Vector3(0.9, 0.7, 0.8)
    var base := Color(0.63, 0.60, 0.54, 0.0)
    if kind == 1:
        radii = Vector3(1.5, 0.38, 1.0)
        base = Color(0.60, 0.58, 0.54, 0.0)
    elif kind == 2:
        radii = Vector3(0.55, 1.35, 0.6)
        base = Color(0.52, 0.49, 0.46, 0.0)
    var ico := icosphere(1)
    var v: Array = ico["v"]
    var faces: Array = ico["f"]
    var lift := radii.y * 0.45
    var pts: Array = []
    for p in v:
        var q: Vector3 = p
        var bump := noise.get_noise_3d(q.x * 2.0, q.y * 2.0, q.z * 2.0) * 0.30
        var pos := Vector3(q.x * radii.x, q.y * radii.y, q.z * radii.z) * (1.0 + bump)
        if pos.y < -lift:
            pos.y = -lift
        pos.y += lift
        if kind == 2:
            var tpr := 1.0 - 0.45 * clampf(pos.y / (radii.y * 1.45), 0.0, 1.0)
            pos.x *= tpr
            pos.z *= tpr
        pts.append(pos)
    var b := Builder.new()
    var center := Vector3(0.0, lift, 0.0)
    for f in faces:
        var a: Vector3 = pts[f[0]]
        var bb: Vector3 = pts[f[1]]
        var c: Vector3 = pts[f[2]]
        var fy := ((a.y + bb.y + c.y) / 3.0) / (radii.y * 1.6)
        var k := fy * 0.30 - 0.10 + rng.randf_range(-0.06, 0.06)
        var fc := base
        if k >= 0.0:
            fc = base.lightened(minf(k, 0.4))
        else:
            fc = base.darkened(minf(-k, 0.4))
        b.tri(a, bb, c, fc, fc, fc, center)
    var m := b.to_mesh()
    _cache[key] = m
    return m


# ---------- trees ----------

const OAK_LEAVES := [Color(0.20, 0.45, 0.13), Color(0.26, 0.52, 0.14), Color(0.16, 0.38, 0.12)]
const BLOSSOM_LEAVES := [Color(0.92, 0.55, 0.75), Color(0.75, 0.45, 0.85), Color(0.98, 0.72, 0.86)]
const BANYAN_LEAVES := [Color(0.45, 0.62, 0.12), Color(0.38, 0.56, 0.14), Color(0.52, 0.68, 0.18)]
const WILLOW_LEAVES := [Color(0.40, 0.58, 0.20), Color(0.34, 0.52, 0.18), Color(0.48, 0.64, 0.24)]
const SPRUCE_LEAVES := [Color(0.08, 0.28, 0.14), Color(0.10, 0.34, 0.17), Color(0.07, 0.24, 0.13)]


static func tree(t: int) -> ArrayMesh:
    var key := "tree%d" % t
    if _cache.has(key):
        return _cache[key]
    var rng := RandomNumberGenerator.new()
    rng.seed = 5000 + t * 71
    var b := Builder.new()
    match t:
        TREE_OAK:
            _round_tree(b, rng, OAK_LEAVES)
        TREE_BLOSSOM:
            _round_tree(b, rng, BLOSSOM_LEAVES)
        TREE_WILLOW:
            _willow(b, rng)
        TREE_SPRUCE:
            _spruce(b, rng)
        TREE_BANYAN:
            _banyan(b, rng)
        TREE_DEAD:
            _dead(b, rng)
        _:
            _cactus(b, rng)
    var m := b.to_mesh()
    _cache[key] = m
    return m


static func _round_tree(b: Builder, rng: RandomNumberGenerator, leaves: Array) -> void:
    var bark := _wood(0.34, 0.23, 0.13)
    var bark2 := _wood(0.26, 0.17, 0.10)
    frustum(b, Vector3(0, -0.1, 0), Vector3(0, 0.7, 0), 0.66, 0.40, 7, bark2, bark, false)
    frustum(b, Vector3(0, 0.6, 0), Vector3(0, 2.5, 0), 0.40, 0.25, 7, bark, bark, false)
    frustum(b, Vector3(0, 1.9, 0), Vector3(1.0, 3.0, 0.25), 0.15, 0.07, 5, bark, bark, false)
    frustum(b, Vector3(0, 2.0, 0), Vector3(-0.9, 3.1, -0.3), 0.15, 0.07, 5, bark, bark, false)
    frustum(b, Vector3(0, 2.2, 0), Vector3(0.2, 3.4, -0.9), 0.13, 0.06, 5, bark, bark, false)
    var spots := [
        [Vector3(0.0, 3.8, 0.0), Vector3(1.8, 1.4, 1.8)],
        [Vector3(1.2, 3.3, 0.4), Vector3(1.3, 1.05, 1.3)],
        [Vector3(-1.1, 3.4, -0.3), Vector3(1.3, 1.05, 1.3)],
        [Vector3(0.1, 3.2, 1.2), Vector3(1.2, 1.0, 1.2)],
        [Vector3(-0.2, 3.4, -1.3), Vector3(1.2, 1.0, 1.2)],
        [Vector3(0.3, 4.7, 0.1), Vector3(1.2, 0.9, 1.2)],
    ]
    for s in spots:
        var c: Vector3 = s[0]
        var r: Vector3 = s[1]
        blob(b, c, r, _leaf(rng, leaves), rng, 0.18, 0)


static func _willow(b: Builder, rng: RandomNumberGenerator) -> void:
    var bark := _wood(0.36, 0.28, 0.18)
    frustum(b, Vector3(0, -0.1, 0), Vector3(0, 1.9, 0), 0.52, 0.30, 7, bark, bark, false)
    frustum(b, Vector3(0, 1.7, 0), Vector3(0.8, 3.1, 0.1), 0.22, 0.10, 5, bark, bark, false)
    frustum(b, Vector3(0, 1.8, 0), Vector3(-0.7, 3.0, -0.2), 0.22, 0.10, 5, bark, bark, false)
    blob(b, Vector3(0.0, 3.7, 0.0), Vector3(1.7, 1.0, 1.7), _leaf(rng, WILLOW_LEAVES), rng, 0.15, 0)
    blob(b, Vector3(0.9, 3.3, 0.3), Vector3(1.2, 0.8, 1.2), _leaf(rng, WILLOW_LEAVES), rng, 0.15, 0)
    blob(b, Vector3(-0.9, 3.4, -0.3), Vector3(1.2, 0.8, 1.2), _leaf(rng, WILLOW_LEAVES), rng, 0.15, 0)
    for i in 16:
        var a := TAU * float(i) / 16.0 + rng.randf_range(-0.15, 0.15)
        var rad := rng.randf_range(1.0, 1.9)
        var top := Vector3(cos(a) * rad, 3.5 - rng.randf_range(0.0, 0.4), sin(a) * rad)
        var bottom := Vector3(top.x * 1.06, rng.randf_range(0.7, 1.7), top.z * 1.06)
        var c0 := _leaf(rng, WILLOW_LEAVES)
        var c1 := c0.lightened(0.18)
        frustum(b, top, bottom, 0.30, 0.04, 4, c0, c1, false)


static func _spruce(b: Builder, rng: RandomNumberGenerator) -> void:
    var bark := _wood(0.30, 0.20, 0.12)
    frustum(b, Vector3(0, -0.1, 0), Vector3(0, 6.2, 0), 0.30, 0.08, 6, bark, bark, false)
    for i in 7:
        var y0 := 0.9 + float(i) * 0.85
        var r := 1.9 - float(i) * 0.26
        var c0 := _leaf(rng, SPRUCE_LEAVES)
        frustum(b, Vector3(0, y0, 0), Vector3(0, y0 + 1.5, 0), r, 0.04, 8, c0.darkened(0.1), c0.lightened(0.1), false)


static func _banyan(b: Builder, rng: RandomNumberGenerator) -> void:
    var bark := _wood(0.52, 0.38, 0.28)
    var bark2 := _wood(0.38, 0.26, 0.18)
    frustum(b, Vector3(0.0, 0.0, 0.0), Vector3(0.35, 2.6, 0.1), 0.40, 0.26, 7, bark2, bark, false)
    frustum(b, Vector3(0.4, 0.0, 0.3), Vector3(0.0, 2.4, -0.1), 0.32, 0.22, 7, bark2, bark, false)
    frustum(b, Vector3(-0.35, 0.0, -0.2), Vector3(-0.1, 2.5, 0.3), 0.30, 0.22, 7, bark2, bark, false)
    for i in 5:
        var a := TAU * float(i) / 5.0 + 0.3
        frustum(b, Vector3(0, 0.45, 0), Vector3(cos(a) * 1.2, -0.05, sin(a) * 1.2), 0.24, 0.05, 5, bark, bark2, false)
    frustum(b, Vector3(0, 2.4, 0), Vector3(2.2, 3.2, 0.5), 0.18, 0.08, 5, bark, bark, false)
    frustum(b, Vector3(0, 2.4, 0), Vector3(-2.0, 3.1, -0.4), 0.18, 0.08, 5, bark, bark, false)
    frustum(b, Vector3(0, 2.4, 0), Vector3(0.5, 3.3, 2.0), 0.18, 0.08, 5, bark, bark, false)
    frustum(b, Vector3(0, 2.4, 0), Vector3(-0.3, 3.2, -2.1), 0.18, 0.08, 5, bark, bark, false)
    var spots := [
        Vector3(0.0, 3.9, 0.0), Vector3(2.0, 3.6, 0.4), Vector3(-1.9, 3.5, -0.3),
        Vector3(0.4, 3.6, 1.9), Vector3(-0.2, 3.5, -2.0),
    ]
    for c in spots:
        blob(b, c, Vector3(1.55, 0.95, 1.55), _leaf(rng, BANYAN_LEAVES), rng, 0.2, 0)


static func _dead(b: Builder, rng: RandomNumberGenerator) -> void:
    var bark := _wood(0.36, 0.31, 0.27)
    var bark2 := _wood(0.28, 0.24, 0.21)
    frustum(b, Vector3(0, -0.1, 0), Vector3(0, 3.6, 0), 0.34, 0.10, 6, bark2, bark, false)
    frustum(b, Vector3(0, 2.0, 0), Vector3(1.1, 3.3, 0.3), 0.12, 0.03, 4, bark, bark, false)
    frustum(b, Vector3(0, 2.4, 0), Vector3(-1.0, 3.7, -0.2), 0.11, 0.03, 4, bark, bark, false)
    frustum(b, Vector3(0, 1.5, 0), Vector3(0.3, 2.6, 1.0), 0.10, 0.03, 4, bark, bark, false)
    frustum(b, Vector3(0, 2.9, 0), Vector3(-0.4, 4.2, 0.5), 0.08, 0.02, 4, bark, bark, false)
    frustum(b, Vector3(0, 1.2, 0), Vector3(-0.8, 2.0, -0.7), 0.09, 0.03, 4, bark, bark, false)


static func _cactus(b: Builder, rng: RandomNumberGenerator) -> void:
    var g0 := _wood(0.22, 0.46, 0.18)
    var g1 := _wood(0.30, 0.55, 0.22)
    frustum(b, Vector3(0, -0.05, 0), Vector3(0, 2.5, 0), 0.30, 0.24, 6, g0, g1, true)
    frustum(b, Vector3(0, 1.1, 0), Vector3(0.75, 1.1, 0.0), 0.15, 0.15, 5, g0, g1, false)
    frustum(b, Vector3(0.75, 1.1, 0), Vector3(0.75, 2.0, 0.0), 0.15, 0.12, 5, g0, g1, true)
    frustum(b, Vector3(0, 1.5, 0), Vector3(-0.65, 1.5, 0.0), 0.13, 0.13, 5, g0, g1, false)
    frustum(b, Vector3(-0.65, 1.5, 0), Vector3(-0.65, 2.2, 0.0), 0.13, 0.10, 5, g0, g1, true)


static func sapling() -> ArrayMesh:
    if _cache.has("sapling"):
        return _cache["sapling"]
    var rng := RandomNumberGenerator.new()
    rng.seed = 77
    var b := Builder.new()
    var bark := _wood(0.38, 0.27, 0.15)
    frustum(b, Vector3(0, 0, 0), Vector3(0, 0.7, 0), 0.05, 0.03, 5, bark, bark, false)
    blob(b, Vector3(0, 1.0, 0), Vector3(0.35, 0.3, 0.35), _leaf(rng, OAK_LEAVES), rng, 0.15, 0)
    blob(b, Vector3(0.15, 0.75, 0.1), Vector3(0.22, 0.18, 0.22), _leaf(rng, OAK_LEAVES), rng, 0.15, 0)
    var m := b.to_mesh()
    _cache["sapling"] = m
    return m


# ---------- small things ----------

static func bush(full: bool) -> ArrayMesh:
    var key := "bush_full" if full else "bush_plain"
    if _cache.has(key):
        return _cache[key]
    var rng := RandomNumberGenerator.new()
    rng.seed = 321
    var b := Builder.new()
    var leaf := [Color(0.20, 0.44, 0.14), Color(0.26, 0.50, 0.16), Color(0.17, 0.38, 0.13)]
    blob(b, Vector3(0.0, 0.42, 0.0), Vector3(0.62, 0.45, 0.60), _leaf(rng, leaf), rng, 0.16, 0)
    blob(b, Vector3(0.45, 0.32, 0.18), Vector3(0.42, 0.32, 0.40), _leaf(rng, leaf), rng, 0.16, 0)
    blob(b, Vector3(-0.42, 0.34, -0.12), Vector3(0.44, 0.34, 0.42), _leaf(rng, leaf), rng, 0.16, 0)
    blob(b, Vector3(0.05, 0.30, -0.45), Vector3(0.40, 0.30, 0.38), _leaf(rng, leaf), rng, 0.16, 0)
    if full:
        var berry := Color(0.82, 0.10, 0.14, 0.0)
        var spots := [
            Vector3(0.30, 0.78, 0.18), Vector3(-0.22, 0.82, 0.24), Vector3(0.05, 0.92, -0.12),
            Vector3(0.62, 0.50, 0.30), Vector3(-0.58, 0.55, -0.05), Vector3(0.10, 0.58, 0.55),
        ]
        for s in spots:
            blob(b, s, Vector3(0.07, 0.07, 0.07), berry, rng, 0.1, 0)
    var m := b.to_mesh()
    _cache[key] = m
    return m


static func branch() -> ArrayMesh:
    if _cache.has("branch"):
        return _cache["branch"]
    var b := Builder.new()
    var bark := _wood(0.38, 0.27, 0.15)
    var bark2 := _wood(0.30, 0.21, 0.12)
    frustum(b, Vector3(-0.55, 0.07, 0.0), Vector3(0.55, 0.10, 0.05), 0.05, 0.035, 5, bark2, bark, true)
    frustum(b, Vector3(0.05, 0.09, 0.02), Vector3(0.28, 0.20, 0.30), 0.025, 0.012, 4, bark, bark, true)
    frustum(b, Vector3(-0.2, 0.08, 0.01), Vector3(-0.35, 0.18, -0.25), 0.022, 0.010, 4, bark, bark, true)
    var m := b.to_mesh()
    _cache["branch"] = m
    return m


static func fiber() -> ArrayMesh:
    if _cache.has("fiber"):
        return _cache["fiber"]
    var rng := RandomNumberGenerator.new()
    rng.seed = 654
    var b := Builder.new()
    for i in 8:
        var a := TAU * float(i) / 8.0 + rng.randf_range(-0.3, 0.3)
        var base := Vector3(cos(a) * 0.08, 0.0, sin(a) * 0.08)
        var tip := Vector3(cos(a) * rng.randf_range(0.22, 0.42), rng.randf_range(0.6, 1.0), sin(a) * rng.randf_range(0.22, 0.42))
        var c0 := Color(0.34, 0.50, 0.16, 1.0)
        var c1 := Color(0.58, 0.72, 0.28, 1.0)
        frustum(b, base, tip, 0.035, 0.004, 3, c0, c1, false)
    var m := b.to_mesh()
    _cache["fiber"] = m
    return m
