extends RefCounted

# Optional real assets. Put files in the repository under  assets/  and the game
# uses them automatically (nothing breaks if they are missing):
#   assets/textures/ground.jpg   seamless ground texture (it is tinted by the biome colour)
# More slots (models, sounds) are added the same way.

static func texture(base: String) -> Texture2D:
    for ext in ["jpg", "jpeg", "png", "webp"]:
        var path := "res://assets/%s.%s" % [base, ext]
        if ResourceLoader.exists(path):
            var t = load(path)
            if t is Texture2D:
                return t
    return null
