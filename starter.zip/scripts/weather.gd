extends Node3D

# Rain, snow and ash. Particles follow the player. While the player stands
# under a roof the precipitation stops and the lens slowly dries.
# The sky / fog / light changes are applied by daynight.gd using the values below.

var kind := "clear"
var player = null
var audio = null
var particles: CPUParticles3D
var wet := 0.0
var cloud := 0.0
var dim := 1.0
var fog_mul := 1.0
var sky_dark := 0.0
var grey := 0.0
var flash_amt := 0.0
var sheltered := false
var shelter_t := 0.0
var rain_vol := 0.0
var flash := 0.0
var thunder_timer := 12.0
var thunder_delay := -1.0
var height := 16.0


func setup(map: Dictionary, p, a) -> void:
    kind = String(map["weather"])
    player = p
    audio = a
    match kind:
        "rain":
            cloud = 0.9
            dim = 0.45
            fog_mul = 2.4
            sky_dark = 0.45
            grey = 0.6
        "snow":
            cloud = 0.6
            dim = 0.75
            fog_mul = 1.8
            sky_dark = 0.15
            grey = 0.5
        "ash":
            cloud = 0.7
            dim = 0.6
            fog_mul = 1.5
            sky_dark = 0.2
            grey = 0.0
    if kind != "clear":
        _build_particles()


func _build_particles() -> void:
    particles = CPUParticles3D.new()
    particles.top_level = true
    particles.local_coords = false
    particles.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
    particles.custom_aabb = AABB(Vector3(-60, -60, -60), Vector3(120, 120, 120))
    particles.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    var mat := StandardMaterial3D.new()
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    match kind:
        "rain":
            var bm := BoxMesh.new()
            bm.size = Vector3(0.012, 0.8, 0.012)
            mat.albedo_color = Color(0.78, 0.84, 0.92, 0.45)
            bm.material = mat
            particles.mesh = bm
            particles.amount = 800
            particles.lifetime = 1.1
            particles.direction = Vector3(0.12, -1.0, 0.04)
            particles.spread = 2.0
            particles.initial_velocity_min = 25.0
            particles.initial_velocity_max = 30.0
            particles.gravity = Vector3.ZERO
            particles.particle_flag_align_y = true
            particles.emission_box_extents = Vector3(15.0, 0.5, 15.0)
            height = 16.0
        "snow":
            var sm := SphereMesh.new()
            sm.radius = 0.035
            sm.height = 0.07
            sm.radial_segments = 5
            sm.rings = 3
            mat.albedo_color = Color(1.0, 1.0, 1.0, 0.9)
            sm.material = mat
            particles.mesh = sm
            particles.amount = 600
            particles.lifetime = 6.0
            particles.direction = Vector3(0.15, -1.0, 0.0)
            particles.spread = 30.0
            particles.initial_velocity_min = 1.2
            particles.initial_velocity_max = 2.2
            particles.gravity = Vector3(0.4, -0.1, 0.2)
            particles.scale_amount_min = 0.6
            particles.scale_amount_max = 1.4
            particles.emission_box_extents = Vector3(18.0, 0.5, 18.0)
            height = 12.0
        "ash":
            var am := SphereMesh.new()
            am.radius = 0.045
            am.height = 0.09
            am.radial_segments = 5
            am.rings = 3
            mat.albedo_color = Color(0.75, 0.45, 0.30, 0.85)
            am.material = mat
            particles.mesh = am
            particles.amount = 350
            particles.lifetime = 8.0
            particles.direction = Vector3(0.3, -0.4, 0.0)
            particles.spread = 40.0
            particles.initial_velocity_min = 0.5
            particles.initial_velocity_max = 1.4
            particles.gravity = Vector3(0.4, -0.15, 0.1)
            particles.emission_box_extents = Vector3(20.0, 0.5, 20.0)
            height = 10.0
    add_child(particles)
    particles.preprocess = particles.lifetime
    particles.emitting = true


func _process(delta: float) -> void:
    if kind == "clear" or player == null or particles == null:
        return
    particles.global_position = player.global_position + Vector3(0.0, height, 0.0)

    shelter_t -= delta
    if shelter_t <= 0.0:
        shelter_t = 0.25
        var from: Vector3 = player.global_position + Vector3(0.0, 1.8, 0.0)
        var q := PhysicsRayQueryParameters3D.create(from, from + Vector3(0.0, 8.0, 0.0))
        q.exclude = [player.get_rid()]
        sheltered = not get_world_3d().direct_space_state.intersect_ray(q).is_empty()
        particles.emitting = not sheltered

    if kind == "rain" or kind == "snow":
        if sheltered:
            wet = move_toward(wet, 0.0, delta * 0.08)
        else:
            var rate := 0.09
            if kind == "rain":
                rate = 0.16
            wet = move_toward(wet, 1.0, delta * rate)

    if kind == "rain":
        var target_vol := 0.38
        if sheltered:
            target_vol = 0.12
        rain_vol = move_toward(rain_vol, target_vol, delta * 0.5)
        if audio != null:
            audio.set_rain(rain_vol)
        thunder_timer -= delta
        if thunder_timer <= 0.0:
            thunder_timer = randf_range(14.0, 38.0)
            flash = 1.0
            thunder_delay = randf_range(0.5, 2.2)
        if thunder_delay >= 0.0:
            thunder_delay -= delta
            if thunder_delay < 0.0 and audio != null:
                audio.thunder()
        flash = move_toward(flash, 0.0, delta * 3.0)
        flash_amt = maxf(flash * (0.6 + 0.4 * sin(Time.get_ticks_msec() * 0.06)), 0.0)
