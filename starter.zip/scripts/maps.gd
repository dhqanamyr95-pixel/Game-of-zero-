extends RefCounted

# The game is one big world; this is its sky, light and water setup.

static func all() -> Array:
    return [
        {
            "id": "world",
            "name": "World",
            "weather": "clear",
            "seasonal": true,
            "seed": 777,
            "sky_top": Color(0.28, 0.50, 0.85), "sky_hor": Color(0.82, 0.84, 0.80),
            "fog": Color(0.78, 0.82, 0.80), "fog_d": 0.011,
            "water": Color(0.10, 0.38, 0.46, 0.82),
            "sun_energy": 1.4, "sun_color": Color(1.0, 0.95, 0.85),
            "sun_rot": Vector3(-42.0, -30.0, 0.0),
        },
    ]


static func get_map(id: String) -> Dictionary:
    for m in all():
        if m["id"] == id:
            return m
    return all()[0]
