extends RefCounted

# All playable maps. Each map is just data: the world builder reads these values.

static func all() -> Array:
    return [
        {
            "id": "savanna",
            "weather": "clear",
            "name": "Savanna - Year Zero",
            "desc": "Warm plains, acacia trees, rocky outcrops. Where it all begins.",
            "seed": 11, "freq": 0.008, "amp": 5.0, "base": 2.2,
            "sand": Color(0.80, 0.72, 0.50), "grass": Color(0.58, 0.54, 0.24),
            "grass2": Color(0.44, 0.46, 0.20), "rock": Color(0.50, 0.44, 0.38),
            "sky_top": Color(0.28, 0.50, 0.85), "sky_hor": Color(0.88, 0.82, 0.68),
            "fog": Color(0.86, 0.80, 0.68), "fog_d": 0.0035,
            "tree_count": 70, "tree_shape": "round",
            "tree_col": Color(0.33, 0.40, 0.13), "trunk_col": Color(0.36, 0.26, 0.16),
            "rock_count": 90, "water": Color(0.10, 0.40, 0.45, 0.85),
            "sun_energy": 1.4, "sun_color": Color(1.0, 0.95, 0.85),
            "sun_rot": Vector3(-38.0, -30.0, 0.0),
        },
        {
            "id": "forest",
            "weather": "rain",
            "name": "Ancient Forest",
            "desc": "Dense woodland, thick fog, deep green valleys.",
            "seed": 22, "freq": 0.012, "amp": 8.0, "base": 3.0,
            "sand": Color(0.45, 0.40, 0.28), "grass": Color(0.16, 0.36, 0.12),
            "grass2": Color(0.10, 0.27, 0.10), "rock": Color(0.35, 0.34, 0.32),
            "sky_top": Color(0.35, 0.55, 0.75), "sky_hor": Color(0.65, 0.76, 0.72),
            "fog": Color(0.55, 0.68, 0.62), "fog_d": 0.010,
            "tree_count": 420, "tree_shape": "round",
            "tree_col": Color(0.10, 0.30, 0.08), "trunk_col": Color(0.28, 0.20, 0.12),
            "rock_count": 70, "water": Color(0.08, 0.30, 0.30, 0.85),
            "sun_energy": 1.1, "sun_color": Color(0.95, 1.0, 0.9),
            "sun_rot": Vector3(-50.0, -20.0, 0.0),
        },
        {
            "id": "iceage",
            "weather": "snow",
            "name": "Ice Age",
            "desc": "Frozen tundra, snow, pine trees and bitter wind.",
            "seed": 33, "freq": 0.010, "amp": 9.0, "base": 4.0,
            "sand": Color(0.82, 0.88, 0.94), "grass": Color(0.92, 0.95, 1.0),
            "grass2": Color(0.78, 0.85, 0.93), "rock": Color(0.42, 0.47, 0.55),
            "sky_top": Color(0.50, 0.66, 0.90), "sky_hor": Color(0.85, 0.91, 0.97),
            "fog": Color(0.80, 0.88, 0.96), "fog_d": 0.012,
            "tree_count": 160, "tree_shape": "cone",
            "tree_col": Color(0.12, 0.27, 0.22), "trunk_col": Color(0.25, 0.18, 0.14),
            "rock_count": 110, "water": Color(0.15, 0.35, 0.50, 0.9),
            "sun_energy": 1.1, "sun_color": Color(0.9, 0.95, 1.0),
            "sun_rot": Vector3(-28.0, -40.0, 0.0),
        },
        {
            "id": "desert",
            "weather": "clear",
            "name": "Burning Desert",
            "desc": "Endless dunes, scorching sun, almost no shelter.",
            "seed": 44, "freq": 0.006, "amp": 9.0, "base": 3.0,
            "sand": Color(0.88, 0.72, 0.44), "grass": Color(0.82, 0.64, 0.38),
            "grass2": Color(0.74, 0.56, 0.32), "rock": Color(0.55, 0.38, 0.28),
            "sky_top": Color(0.32, 0.58, 0.92), "sky_hor": Color(0.95, 0.85, 0.65),
            "fog": Color(0.92, 0.80, 0.62), "fog_d": 0.006,
            "tree_count": 30, "tree_shape": "dead",
            "tree_col": Color(0.3, 0.3, 0.1), "trunk_col": Color(0.40, 0.30, 0.20),
            "rock_count": 120, "water": Color(0.12, 0.45, 0.50, 0.85),
            "sun_energy": 1.8, "sun_color": Color(1.0, 0.93, 0.78),
            "sun_rot": Vector3(-65.0, -30.0, 0.0),
        },
        {
            "id": "volcanic",
            "weather": "ash",
            "name": "Volcanic Island",
            "desc": "Black rock, ash sky and glowing lava seas.",
            "seed": 55, "freq": 0.014, "amp": 14.0, "base": 4.0,
            "sand": Color(0.20, 0.18, 0.18), "grass": Color(0.16, 0.14, 0.14),
            "grass2": Color(0.28, 0.20, 0.18), "rock": Color(0.10, 0.08, 0.08),
            "sky_top": Color(0.22, 0.10, 0.10), "sky_hor": Color(0.78, 0.36, 0.20),
            "fog": Color(0.38, 0.20, 0.15), "fog_d": 0.010,
            "tree_count": 20, "tree_shape": "dead",
            "tree_col": Color(0.1, 0.1, 0.1), "trunk_col": Color(0.12, 0.10, 0.09),
            "rock_count": 160, "water": Color(0.85, 0.28, 0.05, 0.92),
            "sun_energy": 0.9, "sun_color": Color(1.0, 0.65, 0.4),
            "sun_rot": Vector3(-25.0, -50.0, 0.0),
        },
    ]


static func get_map(id: String) -> Dictionary:
    for m in all():
        if m["id"] == id:
            return m
    return all()[0]
