extends RefCounted

# Gem packs. The prices are in toman: change them here, in one place.
# Real payment (Myket) is not connected yet: purchase() says so.

const PACKS := [
    {"id": "gems_10", "gems": 10, "toman": 1000},
    {"id": "gems_50", "gems": 50, "toman": 5000},
    {"id": "gems_100", "gems": 100, "toman": 10000},
    {"id": "gems_250", "gems": 250, "toman": 25000},
    {"id": "gems_500", "gems": 500, "toman": 50000},
    {"id": "gems_1000", "gems": 1000, "toman": 100000},
    {"id": "gems_2000", "gems": 2000, "toman": 200000},
]


# Later this will open the Myket payment screen. For now it only reports that
# payment is unavailable.
static func purchase(pack_id: String) -> String:
    return "unavailable"


static func format_number(n: int) -> String:
    var s := str(n)
    var out := ""
    var count := 0
    for i in range(s.length() - 1, -1, -1):
        out = s[i] + out
        count += 1
        if count % 3 == 0 and i > 0:
            out = "," + out
    return out
