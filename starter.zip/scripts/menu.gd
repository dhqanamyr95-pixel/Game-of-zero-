extends Control

signal map_chosen(map_id: String)
signal continue_chosen

const Maps = preload("res://scripts/maps.gd")
const I18n = preload("res://scripts/i18n.gd")
const Save = preload("res://scripts/save.gd")

var show_langs := false
var content: Control = null


func _ready() -> void:
    set_anchors_preset(Control.PRESET_FULL_RECT)
    var bg := ColorRect.new()
    bg.color = Color(0.07, 0.06, 0.05)
    add_child(bg)
    bg.set_anchors_preset(Control.PRESET_FULL_RECT)
    _build()


func _build() -> void:
    if content != null:
        remove_child(content)
        content.queue_free()
    var margin := MarginContainer.new()
    content = margin
    add_child(margin)
    margin.set_anchors_preset(Control.PRESET_FULL_RECT)
    if I18n.is_rtl():
        margin.layout_direction = Control.LAYOUT_DIRECTION_RTL
    else:
        margin.layout_direction = Control.LAYOUT_DIRECTION_LTR
    margin.add_theme_constant_override("margin_left", 56)
    margin.add_theme_constant_override("margin_right", 56)
    margin.add_theme_constant_override("margin_top", 36)
    margin.add_theme_constant_override("margin_bottom", 36)

    var box := VBoxContainer.new()
    box.add_theme_constant_override("separation", 14)
    margin.add_child(box)

    var head := HBoxContainer.new()
    box.add_child(head)

    var title := Label.new()
    title.text = "SOULKEEN: YEAR ZERO"
    title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    title.add_theme_font_size_override("font_size", 50)
    title.add_theme_color_override("font_color", Color(0.95, 0.75, 0.35))
    head.add_child(title)

    var lang_btn := Button.new()
    lang_btn.text = "%s: %s" % [I18n.t("language"), I18n.native_name()]
    lang_btn.custom_minimum_size = Vector2(0, 64)
    lang_btn.add_theme_font_size_override("font_size", 22)
    _style(lang_btn, false)
    lang_btn.pressed.connect(_toggle_langs)
    head.add_child(lang_btn)

    var sub := Label.new()
    if show_langs:
        sub.text = I18n.t("language")
    else:
        sub.text = I18n.t("choose_world")
    sub.add_theme_font_size_override("font_size", 24)
    sub.add_theme_color_override("font_color", Color(0.8, 0.78, 0.72))
    box.add_child(sub)

    if not show_langs and Save.exists():
        var data := Save.read()
        if data.has("map"):
            var cb := Button.new()
            cb.text = "%s  -  %s" % [I18n.t("continue"), I18n.t("map_" + String(data["map"]))]
            cb.custom_minimum_size = Vector2(0, 76)
            cb.add_theme_font_size_override("font_size", 26)
            _style(cb, true)
            cb.pressed.connect(_on_continue)
            box.add_child(cb)

    var scroll := ScrollContainer.new()
    scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
    scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    box.add_child(scroll)

    var grid := GridContainer.new()
    grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    grid.add_theme_constant_override("h_separation", 16)
    grid.add_theme_constant_override("v_separation", 16)
    scroll.add_child(grid)

    if show_langs:
        grid.columns = 3
        for l in I18n.LANGS:
            var b := Button.new()
            b.text = String(l[1])
            b.custom_minimum_size = Vector2(0, 80)
            b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
            b.add_theme_font_size_override("font_size", 26)
            _style(b, l[0] == I18n.current)
            b.pressed.connect(_on_lang.bind(String(l[0])))
            grid.add_child(b)
    else:
        grid.columns = 2
        for m in Maps.all():
            var id := String(m["id"])
            var btn := Button.new()
            btn.text = "%s\n%s" % [I18n.t("map_" + id), I18n.t("map_" + id + "_d")]
            btn.custom_minimum_size = Vector2(0, 120)
            btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
            btn.add_theme_font_size_override("font_size", 22)
            btn.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
            _style(btn, false)
            btn.pressed.connect(_on_pick.bind(id))
            grid.add_child(btn)


func _style(btn: Button, highlight: bool) -> void:
    var border := Color(0.55, 0.42, 0.22)
    if highlight:
        border = Color(1.0, 0.85, 0.45)
    var normal := _box(Color(0.16, 0.13, 0.10), border)
    var hover := _box(Color(0.22, 0.17, 0.12), Color(0.95, 0.75, 0.35))
    var pressed := _box(Color(0.30, 0.22, 0.12), Color(1.0, 0.85, 0.45))
    btn.add_theme_stylebox_override("normal", normal)
    btn.add_theme_stylebox_override("hover", hover)
    btn.add_theme_stylebox_override("pressed", pressed)
    btn.add_theme_stylebox_override("focus", normal)
    btn.add_theme_color_override("font_color", Color(0.95, 0.9, 0.8))


func _box(fill: Color, border: Color) -> StyleBoxFlat:
    var s := StyleBoxFlat.new()
    s.bg_color = fill
    s.border_color = border
    s.set_border_width_all(3)
    s.set_corner_radius_all(14)
    s.content_margin_left = 18
    s.content_margin_right = 18
    s.content_margin_top = 12
    s.content_margin_bottom = 12
    return s


func _toggle_langs() -> void:
    show_langs = not show_langs
    _build()


func _on_lang(code: String) -> void:
    I18n.set_lang(code)
    show_langs = false
    _build()


func _on_continue() -> void:
    continue_chosen.emit()


func _on_pick(id: String) -> void:
    map_chosen.emit(id)
