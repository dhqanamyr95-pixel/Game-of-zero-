extends Control

# Main menu: cinematic background (your own picture, see BG_PATHS), dark shade for
# readable text, floating embers, big touch-friendly buttons and three pages:
#   main -> worlds / languages.  Arabic and Persian mirror the whole layout.
#
# To use your own background picture, upload a file named  menu_background.jpg
# (or .png) to the root of the GitHub repository (next to starter.zip).
# Best size: 2400 x 1080, JPG, under 2 MB. Without it a built-in glow is used.

signal map_chosen(map_id: String)
signal continue_chosen

const Maps = preload("res://scripts/maps.gd")
const I18n = preload("res://scripts/i18n.gd")
const Save = preload("res://scripts/save.gd")
const Settings = preload("res://scripts/settings.gd")

const BG_PATHS := [
    "res://menu_background.jpg",
    "res://menu_background.jpeg",
    "res://menu_background.png",
    "res://images/menu_background.jpg",
    "res://images/menu_background.png",
]
const GOLD := Color(0.95, 0.75, 0.35)
const ACCENT := {
    "savanna": Color(0.92, 0.70, 0.28),
    "forest": Color(0.30, 0.72, 0.36),
    "iceage": Color(0.52, 0.78, 1.00),
    "desert": Color(0.96, 0.56, 0.20),
    "volcanic": Color(0.92, 0.26, 0.14),
}

var page := "main"
var content: Control = null


func _ready() -> void:
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    _rebuild_all()


# ---------- building ----------

func _rebuild_all() -> void:
    for c in get_children():
        remove_child(c)
        c.queue_free()
    content = null
    _build_background()
    _build_content()


func _go(p: String) -> void:
    page = p
    _build_content()


func _grad(colors: Array, offsets: Array, from: Vector2, to: Vector2, radial: bool) -> GradientTexture2D:
    var g := Gradient.new()
    g.colors = PackedColorArray(colors)
    g.offsets = PackedFloat32Array(offsets)
    var gt := GradientTexture2D.new()
    gt.gradient = g
    gt.width = 512
    gt.height = 256
    gt.fill_from = from
    gt.fill_to = to
    if radial:
        gt.fill = GradientTexture2D.FILL_RADIAL
    else:
        gt.fill = GradientTexture2D.FILL_LINEAR
    return gt


func _full_rect(tex: Texture2D, stretch: int) -> TextureRect:
    var r := TextureRect.new()
    add_child(r)
    r.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    r.mouse_filter = Control.MOUSE_FILTER_IGNORE
    r.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    r.stretch_mode = stretch
    r.texture = tex
    return r


func _build_background() -> void:
    var tex: Texture2D = null
    for p in BG_PATHS:
        if ResourceLoader.exists(p):
            var loaded = load(p)
            if loaded is Texture2D:
                tex = loaded
                break
    if tex != null:
        _full_rect(tex, TextureRect.STRETCH_KEEP_ASPECT_COVERED)
    else:
        var glow := _grad([Color(0.32, 0.19, 0.07), Color(0.05, 0.04, 0.03)], [0.0, 1.0], Vector2(0.7, 0.4), Vector2(1.3, 0.4), true)
        _full_rect(glow, TextureRect.STRETCH_SCALE)

    # dark shade on the text side, and at the bottom
    var side := _grad([Color(0, 0, 0, 0.88), Color(0, 0, 0, 0.55), Color(0, 0, 0, 0.05)], [0.0, 0.42, 1.0], Vector2(0.0, 0.0), Vector2(1.0, 0.0), false)
    var side_rect := _full_rect(side, TextureRect.STRETCH_SCALE)
    if I18n.is_rtl():
        side_rect.flip_h = true
    var bottom := _grad([Color(0, 0, 0, 0.0), Color(0, 0, 0, 0.7)], [0.0, 1.0], Vector2(0.0, 0.55), Vector2(0.0, 1.0), false)
    _full_rect(bottom, TextureRect.STRETCH_SCALE)
    _add_embers()


func _add_embers() -> void:
    var vp := get_viewport().get_visible_rect().size
    var p := CPUParticles2D.new()
    p.position = Vector2(vp.x * 0.5, vp.y + 10.0)
    p.amount = 50
    p.lifetime = 9.0
    p.preprocess = 9.0
    p.emission_shape = CPUParticles2D.EMISSION_SHAPE_RECTANGLE
    p.emission_rect_extents = Vector2(vp.x * 0.5, 4.0)
    p.direction = Vector2(0, -1)
    p.spread = 25.0
    p.gravity = Vector2(0, -6)
    p.initial_velocity_min = 20.0
    p.initial_velocity_max = 60.0
    p.scale_amount_min = 2.0
    p.scale_amount_max = 5.0
    p.color = Color(1.0, 0.72, 0.35, 0.55)
    add_child(p)
    p.emitting = true


func _build_content() -> void:
    if content != null:
        remove_child(content)
        content.queue_free()
    var margin := MarginContainer.new()
    content = margin
    add_child(margin)
    margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    if I18n.is_rtl():
        margin.layout_direction = Control.LAYOUT_DIRECTION_RTL
    else:
        margin.layout_direction = Control.LAYOUT_DIRECTION_LTR
    margin.add_theme_constant_override("margin_left", 90)
    margin.add_theme_constant_override("margin_right", 90)
    margin.add_theme_constant_override("margin_top", 56)
    margin.add_theme_constant_override("margin_bottom", 44)
    match page:
        "worlds":
            _page_worlds(margin)
        "langs":
            _page_langs(margin)
        "settings":
            _page_settings(margin)
        _:
            _page_main(margin)
    margin.modulate.a = 0.0
    var tw := create_tween()
    tw.tween_property(margin, "modulate:a", 1.0, 0.4)


# ---------- pages ----------

func _page_main(root: Control) -> void:
    var row := HBoxContainer.new()
    root.add_child(row)

    var col := VBoxContainer.new()
    col.custom_minimum_size = Vector2(560, 0)
    col.alignment = BoxContainer.ALIGNMENT_CENTER
    col.add_theme_constant_override("separation", 16)
    row.add_child(col)

    var spacer := Control.new()
    spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    row.add_child(spacer)

    var title := Label.new()
    title.text = "SOULKEEN"
    title.add_theme_font_size_override("font_size", 78)
    title.add_theme_color_override("font_color", GOLD)
    title.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.7))
    title.add_theme_constant_override("shadow_offset_x", 3)
    title.add_theme_constant_override("shadow_offset_y", 4)
    col.add_child(title)

    var line := ColorRect.new()
    line.color = GOLD
    line.custom_minimum_size = Vector2(130, 4)
    line.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
    col.add_child(line)

    var gap := Control.new()
    gap.custom_minimum_size = Vector2(0, 26)
    col.add_child(gap)

    var has_save := false
    var save_map := ""
    if Save.exists():
        var data := Save.read()
        if data.has("map"):
            has_save = true
            save_map = String(data["map"])

    if has_save:
        var cb := _btn("%s  -  %s" % [I18n.t("continue"), I18n.t("map_" + save_map)], true)
        cb.pressed.connect(_on_continue)
        col.add_child(cb)
    var pb := _btn(I18n.t("play"), not has_save)
    pb.pressed.connect(_go.bind("worlds"))
    col.add_child(pb)
    var sb := _btn(I18n.t("settings"), false)
    sb.pressed.connect(_go.bind("settings"))
    col.add_child(sb)
    var lb := _btn("%s:  %s" % [I18n.t("language"), I18n.native_name()], false)
    lb.pressed.connect(_go.bind("langs"))
    col.add_child(lb)

    var ver := Label.new()
    ver.text = "v0.8"
    ver.add_theme_font_size_override("font_size", 18)
    ver.add_theme_color_override("font_color", Color(1, 1, 1, 0.35))
    ver.size_flags_vertical = Control.SIZE_SHRINK_END
    ver.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
    root.add_child(ver)


func _page_header(root_col: VBoxContainer, title_text: String) -> void:
    var head := HBoxContainer.new()
    head.add_theme_constant_override("separation", 24)
    root_col.add_child(head)
    var back := _btn(I18n.t("back"), false)
    back.custom_minimum_size = Vector2(190, 64)
    back.pressed.connect(_go.bind("main"))
    head.add_child(back)
    var t := Label.new()
    t.text = title_text
    t.add_theme_font_size_override("font_size", 40)
    t.add_theme_color_override("font_color", GOLD)
    t.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    head.add_child(t)


func _page_worlds(root: Control) -> void:
    var col := VBoxContainer.new()
    col.add_theme_constant_override("separation", 30)
    root.add_child(col)
    _page_header(col, I18n.t("choose_world"))

    var row := HBoxContainer.new()
    row.size_flags_vertical = Control.SIZE_EXPAND_FILL
    row.add_theme_constant_override("separation", 18)
    col.add_child(row)

    for m in Maps.all():
        var id := String(m["id"])
        var accent: Color = ACCENT.get(id, GOLD)
        var card := Button.new()
        card.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        card.size_flags_vertical = Control.SIZE_EXPAND_FILL
        card.custom_minimum_size = Vector2(0, 330)
        _style(card, false, accent)
        row.add_child(card)

        var inner := VBoxContainer.new()
        inner.mouse_filter = Control.MOUSE_FILTER_IGNORE
        inner.add_theme_constant_override("separation", 12)
        card.add_child(inner)
        inner.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT, Control.PRESET_MODE_MINSIZE, 20)

        var bar := ColorRect.new()
        bar.color = accent
        bar.custom_minimum_size = Vector2(0, 8)
        bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
        inner.add_child(bar)

        var name_label := Label.new()
        name_label.text = I18n.t("map_" + id)
        name_label.add_theme_font_size_override("font_size", 30)
        name_label.add_theme_color_override("font_color", accent)
        name_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
        name_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
        inner.add_child(name_label)

        var desc := Label.new()
        desc.text = I18n.t("map_" + id + "_d")
        desc.add_theme_font_size_override("font_size", 20)
        desc.add_theme_color_override("font_color", Color(0.92, 0.9, 0.85, 0.9))
        desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
        desc.mouse_filter = Control.MOUSE_FILTER_IGNORE
        inner.add_child(desc)

        card.pressed.connect(_on_pick.bind(id))


func _page_settings(root: Control) -> void:
    var col := VBoxContainer.new()
    col.add_theme_constant_override("separation", 26)
    root.add_child(col)
    _page_header(col, I18n.t("settings"))

    var q := Label.new()
    q.text = I18n.t("quality")
    q.add_theme_font_size_override("font_size", 28)
    q.add_theme_color_override("font_color", Color(0.92, 0.9, 0.85))
    col.add_child(q)

    var qrow := HBoxContainer.new()
    qrow.add_theme_constant_override("separation", 14)
    col.add_child(qrow)
    for opt in ["auto", "high", "medium", "low"]:
        var b := _btn(I18n.t("q_" + opt), Settings.mode == opt)
        b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        b.pressed.connect(_on_quality.bind(opt))
        qrow.add_child(b)

    var tb := _btn(I18n.t("replay_tutorial"), false)
    tb.pressed.connect(_on_replay_tutorial)
    col.add_child(tb)


func _page_langs(root: Control) -> void:
    var col := VBoxContainer.new()
    col.add_theme_constant_override("separation", 30)
    root.add_child(col)
    _page_header(col, I18n.t("language"))

    var scroll := ScrollContainer.new()
    scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
    scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    col.add_child(scroll)

    var grid := GridContainer.new()
    grid.columns = 3
    grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    grid.add_theme_constant_override("h_separation", 16)
    grid.add_theme_constant_override("v_separation", 16)
    scroll.add_child(grid)

    for l in I18n.LANGS:
        var b := _btn(String(l[1]), l[0] == I18n.current)
        b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        b.pressed.connect(_on_lang.bind(String(l[0])))
        grid.add_child(b)


# ---------- widgets ----------

func _btn(text: String, primary: bool) -> Button:
    var b := Button.new()
    b.text = text
    b.custom_minimum_size = Vector2(0, 76)
    b.add_theme_font_size_override("font_size", 28)
    b.alignment = HORIZONTAL_ALIGNMENT_LEFT
    _style(b, primary, GOLD)
    return b


func _style(btn: Button, primary: bool, accent: Color) -> void:
    var normal := StyleBoxFlat.new()
    var hover := StyleBoxFlat.new()
    var pressed := StyleBoxFlat.new()
    for s in [normal, hover, pressed]:
        s.set_corner_radius_all(10)
        s.content_margin_left = 26
        s.content_margin_right = 26
        s.content_margin_top = 12
        s.content_margin_bottom = 12
        s.border_width_left = 6
        s.border_color = accent
    if primary:
        normal.bg_color = GOLD
        hover.bg_color = Color(1.0, 0.84, 0.50)
        pressed.bg_color = Color(0.82, 0.62, 0.25)
        btn.add_theme_color_override("font_color", Color(0.12, 0.08, 0.03))
        btn.add_theme_color_override("font_hover_color", Color(0.12, 0.08, 0.03))
        btn.add_theme_color_override("font_pressed_color", Color(0.12, 0.08, 0.03))
    else:
        normal.bg_color = Color(0.08, 0.07, 0.06, 0.72)
        hover.bg_color = Color(0.20, 0.15, 0.08, 0.88)
        pressed.bg_color = Color(0.30, 0.22, 0.10, 0.95)
        btn.add_theme_color_override("font_color", Color(0.96, 0.93, 0.86))
        btn.add_theme_color_override("font_hover_color", Color(1.0, 0.95, 0.80))
        btn.add_theme_color_override("font_pressed_color", Color(1.0, 0.9, 0.6))
    btn.add_theme_stylebox_override("normal", normal)
    btn.add_theme_stylebox_override("hover", hover)
    btn.add_theme_stylebox_override("pressed", pressed)
    btn.add_theme_stylebox_override("focus", normal)


# ---------- actions ----------

func _on_lang(code: String) -> void:
    I18n.set_lang(code)
    page = "main"
    _rebuild_all()


func _on_quality(opt: String) -> void:
    Settings.set_mode(opt)
    _build_content()


func _on_replay_tutorial() -> void:
    Settings.set_tutorial_done(false)
    _build_content()


func _on_continue() -> void:
    continue_chosen.emit()


func _on_pick(id: String) -> void:
    map_chosen.emit(id)
