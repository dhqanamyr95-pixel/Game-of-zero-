extends Node3D

# One big continuous world built from 64 m chunks that are created around the player
# and removed when far away. Biomes (savanna, forest, blossom forest, desert, snow,
# volcanic, beach), rivers, lakes and mountains come from noise. Every chunk also
# gets trees, rocks, bushes, branches under the trees and pebbles around the rocks.
# Trees can be chopped, rocks can be mined, saplings can be planted.

const Settings = preload("res://scripts/settings.gd")
const Meshes = preload("res://scripts/meshes.gd")
const Assets = preload("res://scripts/assets.gd")

const CHUNK := 64.0
const WORLD_R := 760.0
const GROW_TIME := 420.0

const COL_SAVANNA := Color(0.56, 0.53, 0.25)
const COL_FOREST := Color(0.15, 0.38, 0.12)
const COL_BLOSSOM := Color(0.66, 0.50, 0.66)
const COL_DESERT := Color(0.86, 0.69, 0.42)
const COL_SNOW := Color(0.94, 0.96, 1.00)
const COL_VOLCANIC := Color(0.17, 0.15, 0.15)
const COL_SAND := Color(0.82, 0.75, 0.55)
const COL_DEEP := Color(0.20, 0.30, 0.30)
const COL_ROCK := Color(0.46, 0.43, 0.40)

const FOLIAGE_SHADER := """
shader_type spatial;
render_mode cull_disabled, diffuse_lambert, specular_disabled;

uniform vec3 leaf_target = vec3(1.0, 0.7, 0.8);
uniform float leaf_mix = 0.0;
uniform float wind = 0.3;

void vertex() {
    float h = max(VERTEX.y, 0.0);
    vec3 origin = MODEL_MATRIX[3].xyz;
    float ph = origin.x * 0.31 + origin.z * 0.23;
    float k = 0.25 + 0.75 * COLOR.a;
    VERTEX.x += sin(TIME * 1.7 + ph + VERTEX.y * 0.6) * wind * h * 0.02 * k;
    VERTEX.z += cos(TIME * 1.3 + ph * 1.7 + VERTEX.y * 0.5) * wind * h * 0.014 * k;
}

void fragment() {
    vec3 c = COLOR.rgb;
    float leaf = COLOR.a;
    c = mix(c, mix(c, leaf_target, leaf_mix), leaf);
    ALBEDO = c;
    ROUGHNESS = 1.0;
    if (!FRONT_FACING) {
        NORMAL = -NORMAL;
    }
}
"""


class Chunk:
    var key := Vector2i.ZERO
    var node: Node3D = null
    var mesh: ArrayMesh = null
    var body: StaticBody3D = null
    var obj_body: StaticBody3D = null
    var verts := PackedVector3Array()
    var norms := PackedVector3Array()
    var uvs := PackedVector2Array()
    var idx := PackedInt32Array()
    var base_cols := PackedColorArray()
    var phase := 0
    var has_objects := false
    var trees: Array = []
    var rocks: Array = []
    var pebbles: Array = []
    var branches: Array = []
    var fibers: Array = []
    var bushes: Array = []


var seed_val := 777
var segs := 20
var chunks := {}
var queue: Array = []
var mods := {}
var plants: Array = []
var player = null
var weather = null
var water: MeshInstance3D = null
var now := 0.0
var plan_t := 0.0
var plateau_h := 1.8

var ground_mat: StandardMaterial3D
var mat_decid: ShaderMaterial
var mat_conifer: ShaderMaterial
var mat_static: ShaderMaterial
var season_tint := Color(1.0, 1.0, 1.0)
var season_mix_col := Color(1.0, 1.0, 1.0)
var season_mix := 0.0
var chips: CPUParticles3D

var n_elev: FastNoiseLite
var n_ridge: FastNoiseLite
var n_river: FastNoiseLite
var n_temp: FastNoiseLite
var n_moist: FastNoiseLite
var n_bloom: FastNoiseLite
var n_vol: FastNoiseLite
var n_detail: FastNoiseLite

var _best := {}
var _best_d := 9999.0


# ---------- setup ----------

func build(params: Dictionary, segs_count: int = 20) -> void:
    segs = segs_count
    seed_val = int(params.get("seed", 777))
    n_elev = _noise(0, 0.0028, 4, false)
    n_ridge = _noise(1, 0.0060, 3, true)
    n_river = _noise(2, 0.0042, 2, false)
    n_temp = _noise(3, 0.0017, 2, false)
    n_moist = _noise(4, 0.0021, 2, false)
    n_bloom = _noise(5, 0.0040, 2, false)
    n_vol = _noise(6, 0.0031, 2, false)
    n_detail = _noise(7, 0.05, 1, false)

    ground_mat = StandardMaterial3D.new()
    ground_mat.vertex_color_use_as_albedo = true
    ground_mat.roughness = 1.0
    ground_mat.cull_mode = BaseMaterial3D.CULL_DISABLED
    Settings.tune(ground_mat)
    var ground_tex := Assets.texture("textures/ground")
    if ground_tex != null:
        ground_mat.albedo_texture = ground_tex

    var sh := Shader.new()
    sh.code = FOLIAGE_SHADER
    mat_decid = _foliage_mat(sh, 0.35)
    mat_conifer = _foliage_mat(sh, 0.2)
    mat_static = _foliage_mat(sh, 0.0)

    chips = CPUParticles3D.new()
    chips.top_level = true
    chips.one_shot = true
    chips.amount = 12
    chips.lifetime = 0.5
    chips.explosiveness = 0.9
    chips.direction = Vector3(0, 1, 0)
    chips.spread = 70.0
    chips.initial_velocity_min = 2.0
    chips.initial_velocity_max = 4.0
    chips.gravity = Vector3(0, -9.0, 0)
    var bm := BoxMesh.new()
    bm.size = Vector3(0.06, 0.06, 0.06)
    var cm := StandardMaterial3D.new()
    cm.vertex_color_use_as_albedo = true
    cm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    bm.material = cm
    chips.mesh = bm
    chips.emitting = false
    add_child(chips)


func _noise(k: int, freq: float, octaves: int, ridged: bool) -> FastNoiseLite:
    var n := FastNoiseLite.new()
    n.seed = seed_val * 7 + k * 101
    n.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
    n.frequency = freq
    if ridged:
        n.fractal_type = FastNoiseLite.FRACTAL_RIDGED
    else:
        n.fractal_type = FastNoiseLite.FRACTAL_FBM
    n.fractal_octaves = octaves
    return n


func _foliage_mat(sh: Shader, wind: float) -> ShaderMaterial:
    var m := ShaderMaterial.new()
    m.shader = sh
    m.set_shader_parameter("wind", wind)
    return m


# ---------- the shape of the world ----------

func base_height(x: float, z: float) -> float:
    var land := 0.5 + 0.5 * n_elev.get_noise_2d(x, z)
    var h := (land - 0.38) * 30.0
    var mount := smoothstep(0.55, 0.85, land)
    h += mount * (0.5 + 0.5 * n_ridge.get_noise_2d(x, z)) * 16.0
    var r := Vector2(x, z).length() / WORLD_R
    h -= smoothstep(0.80, 1.0, r) * 45.0
    return h


func height_at(x: float, z: float) -> float:
    var h := base_height(x, z)
    var rv := absf(n_river.get_noise_2d(x, z))
    var carve := 1.0 - smoothstep(0.0, 0.04, rv)
    var low := 1.0 - smoothstep(4.0, 10.0, h)
    return lerpf(h, -1.5, carve * low)


# x = temperature, y = moisture, z = blossom patches
func climate(x: float, z: float, h: float) -> Vector3:
    var t := n_temp.get_noise_2d(x, z) * 1.6
    var m := n_moist.get_noise_2d(x, z) * 1.6
    var b := n_bloom.get_noise_2d(x, z) * 1.6
    t -= maxf(0.0, h - 14.0) * 0.07
    return Vector3(t, m, b)


func biome_from(x: float, z: float, h: float) -> String:
    if h < 0.3:
        return "water"
    if h < 1.0:
        return "beach"
    var c := climate(x, z, h)
    if n_vol.get_noise_2d(x, z) > 0.42 and h > 5.0:
        return "volcanic"
    if c.x < -0.30:
        return "snow"
    if c.x > 0.30 and c.y < 0.0:
        return "desert"
    if c.y > 0.15 and c.z > 0.30 and c.x > -0.1:
        return "blossom"
    if c.y > 0.05:
        return "forest"
    return "savanna"


func biome_at(x: float, z: float) -> String:
    return biome_from(x, z, height_at(x, z))


func ground_color(x: float, z: float, h: float, slope_y: float) -> Color:
    var c := climate(x, z, h)
    var col := COL_SAVANNA
    var wet := smoothstep(0.0, 0.3, c.y)
    col = col.lerp(COL_FOREST, wet)
    var bloom := wet * smoothstep(0.25, 0.45, c.z) * smoothstep(-0.2, 0.0, c.x)
    col = col.lerp(COL_BLOSSOM, bloom)
    var dry := smoothstep(0.2, 0.4, c.x) * (1.0 - smoothstep(-0.1, 0.1, c.y))
    col = col.lerp(COL_DESERT, dry)
    var cold := 1.0 - smoothstep(-0.45, -0.2, c.x)
    col = col.lerp(COL_SNOW, cold)
    var vol := smoothstep(0.38, 0.5, n_vol.get_noise_2d(x, z)) * smoothstep(3.0, 6.0, h)
    col = col.lerp(COL_VOLCANIC, vol)
    var shore := 1.0 - smoothstep(0.6, 1.6, h)
    col = col.lerp(COL_SAND, shore)
    var deep := 1.0 - smoothstep(-3.0, 0.0, h)
    col = col.lerp(COL_DEEP, deep)
    col = col.lerp(COL_ROCK, 1.0 - smoothstep(0.66, 0.84, slope_y))
    var sp := 1.0 + n_detail.get_noise_2d(x, z) * 0.12
    return Color(col.r * sp, col.g * sp, col.b * sp)


# A random place on land to start a new game.
func find_spawn() -> Vector3:
    var rng := RandomNumberGenerator.new()
    rng.randomize()
    for i in 600:
        var ang := rng.randf() * TAU
        var rad := rng.randf_range(20.0, 450.0)
        var x := cos(ang) * rad
        var z := sin(ang) * rad
        var h := height_at(x, z)
        if h < 1.6 or h > 8.0:
            continue
        var bio := biome_from(x, z, h)
        if bio != "forest" and bio != "savanna" and bio != "blossom":
            continue
        var sl := absf(height_at(x + 2.0, z) - h) + absf(height_at(x, z + 2.0) - h)
        if sl > 0.8:
            continue
        return Vector3(x, h, z)
    return Vector3(0.0, maxf(height_at(0.0, 0.0), 1.0), 0.0)


# ---------- chunk streaming ----------

func _chunk_of(pos: Vector3) -> Vector2i:
    return Vector2i(int(floor(pos.x / CHUNK)), int(floor(pos.z / CHUNK)))


func _make_chunk(key: Vector2i) -> void:
    var ch := Chunk.new()
    ch.key = key
    ch.node = Node3D.new()
    ch.node.position = Vector3(float(key.x) * CHUNK, 0.0, float(key.y) * CHUNK)
    add_child(ch.node)
    chunks[key] = ch


func _free_chunk(key: Vector2i) -> void:
    var ch: Chunk = chunks[key]
    ch.node.queue_free()
    chunks.erase(key)


func prebuild(center: Vector3, radius: int) -> void:
    var pc := _chunk_of(center)
    for dz in range(-radius, radius + 1):
        for dx in range(-radius, radius + 1):
            var key := Vector2i(pc.x + dx, pc.y + dz)
            if not chunks.has(key):
                _make_chunk(key)
            var ch: Chunk = chunks[key]
            while ch.phase < 3:
                if ch.phase == 0:
                    _build_mesh(ch)
                elif ch.phase == 1:
                    _build_collision(ch)
                else:
                    _build_objects(ch)


func _process(delta: float) -> void:
    if player == null:
        return
    now += delta
    var pp: Vector3 = player.global_position
    if water != null:
        water.global_position = Vector3(pp.x, 0.0, pp.z)
    plan_t -= delta
    if plan_t <= 0.0:
        plan_t = 0.3
        _plan()
        _tick_plants()
        _tick_bushes()
        if weather != null:
            var w := 0.35
            if weather.kind == "storm":
                w = 1.3
            set_wind(w)
    _work()


func _plan() -> void:
    var pc := _chunk_of(player.global_position)
    var r := Settings.chunk_radius()
    var order: Array = []
    for dz in range(-r, r + 1):
        for dx in range(-r, r + 1):
            if dx * dx + dz * dz > r * r + r:
                continue
            var key := Vector2i(pc.x + dx, pc.y + dz)
            if absf(float(key.x) * CHUNK) > WORLD_R + 128.0 or absf(float(key.y) * CHUNK) > WORLD_R + 128.0:
                continue
            order.append([dx * dx + dz * dz, key])
    order.sort_custom(func(a, b): return a[0] < b[0])
    queue.clear()
    for o in order:
        var k: Vector2i = o[1]
        if not chunks.has(k):
            _make_chunk(k)
        queue.append(k)
    for key in chunks.keys():
        var d := maxi(absi(key.x - pc.x), absi(key.y - pc.y))
        if d > r + 1:
            _free_chunk(key)


# One small job per frame so the game never freezes while the world grows.
func _work() -> void:
    var pc := _chunk_of(player.global_position)
    var obj_r := Settings.object_radius()
    for key in queue:
        var ch: Chunk = chunks.get(key, null)
        if ch == null:
            continue
        if ch.phase == 0:
            _build_mesh(ch)
            return
        if ch.phase == 1:
            _build_collision(ch)
            return
        if ch.phase == 2:
            var d := maxi(absi(key.x - pc.x), absi(key.y - pc.y))
            if d <= obj_r:
                _build_objects(ch)
                return


func _final_colors(ch: Chunk) -> PackedColorArray:
    var cols := PackedColorArray()
    cols.resize(ch.base_cols.size())
    for i in ch.base_cols.size():
        var c: Color = ch.base_cols[i].lerp(season_mix_col, season_mix)
        cols[i] = Color(c.r * season_tint.r, c.g * season_tint.g, c.b * season_tint.b, 1.0)
    return cols


func _set_surface(ch: Chunk) -> void:
    var arrays := []
    arrays.resize(Mesh.ARRAY_MAX)
    arrays[Mesh.ARRAY_VERTEX] = ch.verts
    arrays[Mesh.ARRAY_NORMAL] = ch.norms
    arrays[Mesh.ARRAY_COLOR] = _final_colors(ch)
    arrays[Mesh.ARRAY_TEX_UV] = ch.uvs
    arrays[Mesh.ARRAY_INDEX] = ch.idx
    ch.mesh.clear_surfaces()
    ch.mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
    ch.mesh.surface_set_material(0, ground_mat)


func _build_mesh(ch: Chunk) -> void:
    ch.phase = 1
    var step := CHUNK / float(segs)
    var ox := float(ch.key.x) * CHUNK
    var oz := float(ch.key.y) * CHUNK
    var n := segs + 3
    var hs := PackedFloat32Array()
    hs.resize(n * n)
    for j in n:
        for i in n:
            hs[j * n + i] = height_at(ox + float(i - 1) * step, oz + float(j - 1) * step)
    for j in range(segs + 1):
        for i in range(segs + 1):
            var gi := i + 1
            var gj := j + 1
            var h := hs[gj * n + gi]
            var hl := hs[gj * n + gi - 1]
            var hr := hs[gj * n + gi + 1]
            var hd := hs[(gj - 1) * n + gi]
            var hu := hs[(gj + 1) * n + gi]
            var nrm := Vector3(hl - hr, 2.0 * step, hd - hu).normalized()
            ch.verts.append(Vector3(float(i) * step, h, float(j) * step))
            ch.norms.append(nrm)
            ch.uvs.append(Vector2((ox + float(i) * step) * 0.25, (oz + float(j) * step) * 0.25))
            ch.base_cols.append(ground_color(ox + float(i) * step, oz + float(j) * step, h, nrm.y))
    var stride := segs + 1
    for j in segs:
        for i in segs:
            var a := j * stride + i
            var b := a + 1
            var c := a + stride
            var d := c + 1
            ch.idx.append(a)
            ch.idx.append(b)
            ch.idx.append(c)
            ch.idx.append(b)
            ch.idx.append(d)
            ch.idx.append(c)
    ch.mesh = ArrayMesh.new()
    _set_surface(ch)
    var mi := MeshInstance3D.new()
    mi.mesh = ch.mesh
    mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    ch.node.add_child(mi)


func _build_collision(ch: Chunk) -> void:
    ch.phase = 2
    var shape := ch.mesh.create_trimesh_shape()
    if shape == null:
        return
    ch.body = StaticBody3D.new()
    ch.body.add_to_group("ground")
    var cs := CollisionShape3D.new()
    cs.shape = shape
    ch.body.add_child(cs)
    ch.node.add_child(ch.body)


# ---------- seasons ----------

func recolor(tint: Color, mix_col: Color, mix_amt: float) -> void:
    season_tint = tint
    season_mix_col = mix_col
    season_mix = mix_amt
    for key in chunks.keys():
        var ch: Chunk = chunks[key]
        if ch.mesh != null and ch.phase >= 1:
            _set_surface(ch)


func set_foliage(target: Color, amount: float) -> void:
    var v := Vector3(target.r, target.g, target.b)
    mat_decid.set_shader_parameter("leaf_target", v)
    mat_decid.set_shader_parameter("leaf_mix", amount)
    mat_conifer.set_shader_parameter("leaf_target", v)
    mat_conifer.set_shader_parameter("leaf_mix", amount * 0.35)


func set_wind(w: float) -> void:
    mat_decid.set_shader_parameter("wind", w)
    mat_conifer.set_shader_parameter("wind", w * 0.6)


# ---------- what grows where ----------

func _tree_prob(bio: String) -> float:
    match bio:
        "forest":
            return 0.85
        "blossom":
            return 0.70
        "snow":
            return 0.45
        "savanna":
            return 0.06
        "desert":
            return 0.03
        "volcanic":
            return 0.05
    return 0.0


func _tree_type(bio: String, h: float, r: float) -> int:
    match bio:
        "forest":
            if h < 2.6:
                return Meshes.TREE_WILLOW
            if r < 0.70:
                return Meshes.TREE_OAK
            if r < 0.76:
                return Meshes.TREE_BANYAN
            return Meshes.TREE_SPRUCE
        "blossom":
            if r < 0.8:
                return Meshes.TREE_BLOSSOM
            return Meshes.TREE_OAK
        "snow":
            if r < 0.9:
                return Meshes.TREE_SPRUCE
            return Meshes.TREE_DEAD
        "savanna":
            if r < 0.30:
                return Meshes.TREE_BANYAN
            if r < 0.75:
                return Meshes.TREE_OAK
            return Meshes.TREE_DEAD
        "desert":
            if r < 0.7:
                return Meshes.TREE_CACTUS
            return Meshes.TREE_DEAD
    return Meshes.TREE_DEAD


func _tree_hp(t: int) -> int:
    match t:
        Meshes.TREE_BANYAN:
            return 14
        Meshes.TREE_DEAD:
            return 6
        Meshes.TREE_CACTUS:
            return 5
        Meshes.TREE_SPRUCE:
            return 9
    return 10


func _trunk_radius(t: int) -> float:
    match t:
        Meshes.TREE_BANYAN:
            return 0.9
        Meshes.TREE_CACTUS:
            return 0.35
        Meshes.TREE_DEAD:
            return 0.3
        Meshes.TREE_SPRUCE:
            return 0.35
    return 0.5


func _tree_material(t: int) -> ShaderMaterial:
    match t:
        Meshes.TREE_SPRUCE:
            return mat_conifer
        Meshes.TREE_DEAD:
            return mat_static
        Meshes.TREE_CACTUS:
            return mat_static
    return mat_decid


func _rock_prob(bio: String) -> float:
    match bio:
        "desert":
            return 0.25
        "volcanic":
            return 0.35
        "snow":
            return 0.15
        "savanna":
            return 0.12
        "forest":
            return 0.08
        "blossom":
            return 0.05
        "beach":
            return 0.04
    return 0.0


func _bush_prob(bio: String) -> float:
    match bio:
        "forest":
            return 0.25
        "blossom":
            return 0.20
        "savanna":
            return 0.10
        "snow":
            return 0.03
    return 0.0


func _fiber_prob(bio: String, h: float) -> float:
    if h < 2.4 and (bio == "forest" or bio == "savanna" or bio == "blossom" or bio == "beach"):
        return 0.55
    match bio:
        "savanna":
            return 0.12
        "forest":
            return 0.08
        "blossom":
            return 0.10
    return 0.0


# ---------- objects ----------

func _set_of(arr: Array) -> Dictionary:
    var d := {}
    for v in arr:
        d[int(v)] = true
    return d


func _item(pos: Vector3, scl: float, yaw: float, gk: String, mesh: Mesh, mat: Material, alive: bool, vis: bool, col_r: float, col_h: float) -> Dictionary:
    return {
        "pos": pos, "scale": scl, "yaw": yaw, "gk": gk, "mesh": mesh, "mat": mat,
        "alive": alive, "vis": vis, "col_r": col_r, "col_h": col_h,
        "slot": -1, "shape": null, "mm": null, "lp": Vector3.ZERO, "hp": 1, "type": 0,
    }


func _build_objects(ch: Chunk) -> void:
    ch.phase = 3
    ch.has_objects = true
    var key_s := "%d,%d" % [ch.key.x, ch.key.y]
    var m: Dictionary = mods.get(key_s, {})
    var gone_t := _set_of(m.get("t", []))
    var gone_r := _set_of(m.get("r", []))
    var gone_pb := _set_of(m.get("pb", []))
    var gone_br := _set_of(m.get("br", []))
    var gone_fb := _set_of(m.get("fb", []))
    var rng := RandomNumberGenerator.new()
    rng.seed = hash(Vector3i(ch.key.x, ch.key.y, seed_val))
    var dens := Settings.density()
    var ox := float(ch.key.x) * CHUNK
    var oz := float(ch.key.y) * CHUNK
    ch.obj_body = StaticBody3D.new()
    ch.node.add_child(ch.obj_body)

    # trees, and the branches that fell under them
    for c in 70:
        var lx := rng.randf_range(2.0, CHUNK - 2.0)
        var lz := rng.randf_range(2.0, CHUNK - 2.0)
        var roll := rng.randf()
        var keep := rng.randf()
        var scl := rng.randf_range(0.8, 1.5)
        var yaw := rng.randf() * TAU
        var sel := rng.randf()
        var wx := ox + lx
        var wz := oz + lz
        var h := height_at(wx, wz)
        if h < 0.9:
            continue
        var bio := biome_from(wx, wz, h)
        if roll > _tree_prob(bio):
            continue
        var sl := absf(height_at(wx + 1.5, wz) - h) + absf(height_at(wx, wz + 1.5) - h)
        if sl > 1.7:
            continue
        var close := false
        for o in ch.trees:
            var op: Vector3 = o["pos"]
            if Vector2(op.x - wx, op.z - wz).length() < 2.4 * scl:
                close = true
                break
        if close:
            continue
        var ttype := _tree_type(bio, h, sel)
        var ti := ch.trees.size()
        var talive := not gone_t.has(ti)
        var tree := _item(Vector3(wx, h, wz), scl, yaw, "tree%d" % ttype, Meshes.tree(ttype), _tree_material(ttype), talive, talive and keep <= dens, _trunk_radius(ttype) * scl, 3.0)
        tree["hp"] = _tree_hp(ttype)
        tree["type"] = ttype
        ch.trees.append(tree)
        if ttype != Meshes.TREE_CACTUS:
            var nb := int(rng.randf() * 3.0)
            for k in nb:
                var a := rng.randf() * TAU
                var d := rng.randf_range(1.3, 3.2)
                var bsc := rng.randf_range(0.8, 1.2)
                var byaw := rng.randf() * TAU
                var bkeep := rng.randf()
                var bx := wx + cos(a) * d
                var bz := wz + sin(a) * d
                var bh := height_at(bx, bz)
                if bh < 0.9:
                    continue
                var bi := ch.branches.size()
                var balive := not gone_br.has(bi)
                ch.branches.append(_item(Vector3(bx, bh, bz), bsc, byaw, "branch", Meshes.branch(), mat_static, balive, balive and bkeep <= dens, 0.0, 0.0))

    # rocks, and the pebbles around them
    for c in 28:
        var lx := rng.randf_range(2.0, CHUNK - 2.0)
        var lz := rng.randf_range(2.0, CHUNK - 2.0)
        var roll := rng.randf()
        var keep := rng.randf()
        var scl := rng.randf_range(0.7, 2.2)
        var yaw := rng.randf() * TAU
        var kind := int(rng.randf() * 3.0)
        var wx := ox + lx
        var wz := oz + lz
        var h := height_at(wx, wz)
        if h < 1.0:
            continue
        var bio := biome_from(wx, wz, h)
        if roll > _rock_prob(bio):
            continue
        var ri := ch.rocks.size()
        var ralive := not gone_r.has(ri)
        var rmul := 0.85
        if kind == 1:
            rmul = 1.4
        elif kind == 2:
            rmul = 0.55
        var rock := _item(Vector3(wx, h, wz), scl, yaw, "rock%d" % kind, Meshes.rock(kind), mat_static, ralive, ralive and keep <= dens, rmul * scl, scl)
        rock["hp"] = 6 + int(scl * 3.0)
        ch.rocks.append(rock)
        var np := 2 + int(rng.randf() * 3.0)
        for k in np:
            var a := rng.randf() * TAU
            var d := rng.randf_range(1.2, 2.4)
            var psc := rng.randf_range(0.10, 0.18)
            var pyaw := rng.randf() * TAU
            var pkeep := rng.randf()
            var px := wx + cos(a) * d
            var pz := wz + sin(a) * d
            var ph := height_at(px, pz)
            if ph < 0.9:
                continue
            var pi := ch.pebbles.size()
            var palive := not gone_pb.has(pi)
            ch.pebbles.append(_item(Vector3(px, ph, pz), psc, pyaw, "rock0", Meshes.rock(0), mat_static, palive, palive and pkeep <= dens, 0.0, 0.0))

    # reeds and grass for fibre
    for c in 36:
        var lx := rng.randf_range(2.0, CHUNK - 2.0)
        var lz := rng.randf_range(2.0, CHUNK - 2.0)
        var roll := rng.randf()
        var keep := rng.randf()
        var scl := rng.randf_range(0.8, 1.3)
        var yaw := rng.randf() * TAU
        var wx := ox + lx
        var wz := oz + lz
        var h := height_at(wx, wz)
        if h < 0.9:
            continue
        var bio := biome_from(wx, wz, h)
        if roll > _fiber_prob(bio, h):
            continue
        var fi := ch.fibers.size()
        var falive := not gone_fb.has(fi)
        ch.fibers.append(_item(Vector3(wx, h, wz), scl, yaw, "fiber", Meshes.fiber(), mat_decid, falive, falive and keep <= dens, 0.0, 0.0))

    # berry bushes
    for c in 24:
        var lx := rng.randf_range(2.0, CHUNK - 2.0)
        var lz := rng.randf_range(2.0, CHUNK - 2.0)
        var roll := rng.randf()
        var keep := rng.randf()
        var scl := rng.randf_range(0.8, 1.3)
        var yaw := rng.randf() * TAU
        var wx := ox + lx
        var wz := oz + lz
        var h := height_at(wx, wz)
        if h < 1.0:
            continue
        var bio := biome_from(wx, wz, h)
        if roll > _bush_prob(bio):
            continue
        var bush := _item(Vector3(wx, h, wz), scl, yaw, "bush", null, mat_decid, true, keep <= dens, 0.0, 0.0)
        bush["berries"] = true
        bush["ready"] = 0.0
        bush["full_mm"] = null
        bush["plain_mm"] = null
        ch.bushes.append(bush)

    _instance_items(ch, ch.trees)
    var smalls: Array = []
    smalls.append_array(ch.rocks)
    smalls.append_array(ch.pebbles)
    smalls.append_array(ch.branches)
    smalls.append_array(ch.fibers)
    _instance_items(ch, smalls)
    _instance_bushes(ch)


# Groups items by mesh and draws each group with one MultiMesh (one draw call).
func _instance_items(ch: Chunk, items: Array) -> void:
    var groups := {}
    for i in items.size():
        var o: Dictionary = items[i]
        if not o["vis"]:
            continue
        var gk: String = o["gk"]
        if not groups.has(gk):
            groups[gk] = []
        groups[gk].append(i)
    var ox := float(ch.key.x) * CHUNK
    var oz := float(ch.key.y) * CHUNK
    for gk in groups.keys():
        var ids: Array = groups[gk]
        var first: Dictionary = items[ids[0]]
        var mm := MultiMesh.new()
        mm.transform_format = MultiMesh.TRANSFORM_3D
        mm.mesh = first["mesh"]
        mm.instance_count = ids.size()
        for s in ids.size():
            var o: Dictionary = items[ids[s]]
            var lp: Vector3 = o["pos"] - Vector3(ox, 0.0, oz)
            var sc: float = o["scale"]
            var bs := Basis(Vector3.UP, float(o["yaw"])).scaled(Vector3(sc, sc, sc))
            mm.set_instance_transform(s, Transform3D(bs, lp))
            o["slot"] = s
            o["mm"] = mm
            o["lp"] = lp
            var cr: float = o["col_r"]
            if cr > 0.0:
                var cs := CollisionShape3D.new()
                var sh := CylinderShape3D.new()
                sh.radius = cr
                sh.height = float(o["col_h"])
                cs.shape = sh
                cs.position = lp + Vector3(0.0, float(o["col_h"]) * 0.5, 0.0)
                ch.obj_body.add_child(cs)
                o["shape"] = cs
        var mmi := MultiMeshInstance3D.new()
        mmi.multimesh = mm
        mmi.material_override = first["mat"]
        ch.node.add_child(mmi)


func _instance_bushes(ch: Chunk) -> void:
    var ids: Array = []
    for i in ch.bushes.size():
        var o: Dictionary = ch.bushes[i]
        if o["vis"]:
            ids.append(i)
    if ids.is_empty():
        return
    var ox := float(ch.key.x) * CHUNK
    var oz := float(ch.key.y) * CHUNK
    var full := MultiMesh.new()
    full.transform_format = MultiMesh.TRANSFORM_3D
    full.mesh = Meshes.bush(true)
    full.instance_count = ids.size()
    var plain := MultiMesh.new()
    plain.transform_format = MultiMesh.TRANSFORM_3D
    plain.mesh = Meshes.bush(false)
    plain.instance_count = ids.size()
    for s in ids.size():
        var o: Dictionary = ch.bushes[ids[s]]
        var lp: Vector3 = o["pos"] - Vector3(ox, 0.0, oz)
        var sc: float = o["scale"]
        var xf := Transform3D(Basis(Vector3.UP, float(o["yaw"])).scaled(Vector3(sc, sc, sc)), lp)
        full.set_instance_transform(s, xf)
        plain.set_instance_transform(s, Transform3D(Basis().scaled(Vector3(0.0001, 0.0001, 0.0001)), lp))
        o["slot"] = s
        o["lp"] = lp
        o["xf"] = xf
        o["full_mm"] = full
        o["plain_mm"] = plain
    var a := MultiMeshInstance3D.new()
    a.multimesh = full
    a.material_override = mat_decid
    ch.node.add_child(a)
    var b := MultiMeshInstance3D.new()
    b.multimesh = plain
    b.material_override = mat_decid
    ch.node.add_child(b)


func _hide_item(o: Dictionary) -> void:
    var mm = o["mm"]
    if mm != null and int(o["slot"]) >= 0:
        var lp: Vector3 = o["lp"]
        (mm as MultiMesh).set_instance_transform(int(o["slot"]), Transform3D(Basis().scaled(Vector3(0.0001, 0.0001, 0.0001)), lp))
    var sh = o["shape"]
    if sh != null and is_instance_valid(sh):
        (sh as Node).queue_free()
    o["shape"] = null
    o["alive"] = false


func _mark(ch: Chunk, list_key: String, i: int) -> void:
    var ks := "%d,%d" % [ch.key.x, ch.key.y]
    if not mods.has(ks):
        mods[ks] = {}
    var d: Dictionary = mods[ks]
    if not d.has(list_key):
        d[list_key] = []
    d[list_key].append(i)


func _set_berries(o: Dictionary, on: bool) -> void:
    o["berries"] = on
    var full = o["full_mm"]
    var plain = o["plain_mm"]
    if full == null or plain == null:
        return
    var hidden := Transform3D(Basis().scaled(Vector3(0.0001, 0.0001, 0.0001)), o["lp"])
    var shown: Transform3D = o["xf"]
    var s: int = o["slot"]
    if on:
        (full as MultiMesh).set_instance_transform(s, shown)
        (plain as MultiMesh).set_instance_transform(s, hidden)
    else:
        (full as MultiMesh).set_instance_transform(s, hidden)
        (plain as MultiMesh).set_instance_transform(s, shown)


func _tick_bushes() -> void:
    for key in chunks.keys():
        var ch: Chunk = chunks[key]
        if not ch.has_objects:
            continue
        for o in ch.bushes:
            if o["vis"] and not o["berries"] and now >= float(o["ready"]):
                _set_berries(o, true)


# ---------- finding things to use ----------

func _consider(ch: Chunk, list: Array, kind: String, lkey: String, pos: Vector3, f: Vector2, rad: float, front: bool, bias: float) -> void:
    for i in list.size():
        var o: Dictionary = list[i]
        if not o["alive"] or not o["vis"]:
            continue
        if kind == "bush" and not o["berries"]:
            continue
        var op: Vector3 = o["pos"]
        var dx := op.x - pos.x
        var dz := op.z - pos.z
        var d := sqrt(dx * dx + dz * dz)
        if d > rad:
            continue
        if front and d > 0.6:
            if (dx * f.x + dz * f.y) / d < 0.25:
                continue
        var score := d - bias
        if score < _best_d:
            _best_d = score
            _best = {"kind": kind, "chunk": ch, "lkey": lkey, "i": i, "o": o}


# Returns the nearest thing the player can use: {} when there is nothing.
# kinds: branch, pebble, fiber (pick up), bush (berries), tree, rock, ptree (planted tree)
func find_target(pos: Vector3, fwd: Vector3, reach: float) -> Dictionary:
    _best = {}
    _best_d = 9999.0
    var f := Vector2(fwd.x, fwd.z)
    if f.length() > 0.01:
        f = f.normalized()
    var pc := _chunk_of(pos)
    for dz in range(-1, 2):
        for dx in range(-1, 2):
            var ch: Chunk = chunks.get(Vector2i(pc.x + dx, pc.y + dz), null)
            if ch == null or not ch.has_objects:
                continue
            _consider(ch, ch.branches, "branch", "br", pos, f, 1.8, false, 1.5)
            _consider(ch, ch.pebbles, "pebble", "pb", pos, f, 1.8, false, 1.5)
            _consider(ch, ch.fibers, "fiber", "fb", pos, f, 1.8, false, 1.5)
            _consider(ch, ch.bushes, "bush", "bu", pos, f, reach, true, 0.5)
            _consider(ch, ch.trees, "tree", "t", pos, f, reach + 0.5, true, 0.0)
            _consider(ch, ch.rocks, "rock", "r", pos, f, reach + 0.7, true, 0.0)
    for pl in plants:
        if not pl["grown"]:
            continue
        var pp: Vector3 = pl["pos"]
        var ddx := pp.x - pos.x
        var ddz := pp.z - pos.z
        var d := sqrt(ddx * ddx + ddz * ddz)
        if d <= reach + 0.5 and d < _best_d:
            _best_d = d
            _best = {"kind": "ptree", "plant": pl}
    return _best


func collect(target: Dictionary) -> Dictionary:
    var out := {}
    var kind: String = target["kind"]
    var ch: Chunk = target["chunk"]
    var o: Dictionary = target["o"]
    var i: int = target["i"]
    if kind == "branch":
        out["wood"] = 1 + int(randf() * 2.0)
        _mark(ch, "br", i)
    elif kind == "pebble":
        out["stone"] = 1
        _mark(ch, "pb", i)
    elif kind == "fiber":
        out["fiber"] = 1 + int(randf() * 2.0)
        _mark(ch, "fb", i)
    else:
        return out
    _hide_item(o)
    return out


func eat_berries(target: Dictionary) -> bool:
    var o: Dictionary = target["o"]
    if not o["berries"]:
        return false
    _set_berries(o, false)
    o["ready"] = now + 150.0
    return true


func _tree_drops(t: int) -> Dictionary:
    var out := {}
    match t:
        Meshes.TREE_CACTUS:
            out["fiber"] = 2
        Meshes.TREE_DEAD:
            out["wood"] = 2
        Meshes.TREE_SPRUCE:
            out["wood"] = 4
        _:
            out["wood"] = 3 + int(randf() * 3.0)
    if t != Meshes.TREE_CACTUS and t != Meshes.TREE_DEAD and randf() < 0.4:
        out["sapling"] = 1
    return out


func puff(pos: Vector3, col: Color) -> void:
    if chips == null:
        return
    chips.global_position = pos
    chips.color = col
    chips.restart()
    chips.emitting = true


# Hit a tree or rock. power: how strong the tool is. Returns what dropped.
func hit(target: Dictionary, power: int, can_mine: bool) -> Dictionary:
    var kind: String = target["kind"]
    var out := {}
    if kind == "tree":
        var o: Dictionary = target["o"]
        o["hp"] = int(o["hp"]) - power
        puff(Vector3(o["pos"]) + Vector3(0.0, 1.4, 0.0), Color(0.55, 0.38, 0.22))
        out["hit"] = true
        if int(o["hp"]) <= 0:
            out = _tree_drops(int(o["type"]))
            out["hit"] = true
            out["felled"] = true
            _mark(target["chunk"], "t", int(target["i"]))
            _hide_item(o)
    elif kind == "rock":
        if not can_mine:
            out["need_pickaxe"] = true
            return out
        var r: Dictionary = target["o"]
        r["hp"] = int(r["hp"]) - power
        puff(Vector3(r["pos"]) + Vector3(0.0, 0.7, 0.0), Color(0.7, 0.68, 0.64))
        out["hit"] = true
        out["rock"] = true
        if int(r["hp"]) <= 0:
            out["stone"] = 2 + int(randf() * 3.0)
            out["felled"] = true
            _mark(target["chunk"], "r", int(target["i"]))
            _hide_item(r)
    elif kind == "ptree":
        var pl: Dictionary = target["plant"]
        pl["hp"] = int(pl["hp"]) - power
        puff(Vector3(pl["pos"]) + Vector3(0.0, 1.4, 0.0), Color(0.55, 0.38, 0.22))
        out["hit"] = true
        if int(pl["hp"]) <= 0:
            out = _tree_drops(int(pl["type"]))
            out["hit"] = true
            out["felled"] = true
            _remove_plant(pl)
    return out


# ---------- planting ----------

func soil_ok(bio: String) -> bool:
    return bio == "forest" or bio == "blossom" or bio == "savanna"


func _spawn_plant(p: Vector3, ttype: int, age: float, ok: bool) -> void:
    var node := MeshInstance3D.new()
    node.mesh = Meshes.sapling()
    node.material_override = mat_decid
    node.position = p
    node.scale = Vector3(0.7, 0.7, 0.7)
    add_child(node)
    plants.append({"pos": p, "type": ttype, "t0": now - age, "ok": ok, "node": node, "grown": false, "hp": _tree_hp(ttype), "body": null, "stage": 0})


# result: "ok", "bad_soil" (it will wither), "water", "blocked"
func plant(pos: Vector3, fwd: Vector3) -> String:
    var p := pos + fwd * 1.3
    p.y = height_at(p.x, p.z)
    if p.y < 1.0:
        return "water"
    for pl in plants:
        var q: Vector3 = pl["pos"]
        if Vector2(q.x - p.x, q.z - p.z).length() < 1.2:
            return "blocked"
    var bio := biome_from(p.x, p.z, p.y)
    var ttype := Meshes.TREE_OAK
    if bio == "blossom":
        ttype = Meshes.TREE_BLOSSOM
    var ok := soil_ok(bio)
    _spawn_plant(p, ttype, 0.0, ok)
    if ok:
        return "ok"
    return "bad_soil"


func _remove_plant(pl: Dictionary) -> void:
    var node = pl["node"]
    if node != null and is_instance_valid(node):
        (node as Node).queue_free()
    var body = pl["body"]
    if body != null and is_instance_valid(body):
        (body as Node).queue_free()
    plants.erase(pl)


func _tick_plants() -> void:
    var i := plants.size() - 1
    while i >= 0:
        var pl: Dictionary = plants[i]
        var age := now - float(pl["t0"])
        var node: MeshInstance3D = pl["node"]
        if not bool(pl["ok"]) and age > 90.0:
            node.queue_free()
            plants.remove_at(i)
        elif not bool(pl["grown"]):
            var k := clampf(age / GROW_TIME, 0.0, 1.0)
            if int(pl["stage"]) == 0 and k >= 0.25:
                pl["stage"] = 1
                node.mesh = Meshes.tree(int(pl["type"]))
                node.material_override = _tree_material(int(pl["type"]))
            var s := 0.7 + 1.2 * k
            if int(pl["stage"]) == 1:
                s = 0.35 + 0.65 * ((k - 0.25) / 0.75)
            node.scale = Vector3(s, s, s)
            if k >= 1.0:
                pl["grown"] = true
                var body := StaticBody3D.new()
                var cs := CollisionShape3D.new()
                var sh := CylinderShape3D.new()
                sh.radius = 0.45
                sh.height = 3.0
                cs.shape = sh
                cs.position = Vector3(0.0, 1.5, 0.0)
                body.add_child(cs)
                body.position = pl["pos"]
                add_child(body)
                pl["body"] = body
        i -= 1


# ---------- save and load ----------

func to_dict() -> Dictionary:
    var pl: Array = []
    for p in plants:
        var ps: Vector3 = p["pos"]
        pl.append([ps.x, ps.y, ps.z, int(p["type"]), now - float(p["t0"]), bool(p["ok"])])
    return {"mods": mods, "now": now, "plants": pl}


func from_dict(d: Dictionary) -> void:
    mods = d.get("mods", {})
    now = float(d.get("now", 0.0))
    for e in d.get("plants", []):
        var pos := Vector3(float(e[0]), float(e[1]), float(e[2]))
        _spawn_plant(pos, int(e[3]), float(e[4]), bool(e[5]))
