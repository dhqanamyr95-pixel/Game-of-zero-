extends CanvasLayer

# Camera "lens" effects drawn on top of the 3D view (below the HUD):
#   - eyelashes, eyelid shadow, blinking, film vignette and grain (first person)
#   - rain / snow drops sliding on the lens, wet-lens blur (first + third person)
#   - sun glare, streak and lens ghosts when looking at the sun
# Every rect uses a transparent fallback colour, so if a shader ever fails to
# compile the game stays playable (the effect just disappears).

const EYE_CODE := """
shader_type canvas_item;

uniform float lash : hint_range(0.0, 1.0) = 1.0;
uniform float blink : hint_range(0.0, 1.0) = 0.0;
uniform float vignette : hint_range(0.0, 1.0) = 0.4;
uniform float grain : hint_range(0.0, 0.2) = 0.03;
uniform vec4 skin : source_color = vec4(0.09, 0.045, 0.035, 1.0);

float h11(float p) {
    p = fract(p * 0.1031);
    p *= p + 33.33;
    p *= p + p;
    return fract(p);
}

float h21(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

float lashes(float x, float e, float seed) {
    float n = 44.0;
    float id = floor(x * n);
    float lx = fract(x * n) - 0.5;
    float h = h11(id + seed);
    float len = 0.030 + 0.050 * h;
    float dir = sign(0.5 - (id + 0.5) / n);
    float t = clamp(e / len, 0.0, 1.0);
    float off = dir * 0.35 * t * t;
    float w = 0.07 + 0.16 * (1.0 - t);
    float c = 1.0 - smoothstep(w * 0.4, w, abs(lx - off));
    return c * (1.0 - smoothstep(len * 0.75, len, e));
}

void fragment() {
    vec2 uv = UV;
    float b = blink * 0.53;
    float top = 1.0 - smoothstep(b - 0.05, b, uv.y);
    float bot = smoothstep(1.0 - b, 1.0 - b + 0.05, uv.y);
    float lid = max(top, bot);
    if (blink <= 0.001) {
        lid = 0.0;
    }
    float lc = lashes(uv.x, uv.y, 0.0) * 0.9;
    lc = max(lc, lashes(uv.x, 1.0 - uv.y, 37.0) * 0.55);
    float shade = (1.0 - smoothstep(0.0, 0.09, uv.y)) * 0.45 + smoothstep(0.90, 1.0, uv.y) * 0.5;
    float d = length((uv - 0.5) * vec2(1.0, 0.75));
    float vig = smoothstep(0.42, 0.85, d) * vignette * 0.6;
    float a = max(lid, max(lc * 0.6 * lash, shade * lash * 0.7));
    a = max(a, vig);
    vec3 col = mix(vec3(0.0), skin.rgb, lid);
    float g = h21(uv * 900.0 + vec2(TIME * 13.0, TIME * 7.0)) - 0.5;
    a = clamp(a + abs(g) * grain, 0.0, 1.0);
    COLOR = vec4(col, a);
}
"""

const DROPS_CODE := """
shader_type canvas_item;

uniform sampler2D screen_tex : hint_screen_texture, filter_linear_mipmap;
uniform float wet : hint_range(0.0, 1.0) = 0.0;
uniform vec4 tint : source_color = vec4(1.0, 1.0, 1.0, 1.0);
uniform float slide = 1.0;

float h11(float p) {
    p = fract(p * 0.1031);
    p *= p + 33.33;
    p *= p + p;
    return fract(p);
}

float h21(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

void sliders(vec2 p, float w, float tm, out vec2 off, out float mask, out float rim, out float spec) {
    off = vec2(0.0);
    mask = 0.0;
    rim = 0.0;
    spec = 0.0;
    float cw = 0.11;
    float cid = floor(p.x / cw);
    float cx = (cid + 0.5) * cw;
    for (int k = 0; k < 2; k++) {
        float seed = cid * 7.13 + float(k) * 3.7;
        float present = step(h11(seed + 0.5), w * 0.85);
        float speed = (0.045 + 0.09 * h11(seed + 1.7)) * slide;
        float ph = h11(seed + 2.9);
        float cyc = fract(tm * speed + ph);
        float y = -0.1 + cyc * 1.25;
        y += sin(tm * 2.7 + seed * 5.0) * 0.008;
        float x = cx + (h11(seed + 4.1) - 0.5) * cw * 0.5 + sin(y * 24.0 + seed) * 0.005;
        float r = (0.013 + 0.014 * h11(seed + 5.3)) * (0.6 + 0.4 * w);
        vec2 d = p - vec2(x, y);
        float dd = length(vec2(d.x, d.y * 0.8));
        float body = (1.0 - smoothstep(r * 0.82, r, dd)) * present;
        float above = y - p.y;
        float tlen = 0.10 + 0.22 * h11(seed + 6.1);
        float tw = r * 0.38;
        float trail = step(0.0, above) * (1.0 - smoothstep(0.0, tlen, above)) * (1.0 - smoothstep(tw * 0.4, tw, abs(d.x))) * present;
        float m = max(body, trail * 0.45);
        if (m > mask) {
            mask = m;
            off = -d * 1.3 * body;
        }
        rim = max(rim, body * smoothstep(r * 0.55, r, dd));
        spec = max(spec, present * (1.0 - smoothstep(0.0, r * 0.3, length(p - vec2(x - r * 0.3, y - r * 0.35)))));
    }
}

void beads(vec2 p, float w, float tm, out vec2 off, out float mask, out float rim, out float spec) {
    float cs = 0.05;
    vec2 id = floor(p / cs);
    vec2 f = fract(p / cs) - 0.5;
    float hh = h21(id);
    float present = step(hh, w * 0.6);
    vec2 jit = vec2(h21(id + 7.1), h21(id + 13.7)) - 0.5;
    float life = fract(tm * 0.025 + hh * 7.0);
    float grow = smoothstep(0.0, 0.2, life) * (1.0 - smoothstep(0.75, 1.0, life));
    float r = max(0.0005, (0.004 + 0.011 * h21(id + 3.3)) * grow);
    vec2 c = jit * 0.4 * cs;
    vec2 d = (f * cs) - c;
    float dd = length(d);
    float body = (1.0 - smoothstep(r * 0.8, r, dd)) * present;
    mask = body;
    off = -d * 1.3 * body;
    rim = body * smoothstep(r * 0.5, r, dd);
    spec = present * (1.0 - smoothstep(0.0, r * 0.3, length(d - vec2(-r * 0.3, -r * 0.35))));
}

void fragment() {
    float aspect = SCREEN_PIXEL_SIZE.y / SCREEN_PIXEL_SIZE.x;
    vec2 p = vec2(UV.x * aspect, UV.y);
    vec2 o1 = vec2(0.0);
    float m1 = 0.0;
    float r1 = 0.0;
    float s1 = 0.0;
    vec2 o2 = vec2(0.0);
    float m2 = 0.0;
    float r2 = 0.0;
    float s2 = 0.0;
    sliders(p, wet, TIME, o1, m1, r1, s1);
    beads(p, wet, TIME, o2, m2, r2, s2);
    vec2 off = o1;
    float mask = m1;
    if (m2 > m1) {
        off = o2;
        mask = m2;
    }
    float rim = max(r1, r2);
    float spec = max(s1, s2);
    vec2 uv2 = clamp(SCREEN_UV + vec2(off.x / aspect, off.y), vec2(0.001), vec2(0.999));
    float film = wet * 1.4;
    vec3 base = textureLod(screen_tex, SCREEN_UV, film).rgb;
    vec3 inside = textureLod(screen_tex, uv2, 0.6).rgb * tint.rgb;
    inside = mix(inside, inside * 0.55, rim * 0.8);
    inside += vec3(spec) * 0.85;
    COLOR = vec4(mix(base, inside, clamp(mask, 0.0, 1.0)), 1.0);
}
"""

const FLARE_CODE := """
shader_type canvas_item;
render_mode blend_add;

uniform vec2 sun_uv = vec2(0.5, 0.2);
uniform float strength = 0.0;
uniform vec4 sun_col : source_color = vec4(1.0, 0.92, 0.75, 1.0);

float ring(vec2 p, vec2 c, float r, float w) {
    float d = abs(length(p - c) - r);
    return 1.0 - smoothstep(0.0, w, d);
}

float blob(vec2 p, vec2 c, float r) {
    return 1.0 - smoothstep(0.0, r, length(p - c));
}

void fragment() {
    float aspect = SCREEN_PIXEL_SIZE.y / SCREEN_PIXEL_SIZE.x;
    vec2 p = vec2(UV.x * aspect, UV.y);
    vec2 s = vec2(sun_uv.x * aspect, sun_uv.y);
    vec2 c = vec2(0.5 * aspect, 0.5);
    float d = length(p - s);
    float glow = exp(-d * 5.0) * 0.55 + exp(-d * 18.0) * 0.8;
    float streak = exp(-abs(p.y - s.y) * 70.0) * exp(-abs(p.x - s.x) * 2.2) * 0.6;
    vec2 v = c - s;
    float g = 0.0;
    g += blob(p, s + v * 0.35, 0.05) * 0.25;
    g += ring(p, s + v * 0.7, 0.07, 0.015) * 0.35;
    g += blob(p, s + v * 1.2, 0.09) * 0.20;
    g += ring(p, s + v * 1.6, 0.12, 0.02) * 0.25;
    vec3 col = sun_col.rgb * (glow + streak) + vec3(0.6, 0.8, 1.0) * g * 0.8;
    COLOR = vec4(col * strength, 1.0);
}
"""

var rng := RandomNumberGenerator.new()
var eye_rect: ColorRect
var drops_rect: ColorRect
var flare_rect: ColorRect
var blink_timer := 4.0
var blink_t := -1.0
var lash_amt := 0.0
var vig_amt := 0.3
var flare_amt := 0.0
var sun_uv := Vector2(0.5, 0.2)


func _ready() -> void:
    rng.randomize()
    drops_rect = _make_rect(DROPS_CODE)
    flare_rect = _make_rect(FLARE_CODE)
    eye_rect = _make_rect(EYE_CODE)
    drops_rect.visible = false
    flare_rect.visible = false


func _make_rect(code: String) -> ColorRect:
    var r := ColorRect.new()
    r.color = Color(0.0, 0.0, 0.0, 0.0)
    r.mouse_filter = Control.MOUSE_FILTER_IGNORE
    r.anchor_right = 1.0
    r.anchor_bottom = 1.0
    var sh := Shader.new()
    sh.code = code
    var m := ShaderMaterial.new()
    m.shader = sh
    r.material = m
    add_child(r)
    return r


# mode: 0 first person, 1 third person, 2 strategy view
func update(delta: float, camera: Camera3D, mode: int, sun: DirectionalLight3D, ignore_rid: RID, wet: float, snowy: bool, cloud: float) -> void:
    var first := mode == 0
    var eye_mat: ShaderMaterial = eye_rect.material

    # --- eyelashes, blinking, vignette, grain ---
    lash_amt = lerpf(lash_amt, 1.0 if first else 0.0, minf(1.0, delta * 6.0))
    var vig_target := 0.5 if first else (0.3 if mode == 1 else 0.1)
    vig_amt = lerpf(vig_amt, vig_target, minf(1.0, delta * 4.0))
    var blink := 0.0
    if first:
        blink_timer -= delta
        if blink_timer <= 0.0:
            blink_timer = rng.randf_range(3.0, 8.0)
            blink_t = 0.0
    if blink_t >= 0.0:
        blink_t += delta
        var u := blink_t / 0.24
        if u >= 1.0:
            blink_t = -1.0
        else:
            blink = pow(sin(u * PI), 0.6)
    eye_mat.set_shader_parameter("lash", lash_amt)
    eye_mat.set_shader_parameter("blink", blink)
    eye_mat.set_shader_parameter("vignette", vig_amt)

    # --- drops on the lens ---
    var w := wet if mode != 2 else 0.0
    drops_rect.visible = w > 0.01
    if drops_rect.visible:
        var dm: ShaderMaterial = drops_rect.material
        dm.set_shader_parameter("wet", w)
        dm.set_shader_parameter("tint", Color(0.92, 0.96, 1.0) if snowy else Color(1.0, 1.0, 1.0))
        dm.set_shader_parameter("slide", 0.35 if snowy else 1.0)

    # --- sun glare ---
    var target_flare := 0.0
    if mode != 2 and sun != null:
        var sun_dir := sun.global_transform.basis.z.normalized()
        var cam_pos := camera.global_position
        var far_pt := cam_pos + sun_dir * 800.0
        if sun_dir.y > 0.03 and not camera.is_position_behind(far_pt):
            var vp := get_viewport().get_visible_rect().size
            var sp := camera.unproject_position(far_pt)
            sun_uv = Vector2(sp.x / vp.x, sp.y / vp.y)
            var fwd := -camera.global_transform.basis.z
            var look := smoothstep(0.5, 0.97, fwd.dot(sun_dir))
            if look > 0.0:
                var q := PhysicsRayQueryParameters3D.create(cam_pos, far_pt)
                q.exclude = [ignore_rid]
                var blocked := not camera.get_world_3d().direct_space_state.intersect_ray(q).is_empty()
                if not blocked:
                    target_flare = look * (1.0 - cloud)
    flare_amt = lerpf(flare_amt, target_flare, minf(1.0, delta * 5.0))
    flare_rect.visible = flare_amt > 0.01
    if flare_rect.visible:
        var fm: ShaderMaterial = flare_rect.material
        fm.set_shader_parameter("sun_uv", sun_uv)
        fm.set_shader_parameter("strength", flare_amt)
