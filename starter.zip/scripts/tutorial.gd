extends Node

# One-time tutorial. It shows one hint at a time and moves on when the player does
# the thing. After the last step it is saved as done and never shown again
# (the player can replay it from Settings).

const I18n = preload("res://scripts/i18n.gd")
const Settings = preload("res://scripts/settings.gd")

var player = null
var camp = null
var hud = null
var active := false
var step := 0
var timer := 0.0


func setup(p, c, h) -> void:
    player = p
    camp = c
    hud = h


func begin() -> void:
    if Settings.tutorial_done():
        return
    active = true
    step = 0
    timer = 0.0
    if hud != null:
        hud.look_total = 0.0


func _process(delta: float) -> void:
    if not active or hud == null:
        return
    match step:
        0:
            hud.tutorial_text = I18n.t("tut_move")
            if hud.move.length() > 0.3:
                timer += delta
            if timer > 1.5:
                _next()
        1:
            hud.tutorial_text = I18n.t("tut_look")
            if hud.look_total > 350.0:
                _next()
        2:
            hud.tutorial_text = I18n.t("tut_gather")
            if camp.fires.size() > 0:
                step = 4
                timer = 0.0
            elif camp.wood >= 3 and camp.stone >= 2:
                _next()
        3:
            hud.tutorial_text = I18n.t("tut_fire")
            if camp.fires.size() > 0:
                _next()
        4:
            hud.tutorial_text = I18n.t("tut_done")
            timer += delta
            if timer > 4.0:
                hud.tutorial_text = ""
                Settings.set_tutorial_done(true)
                active = false


func _next() -> void:
    step += 1
    timer = 0.0
