extends RefCounted

# Save file helper (JSON in the app's private storage).

const PATH := "user://savegame.json"


static func exists() -> bool:
    return FileAccess.file_exists(PATH)


static func write(d: Dictionary) -> void:
    var f := FileAccess.open(PATH, FileAccess.WRITE)
    if f != null:
        f.store_string(JSON.stringify(d))
        f.close()


static func read() -> Dictionary:
    if not exists():
        return {}
    var f := FileAccess.open(PATH, FileAccess.READ)
    if f == null:
        return {}
    var txt := f.get_as_text()
    f.close()
    var parsed = JSON.parse_string(txt)
    if typeof(parsed) == TYPE_DICTIONARY:
        return parsed
    return {}
