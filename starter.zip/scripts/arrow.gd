extends Node3D

# A simple arrow: flies in an arc, sticks into the first thing it hits.

var vel := Vector3.ZERO
var life := 8.0
var stuck := false


func _ready() -> void:
    var cm := CylinderMesh.new()
    cm.top_radius = 0.012
    cm.bottom_radius = 0.012
    cm.height = 0.8
    cm.radial_segments = 4
    cm.rings = 1
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.55, 0.42, 0.25)
    cm.material = mat
    var mi := MeshInstance3D.new()
    mi.mesh = cm
    mi.rotation_degrees.x = 90.0
    add_child(mi)


func _physics_process(delta: float) -> void:
    life -= delta
    if life <= 0.0:
        queue_free()
        return
    if stuck:
        return
    vel.y -= 9.8 * delta
    var from := global_position
    var to := from + vel * delta
    var q := PhysicsRayQueryParameters3D.create(from, to)
    var hit := get_world_3d().direct_space_state.intersect_ray(q)
    if not hit.is_empty():
        global_position = hit["position"]
        stuck = true
        life = 6.0
        return
    global_position = to
    var d := vel.normalized()
    if absf(d.dot(Vector3.UP)) < 0.98:
        look_at(global_position + d, Vector3.UP)
