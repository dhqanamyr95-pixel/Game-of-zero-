extends Node3D

# A simple hut with a real doorway. Walls are separate solid boxes, the terrain
# under it is flat, so the player can walk in and out without getting stuck.

const W := 6.0
const D := 6.0
const H := 3.0
const T := 0.3
const DOOR := 1.8


func build() -> void:
    var wall := StandardMaterial3D.new()
    wall.albedo_color = Color(0.46, 0.33, 0.20)
    wall.roughness = 1.0
    var roof := StandardMaterial3D.new()
    roof.albedo_color = Color(0.68, 0.56, 0.28)
    roof.roughness = 1.0

    # back wall
    _box(Vector3(W + T, H, T), Vector3(0, H * 0.5, -D * 0.5), wall)
    # side walls
    _box(Vector3(T, H, D), Vector3(-W * 0.5, H * 0.5, 0), wall)
    _box(Vector3(T, H, D), Vector3(W * 0.5, H * 0.5, 0), wall)
    # front wall with a door gap in the middle
    var seg := ((W + T) - DOOR) * 0.5
    var off := DOOR * 0.5 + seg * 0.5
    _box(Vector3(seg, H, T), Vector3(-off, H * 0.5, D * 0.5), wall)
    _box(Vector3(seg, H, T), Vector3(off, H * 0.5, D * 0.5), wall)
    # lintel above the door
    _box(Vector3(DOOR, 0.7, T), Vector3(0, H - 0.35, D * 0.5), wall)
    # roof
    _box(Vector3(W + 1.4, 0.25, D + 1.4), Vector3(0, H + 0.125, 0), roof)


func _box(size: Vector3, pos: Vector3, mat: Material) -> void:
    var body := StaticBody3D.new()
    body.position = pos
    add_child(body)
    var cs := CollisionShape3D.new()
    var sh := BoxShape3D.new()
    sh.size = size
    cs.shape = sh
    body.add_child(cs)
    var mi := MeshInstance3D.new()
    var bm := BoxMesh.new()
    bm.size = size
    bm.material = mat
    mi.mesh = bm
    body.add_child(mi)
