extends CanvasLayer

# Shop and wardrobe. While it is open the camera turns to look at the character,
# so every piece can be tried on before it is bought. Premium pieces cost gems
# (tap twice to buy), free pieces unlock during the first 10 game days.

const I18n = preload("res://scripts/i18n.gd")
const Outfits = preload("res://scripts/outfits.gd")
const Wardrobe = preload("res://scripts/wardrobe.gd")
const Billing = preload("res://scripts/billing.gd")

const TABS := ["shirt", "pants", "shoes", "hat", "mask", "look", "gems"]
const LOOK_KEYS := [["skin", 6, "look_skin"], ["hair", 6, "look_hair"], ["hair_color", 8, "look_hair_color"], ["beard", 4, "look_beard"]]
const GOLD := Color(0.95, 0.75, 0.35)

var player = null
var hud = null
var daynight = null
var root: Control = null
var content: VBoxContainer = null
var info: Label = null
var gems_label: Label = null
var tab := "shirt"
var pending := ""
var buttons := {}
var is_open := false


func setup(p, h, d) -> void:
    player = p
    hud = h
    daynight = d
    layer = 6


func toggle() -> void:
    if is_open:
        close()
    else:
        open()


func open() -> void:
    if is_open:
        return
    is_open = true
    pending = ""
    hud.visible = false
    player.input_enabled = false
    player.preview = true
    _build()


func close() -> void:
    if not is_open:
        return
    is_open = false
    Wardrobe.save_all()
    _apply_equipped()
    player.preview = false
    if root != null:
        root.queue_free()
        root = null
    hud.visible = true
    player.input_enabled = true


func _apply_equipped() -> void:
    if player.model.has_method("set_outfit"):
        player.model.set_outfit(Wardrobe.equipped)


func _label(text: String, size_px: int, col: Color) -> Label:
    var l := Label.new()
    l.text = text
    l.add_theme_font_size_override("font_size", size_px)
    l.add_theme_color_override("font_color", col)
    return l


func _style(btn: Button, border: Color, selected: bool) -> void:
    var s := StyleBoxFlat.new()
    if selected:
        s.bg_color = Color(0.20, 0.16, 0.10)
    else:
        s.bg_color = Color(0.14, 0.12, 0.09)
    s.border_color = border
    s.border_width_left = 10
    s.set_corner_radius_all(8)
    s.content_margin_left = 20
    s.content_margin_right = 12
    s.content_margin_top = 8
    s.content_margin_bottom = 8
    if selected:
        s.border_width_top = 2
        s.border_width_right = 2
        s.border_width_bottom = 2
    btn.add_theme_stylebox_override("normal", s)
    btn.add_theme_stylebox_override("hover", s)
    btn.add_theme_stylebox_override("pressed", s)
    btn.add_theme_stylebox_override("disabled", s)


func _build() -> void:
    if root != null:
        root.queue_free()
    root = Control.new()
    root.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(root)
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    if I18n.is_rtl():
        root.layout_direction = Control.LAYOUT_DIRECTION_RTL

    var panel := PanelContainer.new()
    panel.custom_minimum_size = Vector2(640, 0)
    var sb := StyleBoxFlat.new()
    sb.bg_color = Color(0.08, 0.07, 0.05, 0.94)
    sb.border_color = GOLD
    sb.set_border_width_all(3)
    sb.set_corner_radius_all(14)
    sb.content_margin_left = 18
    sb.content_margin_right = 18
    sb.content_margin_top = 16
    sb.content_margin_bottom = 16
    panel.add_theme_stylebox_override("panel", sb)
    root.add_child(panel)
    if I18n.is_rtl():
        panel.set_anchors_and_offsets_preset(Control.PRESET_RIGHT_WIDE)
    else:
        panel.set_anchors_and_offsets_preset(Control.PRESET_LEFT_WIDE)

    var vb := VBoxContainer.new()
    vb.add_theme_constant_override("separation", 10)
    panel.add_child(vb)

    var head := HBoxContainer.new()
    vb.add_child(head)
    var title := _label(I18n.t("shop"), 34, GOLD)
    title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    head.add_child(title)
    gems_label = _label("", 24, Color(0.6, 0.9, 1.0))
    head.add_child(gems_label)
    var cb := Button.new()
    cb.text = I18n.t("close")
    cb.custom_minimum_size = Vector2(120, 48)
    cb.add_theme_font_size_override("font_size", 22)
    cb.pressed.connect(close)
    head.add_child(cb)

    var tabs := HFlowContainer.new()
    tabs.add_theme_constant_override("h_separation", 8)
    tabs.add_theme_constant_override("v_separation", 8)
    vb.add_child(tabs)
    for tn in TABS:
        var t: String = tn
        var tbn := Button.new()
        tbn.text = I18n.t("tab_" + t)
        tbn.custom_minimum_size = Vector2(0, 46)
        tbn.add_theme_font_size_override("font_size", 20)
        _style(tbn, GOLD, t == tab)
        tbn.pressed.connect(_on_tab.bind(t))
        tabs.add_child(tbn)

    var scroll := ScrollContainer.new()
    scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
    scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    vb.add_child(scroll)
    content = VBoxContainer.new()
    content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    content.add_theme_constant_override("separation", 10)
    scroll.add_child(content)

    info = _label("", 22, Color(1.0, 0.9, 0.6))
    vb.add_child(info)
    _show_tab()


func _on_tab(t: String) -> void:
    tab = t
    pending = ""
    _apply_equipped()
    _build()


func _show_tab() -> void:
    buttons = {}
    for ch in content.get_children():
        ch.queue_free()
    if tab == "look":
        _tab_look()
    elif tab == "gems":
        _tab_gems()
    else:
        _tab_items()
    _refresh()


func _tab_items() -> void:
    var grid := GridContainer.new()
    grid.columns = 2
    grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    grid.add_theme_constant_override("h_separation", 10)
    grid.add_theme_constant_override("v_separation", 10)
    content.add_child(grid)
    var list: Array = Outfits.catalog(tab)
    for entry in list:
        var it: Dictionary = entry
        var id: String = String(it["id"])
        var b := Button.new()
        b.custom_minimum_size = Vector2(280, 86)
        b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        b.add_theme_font_size_override("font_size", 19)
        b.alignment = HORIZONTAL_ALIGNMENT_LEFT
        b.pressed.connect(_on_item.bind(id))
        grid.add_child(b)
        buttons[id] = b


func _refresh() -> void:
    gems_label.text = "%d %s" % [Wardrobe.gems, I18n.t("gems_word")]
    var day := int(daynight.day_number())
    for key in buttons.keys():
        var id: String = String(key)
        var b: Button = buttons[key]
        var item: Dictionary = Outfits.find(id)
        var cat: String = String(item["cat"])
        var owned: bool = Wardrobe.is_owned(item, day)
        var worn: bool = String(Wardrobe.equipped.get(cat, "")) == id
        var status := ""
        if owned:
            if worn:
                status = I18n.t("equipped_word")
            else:
                status = I18n.t("owned_word")
        elif bool(item["premium"]):
            status = "%d %s" % [int(item["price"]), I18n.t("gems_word")]
        else:
            status = I18n.t("locked_day") % int(item["day"])
        if pending == id:
            status = I18n.t("buy_again")
        b.text = Outfits.item_name(item) + "\n" + status
        b.disabled = (not owned) and (not bool(item["premium"]))
        _style(b, Outfits.color_of(item), worn or pending == id)


func _on_item(id: String) -> void:
    var item: Dictionary = Outfits.find(id)
    if item.is_empty():
        return
    var cat: String = String(item["cat"])
    var day := int(daynight.day_number())
    info.text = ""
    if Wardrobe.is_owned(item, day):
        var worn: bool = String(Wardrobe.equipped.get(cat, "")) == id
        if worn and cat != "shirt" and cat != "pants":
            Wardrobe.equipped[cat] = ""
        else:
            Wardrobe.equipped[cat] = id
        pending = ""
        _apply_equipped()
    else:
        if pending != id:
            pending = id
            if player.model.has_method("set_outfit_part"):
                player.model.set_outfit_part(cat, id)
            info.text = I18n.t("buy_again")
        else:
            var r: String = Wardrobe.buy(item)
            if r == "ok":
                Wardrobe.equipped[cat] = id
                pending = ""
                _apply_equipped()
                info.text = I18n.t("bought")
            elif r == "no_gems":
                info.text = I18n.t("not_enough_gems")
    _refresh()


func _tab_look() -> void:
    for entry in LOOK_KEYS:
        var key: String = String(entry[0])
        var count: int = int(entry[1])
        var b := Button.new()
        b.custom_minimum_size = Vector2(0, 70)
        b.add_theme_font_size_override("font_size", 24)
        b.text = "%s:  %d / %d" % [I18n.t(String(entry[2])), int(Wardrobe.look.get(key, 0)) + 1, count]
        _style(b, GOLD, false)
        b.pressed.connect(_on_look.bind(key, count))
        content.add_child(b)


func _on_look(key: String, count: int) -> void:
    Wardrobe.look[key] = (int(Wardrobe.look.get(key, 0)) + 1) % count
    if player.model.has_method("set_look"):
        player.model.set_look(Wardrobe.look)
    _show_tab()


func _tab_gems() -> void:
    var unit := "Toman"
    if I18n.current == "fa":
        unit = "تومان"
    for entry in Billing.PACKS:
        var pk: Dictionary = entry
        var b := Button.new()
        b.custom_minimum_size = Vector2(0, 70)
        b.add_theme_font_size_override("font_size", 24)
        b.text = "%d %s     %s %s" % [int(pk["gems"]), I18n.t("gems_word"), Billing.format_number(int(pk["toman"])), unit]
        _style(b, Color(0.4, 0.8, 1.0), false)
        b.pressed.connect(_on_pack.bind(String(pk["id"])))
        content.add_child(b)
    if OS.is_debug_build():
        var d := Button.new()
        d.custom_minimum_size = Vector2(0, 60)
        d.add_theme_font_size_override("font_size", 22)
        d.text = I18n.t("dev_gems")
        _style(d, Color(0.6, 0.6, 0.6), false)
        d.pressed.connect(_on_dev_gems)
        content.add_child(d)


func _on_pack(pack_id: String) -> void:
    var r: String = Billing.purchase(pack_id)
    if r == "unavailable":
        info.text = I18n.t("payment_unavailable")


func _on_dev_gems() -> void:
    Wardrobe.gems += 500
    Wardrobe.save_all()
    _refresh()
