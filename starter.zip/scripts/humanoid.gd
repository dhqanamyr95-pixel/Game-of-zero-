extends Node3D

# Procedural early-human character (placeholder for a real rigged GLB model later).
# Front of the character is -Z. All limbs are jointed pivots animated by animate().

const HIP_Y := 0.93

var hips: Node3D
var spine: Node3D
var head: Node3D
var arm_l: Node3D
var arm_r: Node3D
var elbow_l: Node3D
var elbow_r: Node3D
var hand_l: Node3D
var hand_r: Node3D
var leg_l: Node3D
var leg_r: Node3D
var knee_l: Node3D
var knee_r: Node3D
var torch: Node3D
var phase := 0.0
var idle_t := 0.0


func _mat(c: Color, rough: float = 0.9) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = c
    m.roughness = rough
    return m


func _mesh(parent: Node3D, mesh: Mesh, mat: Material, pos: Vector3 = Vector3.ZERO, scl: Vector3 = Vector3.ONE) -> MeshInstance3D:
    var mi := MeshInstance3D.new()
    mi.mesh = mesh
    mi.material_override = mat
    mi.position = pos
    mi.scale = scl
    parent.add_child(mi)
    return mi


func _capsule(r: float, h: float) -> CapsuleMesh:
    var m := CapsuleMesh.new()
    m.radius = r
    m.height = h
    m.radial_segments = 12
    m.rings = 4
    return m


func _sphere(r: float) -> SphereMesh:
    var m := SphereMesh.new()
    m.radius = r
    m.height = r * 2.0
    m.radial_segments = 16
    m.rings = 8
    return m


func _box(s: Vector3) -> BoxMesh:
    var m := BoxMesh.new()
    m.size = s
    return m


func _cyl(rt: float, rb: float, h: float) -> CylinderMesh:
    var m := CylinderMesh.new()
    m.top_radius = rt
    m.bottom_radius = rb
    m.height = h
    m.radial_segments = 10
    m.rings = 1
    return m


func build() -> void:
    var skin := _mat(Color(0.74, 0.54, 0.38))
    var hair := _mat(Color(0.10, 0.07, 0.05), 1.0)
    var fur := _mat(Color(0.38, 0.26, 0.15), 1.0)
    var fur2 := _mat(Color(0.27, 0.18, 0.10), 1.0)
    var wood := _mat(Color(0.30, 0.20, 0.12), 1.0)
    var dark := _mat(Color(0.03, 0.03, 0.03), 0.4)
    var wrap := _mat(Color(0.33, 0.24, 0.15), 1.0)

    hips = Node3D.new()
    hips.position.y = HIP_Y
    add_child(hips)
    _mesh(hips, _box(Vector3(0.32, 0.17, 0.20)), skin)
    _mesh(hips, _box(Vector3(0.36, 0.30, 0.24)), fur, Vector3(0, -0.12, 0))

    spine = Node3D.new()
    spine.position.y = 0.06
    hips.add_child(spine)
    _mesh(spine, _capsule(0.165, 0.60), skin, Vector3(0, 0.27, 0), Vector3(1.12, 1.0, 0.78))
    _mesh(spine, _box(Vector3(0.54, 0.12, 0.32)), fur2, Vector3(0, 0.49, 0))
    _mesh(spine, _cyl(0.05, 0.055, 0.10), skin, Vector3(0, 0.58, 0))

    head = Node3D.new()
    head.position = Vector3(0, 0.70, 0)
    spine.add_child(head)
    _mesh(head, _sphere(0.105), skin, Vector3.ZERO, Vector3(0.95, 1.10, 1.0))
    var cap := SphereMesh.new()
    cap.radius = 0.112
    cap.height = 0.112
    cap.is_hemisphere = true
    cap.radial_segments = 16
    cap.rings = 6
    _mesh(head, cap, hair, Vector3(0, 0.03, 0.012), Vector3(1.0, 1.1, 1.05))
    _mesh(head, _sphere(0.068), hair, Vector3(0, -0.078, -0.040), Vector3(1.0, 0.9, 0.8))
    _mesh(head, _sphere(0.014), dark, Vector3(-0.04, 0.0, -0.094))
    _mesh(head, _sphere(0.014), dark, Vector3(0.04, 0.0, -0.094))
    _mesh(head, _box(Vector3(0.12, 0.022, 0.03)), skin, Vector3(0, 0.022, -0.092))
    _mesh(head, _box(Vector3(0.025, 0.04, 0.04)), skin, Vector3(0, -0.022, -0.103))

    var a_l := _make_arm(spine, -1.0, skin)
    arm_l = a_l[0]
    elbow_l = a_l[1]
    hand_l = a_l[2]
    var a_r := _make_arm(spine, 1.0, skin)
    arm_r = a_r[0]
    elbow_r = a_r[1]
    hand_r = a_r[2]

    var l_l := _make_leg(hips, -1.0, skin, wrap)
    leg_l = l_l[0]
    knee_l = l_l[1]
    var l_r := _make_leg(hips, 1.0, skin, wrap)
    leg_r = l_r[0]
    knee_r = l_r[1]

    # wooden club in the right hand
    var club := Node3D.new()
    club.rotation_degrees.x = -60.0
    hand_r.add_child(club)
    _mesh(club, _cyl(0.032, 0.04, 0.62), wood, Vector3(0, 0.20, 0))
    _mesh(club, _sphere(0.085), wood, Vector3(0, 0.52, 0), Vector3(1.0, 1.3, 1.0))

    # torch in the left hand (hidden until toggled)
    torch = Node3D.new()
    torch.rotation_degrees.x = -25.0
    torch.visible = false
    hand_l.add_child(torch)
    _mesh(torch, _cyl(0.03, 0.035, 0.55), wood, Vector3(0, 0.18, 0))
    var flame_mat := StandardMaterial3D.new()
    flame_mat.albedo_color = Color(1.0, 0.55, 0.12)
    flame_mat.emission_enabled = true
    flame_mat.emission = Color(1.0, 0.5, 0.1)
    flame_mat.emission_energy_multiplier = 2.5
    _mesh(torch, _sphere(0.07), flame_mat, Vector3(0, 0.50, 0), Vector3(1.0, 1.5, 1.0))
    var light := OmniLight3D.new()
    light.light_color = Color(1.0, 0.65, 0.3)
    light.light_energy = 2.5
    light.omni_range = 12.0
    light.position = Vector3(0, 0.55, 0)
    torch.add_child(light)


func _make_arm(parent: Node3D, side: float, skin: Material) -> Array:
    var shoulder := Node3D.new()
    shoulder.position = Vector3(0.215 * side, 0.50, 0)
    parent.add_child(shoulder)
    _mesh(shoulder, _sphere(0.065), skin)
    _mesh(shoulder, _capsule(0.055, 0.30), skin, Vector3(0, -0.15, 0))
    var elbow := Node3D.new()
    elbow.position = Vector3(0, -0.30, 0)
    shoulder.add_child(elbow)
    _mesh(elbow, _capsule(0.047, 0.28), skin, Vector3(0, -0.14, 0))
    var hand := Node3D.new()
    hand.position = Vector3(0, -0.29, 0)
    elbow.add_child(hand)
    _mesh(hand, _sphere(0.05), skin)
    return [shoulder, elbow, hand]


func _make_leg(parent: Node3D, side: float, skin: Material, wrap: Material) -> Array:
    var hip := Node3D.new()
    hip.position = Vector3(0.09 * side, -0.05, 0)
    parent.add_child(hip)
    _mesh(hip, _capsule(0.078, 0.46), skin, Vector3(0, -0.22, 0))
    var knee := Node3D.new()
    knee.position = Vector3(0, -0.44, 0)
    hip.add_child(knee)
    _mesh(knee, _capsule(0.062, 0.44), skin, Vector3(0, -0.21, 0))
    _mesh(knee, _cyl(0.07, 0.066, 0.16), wrap, Vector3(0, -0.12, 0))
    _mesh(knee, _box(Vector3(0.095, 0.06, 0.26)), wrap, Vector3(0, -0.41, -0.05))
    return [hip, knee]


func set_torch(on: bool) -> void:
    torch.visible = on


# speed_ratio: 0 = standing, 1 = walking, ~2 = sprinting. cb = crouch blend 0..1.
# attack: -1 when not attacking, else 0..1 progress of the swing.
func animate(delta: float, speed_ratio: float, on_floor: bool, cb: float, attack: float) -> void:
    idle_t += delta
    var amp := clampf(speed_ratio, 0.0, 2.0)
    phase += delta * (3.0 + amp * 3.4)
    var s := sin(phase)
    var c := cos(phase)
    var swing := 0.5 * minf(amp, 1.6)
    var k := minf(amp, 1.0)

    var thigh_l := s * swing * 1.1
    var thigh_r := -s * swing * 1.1
    var bend_l := maxf(0.0, c) * (0.35 + 0.5 * amp) * k
    var bend_r := maxf(0.0, -c) * (0.35 + 0.5 * amp) * k
    var swing_arm_l := -s * swing * 0.9
    var swing_arm_r := s * swing * 0.9
    var sway := sin(idle_t * 1.6) * 0.03 * (1.0 - k)

    if not on_floor:
        thigh_l = 0.6
        thigh_r = -0.15
        bend_l = 0.5
        bend_r = 0.2
        swing_arm_l = -0.5
        swing_arm_r = 0.5

    leg_l.rotation.x = thigh_l + 0.9 * cb
    leg_r.rotation.x = thigh_r + 0.9 * cb
    knee_l.rotation.x = -bend_l - 1.4 * cb
    knee_r.rotation.x = -bend_r - 1.4 * cb

    arm_l.rotation.x = swing_arm_l + sway
    arm_r.rotation.x = swing_arm_r - sway
    elbow_l.rotation.x = 0.15 + 0.35 * amp
    elbow_r.rotation.x = 0.15 + 0.35 * amp

    var twist := 0.0
    if attack >= 0.0:
        var a := 0.0
        if attack < 0.3:
            a = lerpf(0.0, 2.7, attack / 0.3)
        elif attack < 0.6:
            var u := (attack - 0.3) / 0.3
            a = lerpf(2.7, 0.2, u * u)
        else:
            a = lerpf(0.2, 0.0, (attack - 0.6) / 0.4)
        arm_r.rotation.x = a
        elbow_r.rotation.x = 0.7
        twist = sin(attack * PI) * 0.3

    spine.rotation = Vector3(-0.10 * amp - 0.30 * cb, twist, 0.0)
    spine.scale = Vector3(1.0, 1.0 + sin(idle_t * 2.2) * 0.008, 1.0)
    hips.position.y = HIP_Y - 0.22 * cb + absf(s) * 0.025 * minf(amp, 1.5)
