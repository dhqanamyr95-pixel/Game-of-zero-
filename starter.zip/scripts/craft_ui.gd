extends CanvasLayer

# Crafting menu. Recipes unlock on a game day (see items.gd). While it is open the
# touch controls are hidden and the player stands still.

const I18n = preload("res://scripts/i18n.gd")
const Items = preload("res://scripts/items.gd")

var camp = null
var hud = null
var player = null
var daynight = null
var root: Control = null
var info: Label = null
var last_msg := ""
var is_open := false


func setup(c, h, p, d) -> void:
    camp = c
    hud = h
    player = p
    daynight = d
    layer = 6


func toggle() -> void:
    if is_open:
        close()
    else:
        open()


func open() -> void:
    if is_open:
        return
    is_open = true
    last_msg = ""
    hud.visible = false
    player.input_enabled = false
    _build()


func close() -> void:
    if not is_open:
        return
    is_open = false
    if root != null:
        root.queue_free()
        root = null
    hud.visible = true
    player.input_enabled = true


func _label(text: String, size_px: int, col: Color) -> Label:
    var l := Label.new()
    l.text = text
    l.add_theme_font_size_override("font_size", size_px)
    l.add_theme_color_override("font_color", col)
    return l


func _build() -> void:
    if root != null:
        root.queue_free()
    root = Control.new()
    add_child(root)
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    if I18n.is_rtl():
        root.layout_direction = Control.LAYOUT_DIRECTION_RTL

    var dim := ColorRect.new()
    dim.color = Color(0, 0, 0, 0.65)
    root.add_child(dim)
    dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

    var center := CenterContainer.new()
    root.add_child(center)
    center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

    var panel := PanelContainer.new()
    panel.custom_minimum_size = Vector2(980, 560)
    var sb := StyleBoxFlat.new()
    sb.bg_color = Color(0.10, 0.08, 0.06, 0.96)
    sb.border_color = Color(0.95, 0.75, 0.35)
    sb.set_border_width_all(3)
    sb.set_corner_radius_all(16)
    sb.content_margin_left = 24
    sb.content_margin_right = 24
    sb.content_margin_top = 20
    sb.content_margin_bottom = 20
    panel.add_theme_stylebox_override("panel", sb)
    center.add_child(panel)

    var vb := VBoxContainer.new()
    vb.add_theme_constant_override("separation", 14)
    panel.add_child(vb)

    var head := HBoxContainer.new()
    vb.add_child(head)
    var title := _label("%s    %s" % [I18n.t("craft"), I18n.t("locked_day") % int(daynight.day_number())], 36, Color(0.95, 0.75, 0.35))
    title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    head.add_child(title)
    var cb := Button.new()
    cb.text = I18n.t("close")
    cb.custom_minimum_size = Vector2(150, 56)
    cb.add_theme_font_size_override("font_size", 24)
    cb.pressed.connect(close)
    head.add_child(cb)

    var have := ""
    for id in Items.MATERIAL_IDS:
        have += "%s %d    " % [I18n.t("item_" + String(id)), int(camp.items.get(id, 0))]
    vb.add_child(_label(have, 22, Color(0.85, 0.85, 0.8)))

    var scroll := ScrollContainer.new()
    scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
    scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    vb.add_child(scroll)
    var list := VBoxContainer.new()
    list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    list.add_theme_constant_override("separation", 10)
    scroll.add_child(list)
    for r in Items.RECIPES:
        list.add_child(_row(r))

    info = _label(last_msg, 24, Color(1.0, 0.9, 0.6))
    vb.add_child(info)


func _row(r: Dictionary) -> Control:
    var id := String(r["id"])
    var day := int(r["day"])
    var cost: Dictionary = r["cost"]
    var locked := int(daynight.day_number()) < day
    var enough: bool = camp.has_cost(cost)

    var row := PanelContainer.new()
    var sb := StyleBoxFlat.new()
    sb.bg_color = Color(0.17, 0.14, 0.10)
    sb.set_corner_radius_all(10)
    sb.content_margin_left = 16
    sb.content_margin_right = 16
    sb.content_margin_top = 10
    sb.content_margin_bottom = 10
    row.add_theme_stylebox_override("panel", sb)
    var h := HBoxContainer.new()
    h.add_theme_constant_override("separation", 16)
    row.add_child(h)

    var title := _label(I18n.t("item_" + id), 26, Color(1.0, 0.95, 0.85))
    title.custom_minimum_size = Vector2(290, 0)
    h.add_child(title)

    var parts := ""
    for k in cost.keys():
        parts += "%s %d/%d    " % [I18n.t("item_" + String(k)), mini(int(camp.items.get(k, 0)), int(cost[k])), int(cost[k])]
    var col := Color(0.55, 0.9, 0.55)
    if not enough:
        col = Color(1.0, 0.5, 0.45)
    var need := _label(parts, 22, col)
    need.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    h.add_child(need)

    var b := Button.new()
    b.custom_minimum_size = Vector2(170, 56)
    b.add_theme_font_size_override("font_size", 24)
    if locked:
        b.text = I18n.t("locked_day") % day
        b.disabled = true
    else:
        b.text = I18n.t("craft_btn")
        b.disabled = not enough
        b.pressed.connect(_craft.bind(id))
    h.add_child(b)
    return row


func _craft(id: String) -> void:
    var key: String = camp.craft(id)
    if key == "fire_built" or key == "cant_build":
        close()
        camp.msg_key(key)
        return
    last_msg = I18n.t(key) if key != "" else ""
    _build()
