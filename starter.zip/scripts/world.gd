extends Node3D

signal exit_requested

const Maps = preload("res://scripts/maps.gd")
const TerrainScript = preload("res://scripts/terrain.gd")
const HutScript = preload("res://scripts/hut.gd")
const PlayerScript = preload("res://scripts/player.gd")
const HudScript = preload("res://scripts/hud.gd")
const AudioScript = preload("res://scripts/audio.gd")
const WeatherScript = preload("res://scripts/weather.gd")
const LensScript = preload("res://scripts/lens.gd")
const DayNightScript = preload("res://scripts/daynight.gd")
const SurvivalScript = preload("res://scripts/survival.gd")
const CampScript = preload("res://scripts/camp.gd")
const Save = preload("res://scripts/save.gd")
const I18n = preload("res://scripts/i18n.gd")

const INTRO_LEN := 9.0

var map_id: String = "savanna"
var p: Dictionary = {}
var terrain
var player
var hud
var intro_cam: Camera3D
var intro_t := 0.0
var intro_active := true
var ui_layer: CanvasLayer
var bars: Array = []
var title_label: Label
var lens
var weather
var daynight
var survival
var camp
var load_data := {}
var skip_intro := false
var save_t := 0.0
var sun_node: DirectionalLight3D
var env_ref: Environment
var sky_mat_ref: ProceduralSkyMaterial


func _ready() -> void:
    p = Maps.get_map(map_id)
    _setup_environment()
    terrain = TerrainScript.new()
    terrain.name = "Terrain"
    add_child(terrain)
    terrain.build(p)
    _add_water()
    _add_trees()
    _add_rocks()

    var hut = HutScript.new()
    hut.position = Vector3(0, terrain.plateau_h, -6)
    add_child(hut)
    hut.build()

    player = PlayerScript.new()
    player.position = Vector3(0, terrain.plateau_h + 0.2, 6)
    player.height_fn = Callable(terrain, "height_at")
    add_child(player)

    var audio = AudioScript.new()
    audio.name = "Audio"
    add_child(audio)
    audio.setup(p)
    player.audio = audio

    weather = WeatherScript.new()
    weather.name = "Weather"
    add_child(weather)
    weather.setup(p, player, audio)

    daynight = DayNightScript.new()
    daynight.name = "DayNight"
    add_child(daynight)
    daynight.setup(p, player, env_ref, sky_mat_ref, sun_node, weather, audio)

    survival = SurvivalScript.new()
    survival.name = "Survival"
    add_child(survival)
    survival.setup(p, player, terrain, audio)

    camp = CampScript.new()
    camp.name = "Camp"
    add_child(camp)
    camp.setup(p, player, terrain, audio)
    survival.camp = camp

    _build_ui()
    _start_intro()
    if not load_data.is_empty():
        _apply_save()
        _end_intro()
    if skip_intro:
        _end_intro()


# ---------- environment ----------

func _setup_environment() -> void:
    var sky_mat := ProceduralSkyMaterial.new()
    sky_mat.sky_top_color = p["sky_top"]
    sky_mat.sky_horizon_color = p["sky_hor"]
    sky_mat.ground_horizon_color = p["sky_hor"]
    sky_mat.ground_bottom_color = Color(0.2, 0.22, 0.2)
    var sky := Sky.new()
    sky.sky_material = sky_mat
    var env := Environment.new()
    env.background_mode = Environment.BG_SKY
    env.sky = sky
    env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
    env.ambient_light_energy = 0.9
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    env.fog_enabled = true
    env.fog_light_color = p["fog"]
    env.fog_density = float(p["fog_d"])
    var we := WorldEnvironment.new()
    we.environment = env
    add_child(we)

    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = p["sun_rot"]
    sun.light_color = p["sun_color"]
    sun.light_energy = float(p["sun_energy"])
    sun.shadow_enabled = true
    sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS
    sun.directional_shadow_max_distance = 70.0
    add_child(sun)
    sun_node = sun
    env_ref = env
    sky_mat_ref = sky_mat


func _add_water() -> void:
    var pm := PlaneMesh.new()
    pm.size = Vector2(1600.0, 1600.0)
    var mat := StandardMaterial3D.new()
    mat.albedo_color = p["water"]
    mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    mat.roughness = 0.15
    mat.cull_mode = BaseMaterial3D.CULL_DISABLED
    pm.material = mat
    var mi := MeshInstance3D.new()
    mi.mesh = pm
    mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    add_child(mi)


func _std_mat(c: Color) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = c
    m.roughness = 1.0
    return m


func _make_mm(mesh: Mesh, xforms: Array) -> void:
    var mm := MultiMesh.new()
    mm.transform_format = MultiMesh.TRANSFORM_3D
    mm.mesh = mesh
    mm.instance_count = xforms.size()
    for i in xforms.size():
        mm.set_instance_transform(i, xforms[i])
    var mmi := MultiMeshInstance3D.new()
    mmi.multimesh = mm
    add_child(mmi)


func _add_trees() -> void:
    var count: int = p["tree_count"]
    if count <= 0:
        return
    var rng := RandomNumberGenerator.new()
    rng.seed = int(p["seed"]) * 7 + 3

    var spots: Array = []
    var tries := 0
    while spots.size() < count and tries < count * 40:
        tries += 1
        var x := rng.randf_range(-170.0, 170.0)
        var z := rng.randf_range(-170.0, 170.0)
        if Vector2(x, z).length() < 28.0:
            continue
        var h: float = terrain.height_at(x, z)
        if h < 1.3:
            continue
        var slope: float = absf(terrain.height_at(x + 1.5, z) - h) + absf(terrain.height_at(x, z + 1.5) - h)
        if slope > 1.6:
            continue
        spots.append(Vector3(x, h, z))

    var shape: String = p["tree_shape"]
    var trunk := CylinderMesh.new()
    trunk.top_radius = 0.16
    trunk.bottom_radius = 0.26
    trunk.height = 3.2
    trunk.radial_segments = 7
    trunk.rings = 1
    trunk.material = _std_mat(p["trunk_col"])

    var canopy: Mesh = null
    if shape == "round":
        var sm := SphereMesh.new()
        sm.radius = 1.9
        sm.height = 3.2
        sm.radial_segments = 8
        sm.rings = 4
        sm.material = _std_mat(p["tree_col"])
        canopy = sm
    elif shape == "cone":
        var cm := CylinderMesh.new()
        cm.top_radius = 0.0
        cm.bottom_radius = 1.7
        cm.height = 4.6
        cm.radial_segments = 8
        cm.rings = 1
        cm.material = _std_mat(p["tree_col"])
        canopy = cm

    var trunk_x: Array = []
    var canopy_x: Array = []
    var body := StaticBody3D.new()
    add_child(body)
    for sp in spots:
        var s := rng.randf_range(0.8, 1.35)
        var yaw := rng.randf() * TAU
        var bs := Basis(Vector3.UP, yaw).scaled(Vector3(s, s, s))
        trunk_x.append(Transform3D(bs, sp + Vector3(0, 1.45 * s, 0)))
        if shape == "round":
            var bc := Basis(Vector3.UP, yaw).scaled(Vector3(s * 1.15, s * 0.95, s * 1.15))
            canopy_x.append(Transform3D(bc, sp + Vector3(0, 3.6 * s, 0)))
        elif shape == "cone":
            canopy_x.append(Transform3D(bs, sp + Vector3(0, 4.3 * s, 0)))
        var cs := CollisionShape3D.new()
        var cyl := CylinderShape3D.new()
        cyl.radius = 0.38
        cyl.height = 3.2 * s
        cs.shape = cyl
        cs.position = sp + Vector3(0, 1.6 * s, 0)
        body.add_child(cs)

    _make_mm(trunk, trunk_x)
    if canopy != null and canopy_x.size() > 0:
        _make_mm(canopy, canopy_x)


func _add_rocks() -> void:
    var count: int = p["rock_count"]
    if count <= 0:
        return
    var rng := RandomNumberGenerator.new()
    rng.seed = int(p["seed"]) * 13 + 5
    var mesh := SphereMesh.new()
    mesh.radius = 1.0
    mesh.height = 2.0
    mesh.radial_segments = 8
    mesh.rings = 5
    mesh.material = _std_mat(p["rock"])
    var xforms: Array = []
    var body := StaticBody3D.new()
    add_child(body)
    var tries := 0
    while xforms.size() < count and tries < count * 30:
        tries += 1
        var x := rng.randf_range(-180.0, 180.0)
        var z := rng.randf_range(-180.0, 180.0)
        if Vector2(x, z).length() < 22.0:
            continue
        var h: float = terrain.height_at(x, z)
        if h < 0.4:
            continue
        var s := rng.randf_range(0.7, 2.6)
        var bs := Basis(Vector3.UP, rng.randf() * TAU).scaled(Vector3(s * 1.2, s * 0.7, s))
        xforms.append(Transform3D(bs, Vector3(x, h + s * 0.25, z)))
        var cs := CollisionShape3D.new()
        var sh := SphereShape3D.new()
        sh.radius = s * 0.75
        cs.shape = sh
        cs.position = Vector3(x, h + s * 0.2, z)
        body.add_child(cs)
    _make_mm(mesh, xforms)


# ---------- UI and cinematic intro ----------

func _build_ui() -> void:
    lens = LensScript.new()
    lens.layer = 1
    add_child(lens)
    ui_layer = CanvasLayer.new()
    ui_layer.layer = 2
    add_child(ui_layer)
    hud = HudScript.new()
    ui_layer.add_child(hud)
    player.attach_hud(hud)
    hud.menu_pressed.connect(_on_menu)
    daynight.hud = hud
    survival.hud = hud
    camp.hud = hud
    hud.build_pressed.connect(camp.build_fire)
    hud.interact_pressed.connect(survival.interact)


func _on_menu() -> void:
    save_game()
    exit_requested.emit()


func _start_intro() -> void:
    intro_cam = Camera3D.new()
    intro_cam.far = 900.0
    intro_cam.fov = 60.0
    add_child(intro_cam)
    intro_cam.current = true
    hud.visible = false
    lens.visible = false
    player.input_enabled = false

    var top := ColorRect.new()
    top.color = Color.BLACK
    top.anchor_right = 1.0
    top.offset_bottom = 90.0
    ui_layer.add_child(top)
    var bottom := ColorRect.new()
    bottom.color = Color.BLACK
    bottom.anchor_top = 1.0
    bottom.anchor_right = 1.0
    bottom.anchor_bottom = 1.0
    bottom.offset_top = -90.0
    ui_layer.add_child(bottom)
    bars = [top, bottom]

    title_label = Label.new()
    title_label.text = "SOULKEEN\n%s" % I18n.t("map_" + String(p["id"]))
    title_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    title_label.anchor_right = 1.0
    title_label.anchor_top = 0.42
    title_label.anchor_bottom = 0.62
    title_label.add_theme_font_size_override("font_size", 44)
    title_label.add_theme_color_override("font_color", Color(1.0, 0.9, 0.7))
    title_label.modulate.a = 0.0
    ui_layer.add_child(title_label)


func _process(delta: float) -> void:
    if not intro_active:
        save_t += delta
        if save_t >= 30.0:
            save_t = 0.0
            save_game()
        if lens != null:
            lens.update(delta, player.camera, player.cam_mode, sun_node, player.get_rid(), weather.wet, weather.kind == "snow", weather.cloud)
        return
    intro_t += delta
    var a := intro_t * 0.16 + 0.6
    var radius := 150.0 - intro_t * 7.0
    var height := 62.0 - intro_t * 3.5
    intro_cam.position = Vector3(cos(a) * radius, height, sin(a) * radius)
    intro_cam.look_at(Vector3(0.0, 6.0, 0.0), Vector3.UP)
    var fade_in := clampf(intro_t / 1.5, 0.0, 1.0)
    var fade_out := clampf((INTRO_LEN - intro_t) / 1.5, 0.0, 1.0)
    title_label.modulate.a = minf(fade_in, fade_out)
    if intro_t >= INTRO_LEN:
        _end_intro()


func _input(event: InputEvent) -> void:
    if intro_active and event is InputEventScreenTouch and event.pressed:
        _end_intro()


func _end_intro() -> void:
    if not intro_active:
        return
    intro_active = false
    player.camera.current = true
    player.input_enabled = true
    hud.visible = true
    lens.visible = true
    for b in bars:
        b.queue_free()
    bars.clear()
    title_label.queue_free()
    intro_cam.queue_free()


# ---------- save / load ----------

func save_game() -> void:
    if player == null or survival == null or camp == null or daynight == null:
        return
    var pp: Vector3 = player.global_position
    var sp: Vector3 = player.spawn_pos
    var d := {
        "map": map_id,
        "pos": [pp.x, pp.y, pp.z],
        "spawn": [sp.x, sp.y, sp.z],
        "yaw": player.yaw,
        "health": survival.health,
        "hunger": survival.hunger,
        "thirst": survival.thirst,
        "day_t": daynight.day_t,
        "camp": camp.to_dict(),
    }
    Save.write(d)
    if hud != null:
        hud.saved_t = 1.5


func _apply_save() -> void:
    var d := load_data
    var pos: Array = d.get("pos", [0.0, 5.0, 6.0])
    var px := float(pos[0])
    var pz := float(pos[2])
    player.global_position = Vector3(px, terrain.height_at(px, pz) + 0.4, pz)
    player.velocity = Vector3.ZERO
    var sp: Array = d.get("spawn", [])
    if sp.size() == 3:
        player.spawn_pos = Vector3(float(sp[0]), float(sp[1]), float(sp[2]))
    player.yaw = float(d.get("yaw", 0.0))
    survival.health = float(d.get("health", 100.0))
    survival.hunger = float(d.get("hunger", 100.0))
    survival.thirst = float(d.get("thirst", 100.0))
    daynight.day_t = float(d.get("day_t", 0.32))
    camp.from_dict(d.get("camp", {}))


func _notification(what: int) -> void:
    if what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_WM_CLOSE_REQUEST:
        save_game()


# used only by the automatic smoke test in the GitHub build
func autotest_actions() -> void:
    if hud == null:
        return
    hud.move = Vector2(0.0, -1.0)
    hud.sprint = true
    hud.look_accum = Vector2(40.0, 0.0)
    hud.jump_pressed.emit()
    hud.attack_pressed.emit()
    hud.interact_pressed.emit()
    hud.build_pressed.emit()
    hud.crouch_pressed.emit()
    hud.aim_pressed.emit()
    hud.camera_pressed.emit()
    save_game()
