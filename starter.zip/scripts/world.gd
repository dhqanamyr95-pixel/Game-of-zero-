extends Node3D

signal exit_requested

const Maps = preload("res://scripts/maps.gd")
const WorldGenScript = preload("res://scripts/worldgen.gd")
const CraftUIScript = preload("res://scripts/craft_ui.gd")
const Items = preload("res://scripts/items.gd")
const PlayerScript = preload("res://scripts/player.gd")
const HudScript = preload("res://scripts/hud.gd")
const AudioScript = preload("res://scripts/audio.gd")
const WeatherScript = preload("res://scripts/weather.gd")
const LensScript = preload("res://scripts/lens.gd")
const DayNightScript = preload("res://scripts/daynight.gd")
const SurvivalScript = preload("res://scripts/survival.gd")
const CampScript = preload("res://scripts/camp.gd")
const Save = preload("res://scripts/save.gd")
const I18n = preload("res://scripts/i18n.gd")
const Settings = preload("res://scripts/settings.gd")
const TutorialScript = preload("res://scripts/tutorial.gd")
const SeasonsScript = preload("res://scripts/seasons.gd")

const INTRO_LEN := 9.0

var map_id: String = "savanna"
var p: Dictionary = {}
var terrain
var player
var hud
var intro_cam: Camera3D
var intro_t := 0.0
var intro_active := true
var ui_layer: CanvasLayer
var intro_layer: CanvasLayer
var tutorial
var craft_ui
var shop_ui = null
var water_node: MeshInstance3D
var seasons
var canopy_mat: StandardMaterial3D
var canopy_mmi: MultiMeshInstance3D
var ui_scale_v := 1.0
var fps_t := 0.0
var fps_frames := 0
var warmup := 5.0
var bars: Array = []
var title_label: Label
var lens
var weather
var daynight
var survival
var camp
var load_data := {}
var skip_intro := false
var save_t := 0.0
var sun_node: DirectionalLight3D
var env_ref: Environment
var sky_mat_ref: ProceduralSkyMaterial


func _ready() -> void:
    p = Maps.get_map(map_id)
    Settings.apply_window(get_window(), true)
    ui_scale_v = Settings.ui_scale(true)
    _setup_environment()

    terrain = WorldGenScript.new()
    terrain.name = "World"
    add_child(terrain)
    terrain.build(p, Settings.chunk_segs())
    if load_data.has("terrain"):
        terrain.from_dict(load_data["terrain"])
    _add_water()
    terrain.water = water_node

    var spawn := Vector3.ZERO
    if load_data.has("pos"):
        var sp0: Array = load_data["pos"]
        spawn = Vector3(float(sp0[0]), 0.0, float(sp0[2]))
    else:
        spawn = terrain.find_spawn()
    terrain.prebuild(spawn, 1)
    spawn.y = terrain.height_at(spawn.x, spawn.z)

    player = PlayerScript.new()
    player.position = spawn + Vector3(0.0, 0.4, 0.0)
    player.height_fn = Callable(terrain, "height_at")
    add_child(player)
    terrain.player = player
    if load_data.is_empty():
        player.yaw = randf() * TAU

    var audio = AudioScript.new()
    audio.name = "Audio"
    add_child(audio)
    audio.setup(p)
    player.audio = audio

    weather = WeatherScript.new()
    weather.name = "Weather"
    add_child(weather)
    weather.setup(p, player, audio)
    terrain.weather = weather

    daynight = DayNightScript.new()
    daynight.name = "DayNight"
    add_child(daynight)
    daynight.setup(p, player, env_ref, sky_mat_ref, sun_node, weather, audio)

    survival = SurvivalScript.new()
    survival.name = "Survival"
    add_child(survival)
    survival.setup(p, player, terrain, audio)

    camp = CampScript.new()
    camp.name = "Camp"
    add_child(camp)
    camp.setup(p, player, terrain, audio)
    camp.daynight = daynight
    survival.camp = camp
    camp.equip_best()
    _apply_profile()
    _spawn_bots()

    if bool(p.get("seasonal", false)):
        seasons = SeasonsScript.new()
        seasons.name = "Seasons"
        add_child(seasons)
        seasons.setup(self, terrain, weather, daynight)

    tutorial = TutorialScript.new()
    tutorial.name = "Tutorial"
    add_child(tutorial)

    craft_ui = CraftUIScript.new()
    craft_ui.name = "CraftUI"
    add_child(craft_ui)

    var shop_script = load("res://scripts/shop_ui.gd")
    if shop_script != null and shop_script.can_instantiate():
        shop_ui = shop_script.new()
        shop_ui.name = "ShopUI"
        add_child(shop_ui)

    _build_ui()
    _start_intro()
    if not load_data.is_empty():
        _apply_save()
        _end_intro()
    if skip_intro:
        _end_intro()


# ---------- environment ----------

func _setup_environment() -> void:
    var sky_mat := ProceduralSkyMaterial.new()
    sky_mat.sky_top_color = p["sky_top"]
    sky_mat.sky_horizon_color = p["sky_hor"]
    sky_mat.ground_horizon_color = p["sky_hor"]
    sky_mat.ground_bottom_color = Color(0.2, 0.22, 0.2)
    var sky := Sky.new()
    sky.sky_material = sky_mat
    sky.radiance_size = Sky.RADIANCE_SIZE_32
    var env := Environment.new()
    env.background_mode = Environment.BG_SKY
    env.sky = sky
    env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
    env.ambient_light_energy = 0.9
    if Settings.fancy_post():
        env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
        env.adjustment_enabled = true
        env.adjustment_saturation = 1.15
        env.adjustment_contrast = 1.05
    else:
        env.tonemap_mode = Environment.TONE_MAPPER_LINEAR
    env.fog_enabled = true
    env.fog_light_color = p["fog"]
    env.fog_density = float(p["fog_d"])
    var we := WorldEnvironment.new()
    we.environment = env
    add_child(we)

    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = p["sun_rot"]
    sun.light_color = p["sun_color"]
    sun.light_energy = float(p["sun_energy"])
    sun.shadow_enabled = Settings.shadows()
    if Settings.level == 0:
        sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS
        sun.directional_shadow_max_distance = 70.0
    else:
        sun.directional_shadow_mode = DirectionalLight3D.SHADOW_ORTHOGONAL
        sun.directional_shadow_max_distance = 45.0
    RenderingServer.directional_shadow_atlas_set_size(Settings.shadow_atlas(), true)
    add_child(sun)
    sun_node = sun
    env_ref = env
    sky_mat_ref = sky_mat


func _add_water() -> void:
    var pm := PlaneMesh.new()
    pm.size = Vector2(1400.0, 1400.0)
    var mat := StandardMaterial3D.new()
    mat.albedo_color = p["water"]
    mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    mat.roughness = 0.15
    mat.cull_mode = BaseMaterial3D.CULL_DISABLED
    Settings.tune(mat)
    pm.material = mat
    water_node = MeshInstance3D.new()
    water_node.mesh = pm
    water_node.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    add_child(water_node)


# ---------- UI and cinematic intro ----------

func _build_ui() -> void:
    lens = LensScript.new()
    lens.layer = 1
    add_child(lens)
    ui_layer = CanvasLayer.new()
    ui_layer.layer = 2
    ui_layer.scale = Vector2(ui_scale_v, ui_scale_v)
    add_child(ui_layer)
    intro_layer = CanvasLayer.new()
    intro_layer.layer = 3
    add_child(intro_layer)
    hud = HudScript.new()
    hud.ui_scale = ui_scale_v
    ui_layer.add_child(hud)
    player.attach_hud(hud)
    hud.menu_pressed.connect(_on_menu)
    daynight.hud = hud
    survival.hud = hud
    camp.hud = hud
    hud.build_pressed.connect(craft_ui.toggle)
    craft_ui.setup(camp, hud, player, daynight)
    if shop_ui != null:
        shop_ui.setup(player, hud, daynight)
        hud.shop_pressed.connect(shop_ui.toggle)
    hud.interact_pressed.connect(survival.interact)
    tutorial.setup(player, camp, hud)
    if seasons != null:
        seasons.hud = hud


func _on_menu() -> void:
    save_game()
    exit_requested.emit()


func _start_intro() -> void:
    intro_cam = Camera3D.new()
    intro_cam.far = 900.0
    intro_cam.fov = 60.0
    add_child(intro_cam)
    intro_cam.current = true
    hud.visible = false
    lens.visible = false
    player.input_enabled = false

    var top := ColorRect.new()
    top.color = Color.BLACK
    top.anchor_right = 1.0
    top.offset_bottom = 90.0
    intro_layer.add_child(top)
    var bottom := ColorRect.new()
    bottom.color = Color.BLACK
    bottom.anchor_top = 1.0
    bottom.anchor_right = 1.0
    bottom.anchor_bottom = 1.0
    bottom.offset_top = -90.0
    intro_layer.add_child(bottom)
    bars = [top, bottom]

    title_label = Label.new()
    title_label.text = "SOULKEEN\n%s" % I18n.t("map_" + String(p["id"]))
    title_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    title_label.anchor_right = 1.0
    title_label.anchor_top = 0.42
    title_label.anchor_bottom = 0.62
    title_label.add_theme_font_size_override("font_size", 44)
    title_label.add_theme_color_override("font_color", Color(1.0, 0.9, 0.7))
    title_label.modulate.a = 0.0
    intro_layer.add_child(title_label)


func _process(delta: float) -> void:
    if not intro_active:
        save_t += delta
        if save_t >= 30.0:
            save_t = 0.0
            save_game()
        _watch_speed(delta)
        if lens != null:
            lens.update(delta, player.camera, player.cam_mode, sun_node, player.get_rid(), weather.wet, weather.kind == "snow", weather.cloud, Settings.level)
        return
    intro_t += delta
    var c: Vector3 = player.global_position
    var a := intro_t * 0.16 + 0.6
    var radius := 70.0 - intro_t * 3.0
    var height := 38.0 - intro_t * 2.0
    intro_cam.position = c + Vector3(cos(a) * radius, height, sin(a) * radius)
    intro_cam.look_at(c + Vector3(0.0, 4.0, 0.0), Vector3.UP)
    var fade_in := clampf(intro_t / 1.5, 0.0, 1.0)
    var fade_out := clampf((INTRO_LEN - intro_t) / 1.5, 0.0, 1.0)
    title_label.modulate.a = minf(fade_in, fade_out)
    if intro_t >= INTRO_LEN:
        _end_intro()


func _input(event: InputEvent) -> void:
    if intro_active and event is InputEventScreenTouch and event.pressed:
        _end_intro()


func _end_intro() -> void:
    if not intro_active:
        return
    intro_active = false
    player.camera.current = true
    player.input_enabled = true
    hud.visible = true
    lens.visible = true
    tutorial.begin()
    for b in bars:
        b.queue_free()
    bars.clear()
    title_label.queue_free()
    intro_cam.queue_free()


# ---------- save / load ----------

func save_game() -> void:
    if player == null or survival == null or camp == null or daynight == null:
        return
    var pp: Vector3 = player.global_position
    var sp: Vector3 = player.spawn_pos
    var d := {
        "map": map_id,
        "pos": [pp.x, pp.y, pp.z],
        "spawn": [sp.x, sp.y, sp.z],
        "yaw": player.yaw,
        "health": survival.health,
        "hunger": survival.hunger,
        "thirst": survival.thirst,
        "day_t": daynight.day_t,
        "camp": camp.to_dict(),
    }
    if seasons != null:
        d["season"] = seasons.to_dict()
    d["terrain"] = terrain.to_dict()
    d["elapsed"] = daynight.elapsed
    Save.write(d)
    if hud != null:
        hud.saved_t = 1.5


func _apply_save() -> void:
    var d := load_data
    var pos: Array = d.get("pos", [0.0, 5.0, 6.0])
    var px := float(pos[0])
    var pz := float(pos[2])
    player.global_position = Vector3(px, terrain.height_at(px, pz) + 0.4, pz)
    player.velocity = Vector3.ZERO
    var sp: Array = d.get("spawn", [])
    if sp.size() == 3:
        player.spawn_pos = Vector3(float(sp[0]), float(sp[1]), float(sp[2]))
    player.yaw = float(d.get("yaw", 0.0))
    survival.health = float(d.get("health", 100.0))
    survival.hunger = float(d.get("hunger", 100.0))
    survival.thirst = float(d.get("thirst", 100.0))
    daynight.day_t = float(d.get("day_t", 0.32))
    camp.from_dict(d.get("camp", {}))
    daynight.elapsed = float(d.get("elapsed", 0.0))
    if seasons != null and d.has("season"):
        seasons.from_dict(d["season"])


func _notification(what: int) -> void:
    if what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_WM_CLOSE_REQUEST:
        save_game()


# used only by the automatic smoke test in the GitHub build
func autotest_actions() -> void:
    if hud == null:
        return
    hud.move = Vector2(0.0, -1.0)
    hud.sprint = true
    hud.look_accum = Vector2(40.0, 0.0)
    hud.jump_pressed.emit()
    hud.attack_pressed.emit()
    hud.interact_pressed.emit()
    hud.crouch_pressed.emit()
    hud.aim_pressed.emit()
    hud.camera_pressed.emit()
    if seasons != null:
        seasons.force(seasons.idx + 1)
    camp.add_item("wood", 20)
    camp.add_item("stone", 20)
    camp.add_item("fiber", 10)
    camp.add_item("sapling", 2)
    daynight.elapsed = 99999.0
    for r in Items.RECIPES:
        print("AUTOTEST craft ", r["id"], " -> ", camp.craft(String(r["id"])))
    var fwd: Vector3 = -player.model.global_transform.basis.z
    var tg: Dictionary = terrain.find_target(player.global_position, fwd, 3.0)
    if not tg.is_empty():
        print("AUTOTEST target ", tg["kind"])
        if tg["kind"] == "tree" or tg["kind"] == "rock" or tg["kind"] == "ptree":
            terrain.hit(tg, 20, true)
        elif tg["kind"] == "bush":
            terrain.eat_berries(tg)
        else:
            terrain.collect(tg)
    print("AUTOTEST plant ", terrain.plant(player.global_position, fwd))
    save_game()


# ---------- speed control and spawn ----------

# If the game runs slower than 20 frames per second for 6 seconds, the graphics
# are lowered one step automatically (only in "auto" quality mode).
func _watch_speed(delta: float) -> void:
    warmup -= delta
    if warmup > 0.0:
        return
    fps_t += delta
    fps_frames += 1
    if fps_t < 6.0:
        return
    var avg := float(fps_frames) / fps_t
    fps_t = 0.0
    fps_frames = 0
    if Settings.mode == "auto" and avg < 20.0 and Settings.downgrade():
        _apply_quality_live()


func _apply_quality_live() -> void:
    Settings.apply_window(get_window(), true)
    ui_scale_v = Settings.ui_scale(true)
    ui_layer.scale = Vector2(ui_scale_v, ui_scale_v)
    hud.ui_scale = ui_scale_v
    hud._fit()
    sun_node.shadow_enabled = Settings.shadows()
    if Settings.fancy_post():
        env_ref.tonemap_mode = Environment.TONE_MAPPER_FILMIC
        env_ref.adjustment_enabled = true
    else:
        env_ref.tonemap_mode = Environment.TONE_MAPPER_LINEAR
        env_ref.adjustment_enabled = false


# ---------- clothes and companions (loaded safely: the game works without them) ----------

func _apply_profile() -> void:
    var wd = load("res://scripts/wardrobe.gd")
    if wd == null or not wd.can_instantiate():
        return
    wd.load_all()
    if player.model.has_method("set_look"):
        player.model.set_look(wd.get_look())
        player.model.set_outfit(wd.get_equipped())


func _spawn_bots() -> void:
    var scr = load("res://scripts/bot.gd")
    if scr == null or not scr.can_instantiate():
        return
    var pp: Vector3 = player.global_position
    for i in 3:
        var bot = scr.new()
        var ang := TAU * float(i) / 3.0 + 0.5
        var x: float = pp.x + cos(ang) * 6.0
        var z: float = pp.z + sin(ang) * 6.0
        bot.position = Vector3(x, terrain.height_at(x, z) + 0.4, z)
        bot.terrain = terrain
        bot.player = player
        bot.camp = camp
        bot.audio = player.audio
        add_child(bot)
