extends CharacterBody3D

# A friendly offline companion. It follows the player, wanders nearby and helps by
# picking up branches, pebbles and reeds, which it hands over to the player's
# inventory. It never attacks.

const HumanoidScript = preload("res://scripts/humanoid.gd")
const Outfits = preload("res://scripts/outfits.gd")

const NAMES := ["Kian", "Mina", "Arman", "Sara", "Leo", "Aya", "Dara", "Noah"]
const SPEED := 3.3
const GRAVITY := 14.0

var terrain = null
var player = null
var camp = null
var audio = null
var model: Node3D = null
var bot_name := "Bot"
var rng := RandomNumberGenerator.new()
var state := "follow"
var goal := Vector3.ZERO
var think_t := 0.0
var stuck_t := 0.0
var side_t := 0.0
var side_dir := 1.0
var cooldown := 3.0
var model_yaw := 0.0
var pick_target: Dictionary = {}


func _ready() -> void:
    rng.randomize()
    floor_snap_length = 0.5
    var capsule := CapsuleShape3D.new()
    capsule.radius = 0.32
    capsule.height = 1.8
    var cs := CollisionShape3D.new()
    cs.shape = capsule
    cs.position.y = 0.9
    add_child(cs)

    var scr = load("res://scripts/humanoid_pro.gd")
    if scr != null and scr.can_instantiate():
        model = scr.new()
    else:
        model = HumanoidScript.new()
    add_child(model)
    model.build()
    bot_name = String(NAMES[rng.randi() % NAMES.size()])
    if model.has_method("set_look"):
        model.set_look({"skin": rng.randi() % 6, "hair": rng.randi() % 6, "hair_color": rng.randi() % 8, "beard": rng.randi() % 4})
        var outfit := {}
        for cat in Outfits.CATS:
            var c: String = String(cat)
            if c == "shirt" or c == "pants" or rng.randf() < 0.6:
                outfit[c] = Outfits.random_free(rng, c)
            else:
                outfit[c] = ""
        model.set_outfit(outfit)
    model.set_held("club")

    var lb := Label3D.new()
    lb.text = bot_name
    lb.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    lb.pixel_size = 0.006
    lb.font_size = 48
    lb.outline_size = 8
    lb.modulate = Color(0.9, 1.0, 0.8)
    lb.position = Vector3(0.0, 2.15, 0.0)
    add_child(lb)
    goal = global_position


func _teleport_near(pp: Vector3) -> void:
    var a := rng.randf() * TAU
    var x := pp.x + cos(a) * 7.0
    var z := pp.z + sin(a) * 7.0
    global_position = Vector3(x, terrain.height_at(x, z) + 0.5, z)
    velocity = Vector3.ZERO
    goal = global_position


func _think(pos: Vector3, pp: Vector3, dist: float) -> void:
    if state == "gather":
        if pick_target.is_empty() or dist > 40.0:
            state = "follow"
            pick_target = {}
        else:
            return
    if dist > 10.0:
        goal = pp + Vector3(rng.randf_range(-3.0, 3.0), 0.0, rng.randf_range(-3.0, 3.0))
    elif dist < 3.5:
        goal = pos
    elif rng.randf() < 0.35:
        goal = pp + Vector3(rng.randf_range(-7.0, 7.0), 0.0, rng.randf_range(-7.0, 7.0))
    if cooldown <= 0.0 and dist < 25.0:
        var tg: Dictionary = terrain.nearest_pickup(pos, 14.0)
        if not tg.is_empty():
            var o: Dictionary = tg["o"]
            var op: Vector3 = o["pos"]
            pick_target = tg
            goal = op
            state = "gather"


func _try_collect() -> void:
    var tg: Dictionary = pick_target
    pick_target = {}
    state = "follow"
    cooldown = 7.0
    if tg.is_empty():
        return
    var o: Dictionary = tg["o"]
    if not o["alive"]:
        return
    var got: Dictionary = terrain.collect(tg)
    for id in got.keys():
        camp.add_item(String(id), int(got[id]))
    if audio != null:
        audio.pickup()


func _physics_process(delta: float) -> void:
    if player == null or terrain == null:
        return
    var pos: Vector3 = global_position
    var pp: Vector3 = player.global_position
    var dist := Vector2(pp.x - pos.x, pp.z - pos.z).length()
    if dist > 70.0:
        _teleport_near(pp)
        return
    cooldown -= delta
    think_t -= delta
    if think_t <= 0.0:
        think_t = 0.6
        _think(pos, pp, dist)

    var dir := Vector3.ZERO
    var speed := 0.0
    var to_goal := Vector2(goal.x - pos.x, goal.z - pos.z)
    if to_goal.length() > 0.8:
        dir = Vector3(to_goal.x, 0.0, to_goal.y).normalized()
        speed = SPEED
    elif state == "gather":
        _try_collect()

    if dir != Vector3.ZERO:
        var ahead := pos + dir * 1.6
        if terrain.height_at(ahead.x, ahead.z) < 0.25:
            side_t = 0.8
            side_dir = 1.0
            if rng.randf() < 0.5:
                side_dir = -1.0
    if side_t > 0.0:
        side_t -= delta
        dir = dir.rotated(Vector3.UP, side_dir * 1.2)

    var accel := 20.0
    velocity.x = move_toward(velocity.x, dir.x * speed, accel * delta)
    velocity.z = move_toward(velocity.z, dir.z * speed, accel * delta)
    if not is_on_floor():
        velocity.y -= GRAVITY * delta
    move_and_slide()

    var hspeed := Vector2(velocity.x, velocity.z).length()
    if speed > 0.0 and hspeed < 0.4:
        stuck_t += delta
        if stuck_t > 0.5 and is_on_floor():
            velocity.y = 5.0
            stuck_t = 0.0
            side_t = 0.5
            side_dir = 1.0
            if rng.randf() < 0.5:
                side_dir = -1.0
    else:
        stuck_t = 0.0
    if hspeed > 0.3:
        var ty := atan2(-velocity.x, -velocity.z)
        model_yaw = lerp_angle(model_yaw, ty, minf(1.0, delta * 10.0))
    model.rotation.y = model_yaw
    model.animate(delta, hspeed / 3.0, is_on_floor(), 0.0, -1.0)
