extends Node3D

# Survival basics: health, hunger, thirst.
#   - berry bushes (eat with the E button, they regrow)
#   - drink from the sea / lakes (face the water and press E)
#   - volcanic map: the sea is lava and burns
# When nothing can be used nearby, E toggles the torch.

const I18n = preload("res://scripts/i18n.gd")
const Settings = preload("res://scripts/settings.gd")

const BUSH_COUNT := {"savanna": 28, "forest": 70, "iceage": 10, "desert": 8, "volcanic": 0}
const BUSH_COLOR := {
    "savanna": Color(0.32, 0.42, 0.14),
    "forest": Color(0.12, 0.34, 0.10),
    "iceage": Color(0.14, 0.30, 0.20),
    "desert": Color(0.45, 0.50, 0.25),
    "volcanic": Color(0.2, 0.2, 0.2),
}
const BERRY_COLOR := {
    "savanna": Color(0.80, 0.10, 0.12),
    "forest": Color(0.55, 0.10, 0.55),
    "iceage": Color(0.20, 0.30, 0.85),
    "desert": Color(0.95, 0.55, 0.10),
    "volcanic": Color(0.5, 0.1, 0.1),
}

var map: Dictionary = {}
var player = null
var terrain = null
var audio = null
var hud = null
var camp = null

var health := 100.0
var hunger := 100.0
var thirst := 100.0
var lava := false

var bush_pos: Array = []
var bush_eaten := {}
var berry_mm: MultiMesh
var berry_xf: Array = []
var near_bush := -1
var can_drink := false
var scan_t := 0.0


func setup(m: Dictionary, p, t, a) -> void:
    map = m
    player = p
    terrain = t
    audio = a
    lava = String(map["id"]) == "volcanic"
    _build_bushes()


func _build_bushes() -> void:
    var id := String(map["id"])
    var count: int = int(BUSH_COUNT.get(id, 20))
    if count <= 0:
        return
    var rng := RandomNumberGenerator.new()
    rng.seed = int(map["seed"]) * 31 + 7

    var bush_xf: Array = []
    var tries := 0
    while bush_pos.size() < count and tries < count * 80:
        tries += 1
        var x := 0.0
        var z := 0.0
        if bush_pos.size() < 5:
            var ang := rng.randf() * TAU
            var rad := rng.randf_range(9.0, 26.0)
            x = cos(ang) * rad
            z = sin(ang) * rad
        else:
            x = rng.randf_range(-150.0, 150.0)
            z = rng.randf_range(-150.0, 150.0)
        if absf(x) < 6.5 and absf(z + 6.0) < 6.5:
            continue
        var h: float = terrain.height_at(x, z)
        if h < 1.0 or h > 9.0:
            continue
        var slope: float = absf(terrain.height_at(x + 1.5, z) - h) + absf(terrain.height_at(x, z + 1.5) - h)
        if slope > 1.4:
            continue
        var s := rng.randf_range(0.8, 1.3)
        var center := Vector3(x, h, z)
        bush_pos.append(center)
        var bs := Basis().scaled(Vector3(s * 1.1, s * 0.8, s * 1.1))
        bush_xf.append(Transform3D(bs, center + Vector3(0, 0.35 * s, 0)))
        var group: Array = []
        for k in 3:
            var a := rng.randf() * TAU
            var bp := center + Vector3(cos(a) * 0.55 * s, 0.45 * s + 0.05, sin(a) * 0.55 * s)
            group.append(Transform3D(Basis(), bp))
        berry_xf.append(group)

    if bush_pos.is_empty():
        return

    var bush_mesh := SphereMesh.new()
    bush_mesh.radius = 0.65
    bush_mesh.height = 1.0
    bush_mesh.radial_segments = 8
    bush_mesh.rings = 4
    var bm := StandardMaterial3D.new()
    bm.albedo_color = BUSH_COLOR.get(id, Color(0.2, 0.4, 0.15))
    bm.roughness = 1.0
    Settings.tune(bm)
    bush_mesh.material = bm
    _add_mm(bush_mesh, bush_xf)

    var berry_mesh := SphereMesh.new()
    berry_mesh.radius = 0.07
    berry_mesh.height = 0.14
    berry_mesh.radial_segments = 6
    berry_mesh.rings = 3
    var bb := StandardMaterial3D.new()
    bb.albedo_color = BERRY_COLOR.get(id, Color(0.8, 0.1, 0.1))
    bb.roughness = 0.4
    Settings.tune(bb)
    berry_mesh.material = bb
    berry_mm = MultiMesh.new()
    berry_mm.transform_format = MultiMesh.TRANSFORM_3D
    berry_mm.mesh = berry_mesh
    berry_mm.instance_count = bush_pos.size() * 3
    for i in bush_pos.size():
        for k in 3:
            berry_mm.set_instance_transform(i * 3 + k, berry_xf[i][k])
    var mmi := MultiMeshInstance3D.new()
    mmi.multimesh = berry_mm
    add_child(mmi)


func _add_mm(mesh: Mesh, xforms: Array) -> void:
    var mm := MultiMesh.new()
    mm.transform_format = MultiMesh.TRANSFORM_3D
    mm.mesh = mesh
    mm.instance_count = xforms.size()
    for i in xforms.size():
        mm.set_instance_transform(i, xforms[i])
    var mmi := MultiMeshInstance3D.new()
    mmi.multimesh = mm
    add_child(mmi)


# ---------- actions ----------

func interact() -> void:
    if can_drink:
        thirst = minf(100.0, thirst + 14.0)
        if audio != null:
            audio.drink()
        return
    if near_bush >= 0:
        _eat(near_bush)
        return
    if camp != null and camp.try_interact():
        return
    player.toggle_torch()


func _eat(i: int) -> void:
    hunger = minf(100.0, hunger + 16.0)
    health = minf(100.0, health + 3.0)
    bush_eaten[i] = 150.0
    for k in 3:
        var t: Transform3D = berry_xf[i][k]
        berry_mm.set_instance_transform(i * 3 + k, Transform3D(Basis().scaled(Vector3(0.0001, 0.0001, 0.0001)), t.origin))
    near_bush = -1
    if audio != null:
        audio.eat()


func _die() -> void:
    if camp != null:
        camp.drop_bag(player.global_position)
    player.respawn()
    health = 100.0
    hunger = 60.0
    thirst = 60.0
    if hud != null:
        hud.message = I18n.t("died")
        hud.message_t = 3.0
        hud.message_col = Color(0.9, 0.2, 0.15)
        hud.message_size = 56


# ---------- per frame ----------

func _process(delta: float) -> void:
    if player == null:
        return

    # regrow berries
    for key in bush_eaten.keys():
        bush_eaten[key] = float(bush_eaten[key]) - delta
        if float(bush_eaten[key]) <= 0.0:
            for k in 3:
                berry_mm.set_instance_transform(int(key) * 3 + k, berry_xf[int(key)][k])
            bush_eaten.erase(key)

    # what can the player use right now?
    scan_t -= delta
    if scan_t <= 0.0:
        scan_t = 0.2
        var pp: Vector3 = player.global_position
        near_bush = -1
        var best := 2.2
        for i in bush_pos.size():
            if bush_eaten.has(i):
                continue
            var d := Vector2(pp.x - bush_pos[i].x, pp.z - bush_pos[i].z).length()
            if d < best:
                best = d
                near_bush = i
        var fwd: Vector3 = -player.model.global_transform.basis.z
        var probe := pp + fwd * 1.4
        can_drink = not lava and player.is_on_floor() and pp.y < 2.2 and terrain.height_at(probe.x, probe.z) < 0.25

    # needs
    var sprinting: bool = player.hud != null and player.hud.sprint
    var thirst_rate := 0.10
    if sprinting:
        thirst_rate = 0.18
    hunger = maxf(0.0, hunger - delta * 0.06)
    thirst = maxf(0.0, thirst - delta * thirst_rate)
    if hunger <= 0.0 or thirst <= 0.0:
        health -= delta * 1.2
    elif hunger > 50.0 and thirst > 50.0:
        health = minf(100.0, health + delta * 0.6)

    # lava burns
    if lava:
        var pp2: Vector3 = player.global_position
        if pp2.y < 0.3 and terrain.height_at(pp2.x, pp2.z) < 0.0:
            health -= delta * 25.0

    if health <= 0.0:
        _die()

    if hud != null:
        hud.health = health / 100.0
        hud.hunger = hunger / 100.0
        hud.thirst = thirst / 100.0
        if can_drink:
            hud.prompt_text = I18n.t("act_drink")
        elif near_bush >= 0:
            hud.prompt_text = I18n.t("act_eat")
        elif camp != null:
            hud.prompt_text = camp.prompt()
        else:
            hud.prompt_text = ""
