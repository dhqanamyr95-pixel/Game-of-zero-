extends Node3D

# Health, hunger and thirst, plus everything the player does with the world:
#   E  = drink, pick things up, eat berries, plant a sapling, or toggle the torch
#   attack button = chop trees / mine rocks with the right tool (or shoot the bow)

const I18n = preload("res://scripts/i18n.gd")
const ArrowScript = preload("res://scripts/arrow.gd")

var map: Dictionary = {}
var player = null
var terrain = null
var audio = null
var hud = null
var camp = null

var health := 100.0
var hunger := 100.0
var thirst := 100.0

var target: Dictionary = {}
var can_drink := false
var scan_t := 0.0
var prev_attack := -1.0


func setup(m: Dictionary, p, t, a) -> void:
    map = m
    player = p
    terrain = t
    audio = a


# ---------- actions ----------

func interact() -> void:
    if camp.try_interact():
        return
    if can_drink:
        thirst = minf(100.0, thirst + 14.0)
        if audio != null:
            audio.drink()
        return
    if not target.is_empty():
        var kind: String = target["kind"]
        if kind == "branch" or kind == "pebble" or kind == "fiber":
            var got: Dictionary = terrain.collect(target)
            _give(got)
            if audio != null:
                audio.pickup()
            target = {}
            return
        if kind == "bush":
            if terrain.eat_berries(target):
                hunger = minf(100.0, hunger + 16.0)
                health = minf(100.0, health + 3.0)
                if audio != null:
                    audio.eat()
                target = {}
                return
    if int(camp.items["sapling"]) > 0:
        var fwd: Vector3 = -player.model.global_transform.basis.z
        var res: String = terrain.plant(player.global_position, fwd)
        if res == "ok":
            camp.items["sapling"] = int(camp.items["sapling"]) - 1
            camp.msg_key("planted")
            return
        if res == "bad_soil":
            camp.items["sapling"] = int(camp.items["sapling"]) - 1
            camp.msg_key("bad_soil")
            return
        if res == "water":
            camp.msg_key("cant_build")
            return
    player.toggle_torch()


func _give(got: Dictionary) -> void:
    var text := ""
    for id in ["wood", "stone", "fiber", "sapling"]:
        if got.has(id):
            camp.add_item(id, int(got[id]))
            text += "+%d %s  " % [int(got[id]), I18n.t("item_" + id)]
    if text != "":
        camp.msg(text.strip_edges())


func _apply_hit() -> void:
    var pp: Vector3 = player.global_position
    var fwd: Vector3 = -player.model.global_transform.basis.z
    if camp.equipped == "bow" and int(camp.items["arrow"]) > 0:
        _shoot()
        return
    var tg: Dictionary = terrain.find_target(pp, fwd, 2.6)
    if tg.is_empty():
        return
    var kind: String = tg["kind"]
    if kind != "tree" and kind != "rock" and kind != "ptree":
        return
    var power := 1
    if kind == "rock":
        power = camp.tool_power("rock")
        player.model.set_held("pickaxe" if camp.tools.has("pickaxe") else camp.equipped)
    else:
        power = camp.tool_power("tree")
        player.model.set_held("axe" if camp.tools.has("axe") else camp.equipped)
    var res: Dictionary = terrain.hit(tg, power, camp.tools.has("pickaxe"))
    if res.has("need_pickaxe"):
        camp.msg_key("need_pickaxe")
        return
    if audio != null:
        if kind == "rock":
            audio.clack()
        else:
            audio.chop()
    if res.has("felled"):
        _give(res)


func _shoot() -> void:
    camp.items["arrow"] = int(camp.items["arrow"]) - 1
    var cam: Camera3D = player.camera
    var dir: Vector3 = -cam.global_transform.basis.z
    var arrow := ArrowScript.new()
    get_parent().add_child(arrow)
    arrow.global_position = player.global_position + Vector3(0.0, 1.5, 0.0) + dir * 0.8
    arrow.vel = dir * 38.0
    if audio != null:
        audio.swing()


func _die() -> void:
    if camp != null:
        camp.drop_bag(player.global_position)
    player.respawn()
    health = 100.0
    hunger = 60.0
    thirst = 60.0
    if hud != null:
        hud.message = I18n.t("died")
        hud.message_t = 3.0
        hud.message_col = Color(0.9, 0.2, 0.15)
        hud.message_size = 56


# ---------- per frame ----------

func _process(delta: float) -> void:
    if player == null:
        return

    scan_t -= delta
    if scan_t <= 0.0:
        scan_t = 0.2
        var pp: Vector3 = player.global_position
        var fwd: Vector3 = -player.model.global_transform.basis.z
        target = terrain.find_target(pp, fwd, 2.4)
        var probe := pp + fwd * 1.4
        can_drink = player.is_on_floor() and pp.y < 2.2 and terrain.height_at(probe.x, probe.z) < 0.25

    # the moment the swing hits
    var at: float = player.attack_t
    if at >= 0.0 and prev_attack < 0.33 and at >= 0.33:
        _apply_hit()
    prev_attack = at

    # needs
    var sprinting: bool = player.hud != null and player.hud.sprint
    var thirst_rate := 0.10
    if sprinting:
        thirst_rate = 0.18
    hunger = maxf(0.0, hunger - delta * 0.06)
    thirst = maxf(0.0, thirst - delta * thirst_rate)
    if hunger <= 0.0 or thirst <= 0.0:
        health -= delta * 1.2
    elif hunger > 50.0 and thirst > 50.0:
        health = minf(100.0, health + delta * 0.6)
    if health <= 0.0:
        _die()

    if hud != null:
        hud.health = health / 100.0
        hud.hunger = hunger / 100.0
        hud.thirst = thirst / 100.0
        hud.prompt_text = _prompt()


func _prompt() -> String:
    var bag := camp.prompt()
    if bag != "":
        return bag
    if can_drink:
        return I18n.t("act_drink")
    if not target.is_empty():
        match String(target["kind"]):
            "branch":
                return I18n.t("pickup_wood")
            "pebble":
                return I18n.t("pickup_stone")
            "fiber":
                return I18n.t("pickup_fiber")
            "bush":
                return I18n.t("act_eat")
    if int(camp.items["sapling"]) > 0:
        return I18n.t("act_plant")
    return ""
