extends Node

# Procedural sound engine. All sounds are synthesized in code at startup,
# so no audio files are needed. (Placeholders: real recorded sounds come later.)

const RATE := 22050

var rng := RandomNumberGenerator.new()
var step_pool: Array = []
var step_idx := 0
var step_variants: Array = []
var bird_variants: Array = []
var swing_s: AudioStreamWAV
var thud_s: AudioStreamWAV
var click_s: AudioStreamWAV
var ignite_s: AudioStreamWAV
var drink_s: AudioStreamWAV
var fire_player: AudioStreamPlayer
var eat_s: AudioStreamWAV
var crackle: AudioStreamPlayer
var rain_player: AudioStreamPlayer
var cricket_player: AudioStreamPlayer
var day_amt := 1.0
var thunder_player: AudioStreamPlayer
var bird_player: AudioStreamPlayer
var fx_player: AudioStreamPlayer
var birds_enabled := false
var bird_timer := 6.0


func setup(map: Dictionary) -> void:
    rng.randomize()
    var id: String = map["id"]

    # per-map sound profile: wind softness, wind volume, rumble, birds, ground type
    var wind_a := 0.05
    var wind_vol := 0.25
    var rumble_vol := 0.0
    var bird_base := 0.0
    var ground := "grass"
    match id:
        "savanna":
            wind_a = 0.05
            wind_vol = 0.25
            bird_base = 2800.0
            ground = "grass"
        "forest":
            wind_a = 0.035
            wind_vol = 0.18
            bird_base = 3400.0
            ground = "grass"
        "iceage":
            wind_a = 0.09
            wind_vol = 0.50
            ground = "snow"
        "desert":
            wind_a = 0.07
            wind_vol = 0.40
            ground = "sand"
        "volcanic":
            wind_a = 0.04
            wind_vol = 0.35
            rumble_vol = 0.55
            ground = "rock"

    _player(_gen_loop(5.0, wind_a), wind_vol, true)
    if rumble_vol > 0.0:
        _player(_gen_loop(4.0, 0.008), rumble_vol, true)

    # footsteps (3 variants) and a small player pool
    var a := 0.30
    var decay := 28.0
    var thump := 0.15
    match ground:
        "snow":
            a = 0.14
            decay = 22.0
            thump = 0.05
        "sand":
            a = 0.20
            decay = 24.0
            thump = 0.05
        "rock":
            a = 0.55
            decay = 40.0
            thump = 0.30
    for i in 3:
        step_variants.append(_gen_step(a * rng.randf_range(0.85, 1.15), decay, thump))
    for i in 3:
        step_pool.append(_player(null, 0.35, false))

    swing_s = _gen_swing()
    thud_s = _gen_thud()
    click_s = _gen_click()
    ignite_s = _gen_swing()
    drink_s = _gen_drink()
    eat_s = _gen_step(0.6, 18.0, 0.0)
    fx_player = _player(null, 0.6, false)
    crackle = _player(_gen_crackle(), 0.35, false)
    fire_player = _player(_gen_crackle(), 0.001, true)

    if String(map["weather"]) == "rain":
        rain_player = _player(_gen_loop(3.0, 0.4), 0.001, true)
        thunder_player = _player(_gen_thunder(), 0.9, false)

    if bird_base > 0.0:
        birds_enabled = true
        bird_variants.append(_gen_bird(bird_base, 3))
        bird_variants.append(_gen_bird(bird_base * 1.25, 2))
        bird_variants.append(_gen_bird(bird_base * 0.85, 4))
        bird_player = _player(null, 0.22, false)
        cricket_player = _player(_gen_crickets(), 0.001, true)


func _process(delta: float) -> void:
    if birds_enabled and day_amt > 0.6:
        bird_timer -= delta
        if bird_timer <= 0.0:
            bird_timer = rng.randf_range(5.0, 14.0)
            bird_player.stream = bird_variants[rng.randi() % bird_variants.size()]
            bird_player.pitch_scale = rng.randf_range(0.9, 1.15)
            bird_player.play()


# ---------- public API ----------

func step(loudness: float) -> void:
    if step_pool.is_empty():
        return
    var p: AudioStreamPlayer = step_pool[step_idx]
    step_idx = (step_idx + 1) % step_pool.size()
    p.stream = step_variants[rng.randi() % step_variants.size()]
    p.pitch_scale = rng.randf_range(0.9, 1.12)
    p.volume_db = linear_to_db(maxf(0.02, 0.35 * loudness))
    p.play()


func set_rain(v: float) -> void:
    if rain_player != null:
        rain_player.volume_db = linear_to_db(maxf(0.001, v))


func thunder() -> void:
    if thunder_player != null:
        thunder_player.pitch_scale = rng.randf_range(0.85, 1.1)
        thunder_player.play()


func set_day(d: float) -> void:
    day_amt = d
    if cricket_player != null:
        cricket_player.volume_db = linear_to_db(maxf(0.001, (1.0 - d) * 0.10))


func drink() -> void:
    _play_fx(drink_s, 0.7, 1.0)


func eat() -> void:
    _play_fx(eat_s, 0.8, rng.randf_range(0.8, 1.0))


func set_fire(v: float) -> void:
    if fire_player != null:
        fire_player.volume_db = linear_to_db(maxf(0.001, v))


func pickup() -> void:
    _play_fx(click_s, 0.5, 1.5)


func ignite() -> void:
    _play_fx(ignite_s, 0.6, 0.7)


func land() -> void:
    _play_fx(thud_s, 0.8, 1.0)


func swing() -> void:
    _play_fx(swing_s, 0.7, rng.randf_range(0.9, 1.1))


func click() -> void:
    _play_fx(click_s, 0.4, 1.0)


func torch(on: bool) -> void:
    if on:
        _play_fx(ignite_s, 0.5, 0.6)
        crackle.play()
    else:
        crackle.stop()


func _play_fx(s: AudioStreamWAV, vol: float, pitch: float) -> void:
    fx_player.stream = s
    fx_player.volume_db = linear_to_db(vol)
    fx_player.pitch_scale = pitch
    fx_player.play()


func _player(s: AudioStream, vol: float, autoplay: bool) -> AudioStreamPlayer:
    var p := AudioStreamPlayer.new()
    p.stream = s
    p.volume_db = linear_to_db(maxf(0.001, vol))
    add_child(p)
    if autoplay and s != null:
        p.play()
    return p


# ---------- synthesis ----------

func _make_stream(x: PackedFloat32Array, peak: float, loop: bool) -> AudioStreamWAV:
    var m := 0.0001
    for i in x.size():
        m = maxf(m, absf(x[i]))
    var k := peak / m
    var data := PackedByteArray()
    data.resize(x.size() * 2)
    for i in x.size():
        var v := clampi(int(x[i] * k * 32767.0), -32768, 32767)
        data.encode_s16(i * 2, v)
    var w := AudioStreamWAV.new()
    w.format = AudioStreamWAV.FORMAT_16_BITS
    w.mix_rate = RATE
    w.stereo = false
    w.data = data
    if loop:
        w.loop_mode = AudioStreamWAV.LOOP_FORWARD
        w.loop_begin = 0
        w.loop_end = x.size()
    return w


# Smooth looping filtered noise (wind / rumble). a = filter amount (small = deeper).
func _gen_loop(seconds: float, a_base: float) -> AudioStreamWAV:
    var n := int(RATE * seconds)
    var f := int(RATE * 0.5)
    var x := PackedFloat32Array()
    x.resize(n + f)
    var y := 0.0
    var y2 := 0.0
    for i in n + f:
        var t := float(i) / float(RATE)
        var a := a_base * (0.65 + 0.35 * sin(TAU * t / 2.5)) * (0.85 + 0.15 * sin(TAU * t / 1.1 + 1.0))
        y += (rng.randf_range(-1.0, 1.0) - y) * a
        y2 += (y - y2) * a * 2.0
        x[i] = y2
    var r := PackedFloat32Array()
    r.resize(n)
    for i in n:
        if i < f:
            var w := float(i) / float(f)
            r[i] = x[i] * w + x[n + i] * (1.0 - w)
        else:
            r[i] = x[i]
    return _make_stream(r, 0.8, true)


func _gen_step(a: float, decay: float, thump: float) -> AudioStreamWAV:
    var n := int(RATE * 0.18)
    var x := PackedFloat32Array()
    x.resize(n)
    var y := 0.0
    for i in n:
        var t := float(i) / float(RATE)
        y += (rng.randf_range(-1.0, 1.0) - y) * a
        x[i] = y * exp(-t * decay) + sin(TAU * 85.0 * t) * thump * exp(-t * 30.0)
    return _make_stream(x, 0.8, false)


func _gen_swing() -> AudioStreamWAV:
    var dur := 0.45
    var n := int(RATE * dur)
    var x := PackedFloat32Array()
    x.resize(n)
    var prev := 0.0
    var y := 0.0
    for i in n:
        var t := float(i) / float(RATE)
        var nz := rng.randf_range(-1.0, 1.0)
        var hp := nz - prev * 0.6
        prev = nz
        y += (hp - y) * 0.45
        var u := t / dur
        x[i] = y * pow(sin(PI * u), 2.0) * (0.4 + 0.6 * u)
    return _make_stream(x, 0.8, false)


func _gen_thud() -> AudioStreamWAV:
    var n := int(RATE * 0.25)
    var x := PackedFloat32Array()
    x.resize(n)
    var y := 0.0
    for i in n:
        var t := float(i) / float(RATE)
        y += (rng.randf_range(-1.0, 1.0) - y) * 0.3
        x[i] = sin(TAU * 60.0 * t) * exp(-t * 14.0) + y * exp(-t * 40.0) * 0.3
    return _make_stream(x, 0.9, false)


func _gen_click() -> AudioStreamWAV:
    var n := int(RATE * 0.05)
    var x := PackedFloat32Array()
    x.resize(n)
    for i in n:
        var t := float(i) / float(RATE)
        x[i] = sin(TAU * 900.0 * t) * exp(-t * 60.0)
    return _make_stream(x, 0.6, false)


func _gen_crackle() -> AudioStreamWAV:
    var n := RATE * 3
    var x := PackedFloat32Array()
    x.resize(n)
    var p := 0.0
    var y := 0.0
    for i in n:
        if rng.randf() < 0.0012:
            p = rng.randf_range(0.3, 1.0)
        p *= 0.985
        y += (rng.randf_range(-1.0, 1.0) - y) * 0.1
        x[i] = rng.randf_range(-1.0, 1.0) * p * 0.8 + y * 0.12
    return _make_stream(x, 0.7, true)


func _gen_bird(base: float, count: int) -> AudioStreamWAV:
    var n := int(RATE * 0.9)
    var x := PackedFloat32Array()
    x.resize(n)
    for k in count:
        var start := int((0.05 + k * 0.17) * RATE)
        var dur := 0.11
        var f0 := base * rng.randf_range(0.9, 1.1)
        for i in int(dur * RATE):
            var idx := start + i
            if idx >= n:
                break
            var t := float(i) / float(RATE)
            var u := t / dur
            var f := f0 * (1.0 + 0.35 * u)
            x[idx] += sin(TAU * f * t) * sin(PI * u)
    return _make_stream(x, 0.8, false)


func _gen_thunder() -> AudioStreamWAV:
    var n := int(RATE * 3.0)
    var x := PackedFloat32Array()
    x.resize(n)
    var y := 0.0
    var y2 := 0.0
    for i in n:
        var t := float(i) / float(RATE)
        y += (rng.randf_range(-1.0, 1.0) - y) * 0.03
        y2 += (y - y2) * 0.06
        var e := (1.0 - exp(-t * 20.0)) * exp(-t * 1.1)
        x[i] = y2 * e * (1.0 + 0.5 * sin(t * 9.0))
    return _make_stream(x, 0.95, false)


func _gen_crickets() -> AudioStreamWAV:
    var n := RATE * 3
    var x := PackedFloat32Array()
    x.resize(n)
    for i in n:
        var t := float(i) / float(RATE)
        var u := fmod(t * 9.0, 1.0)
        var gate := 0.0
        if u < 0.45:
            gate = 1.0
        x[i] = sin(TAU * 4200.0 * t) * (0.5 + 0.5 * sin(TAU * 54.0 * t)) * gate
    return _make_stream(x, 0.6, true)


func _gen_drink() -> AudioStreamWAV:
    var n := int(RATE * 0.65)
    var x := PackedFloat32Array()
    x.resize(n)
    for k in 3:
        var start := int(k * 0.2 * RATE)
        var glug_n := int(0.14 * RATE)
        for i in glug_n:
            var idx := start + i
            if idx >= n:
                break
            var t := float(i) / float(RATE)
            var u := float(i) / float(glug_n)
            var f := 420.0 - 200.0 * u + 30.0 * k
            x[idx] += sin(TAU * f * t) * sin(PI * u) * 0.7
    return _make_stream(x, 0.7, false)
