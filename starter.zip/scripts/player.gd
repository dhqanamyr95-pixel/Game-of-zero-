extends CharacterBody3D

const HumanoidScript = preload("res://scripts/humanoid.gd")
const I18n = preload("res://scripts/i18n.gd")

enum Cam { FIRST, THIRD, TOP }

const WALK_SPEED := 3.0
const RUN_SPEED := 6.2
const CROUCH_SPEED := 1.6
const JUMP_VEL := 4.8
const GRAVITY := 14.0
const LOOK_SENS := 0.0045
const STAND_H := 1.8
const CROUCH_H := 1.15
const ATTACK_LEN := 0.6

var hud = null
var height_fn: Callable = Callable()
var input_enabled := true

var cam_mode: int = Cam.THIRD
var yaw := 0.0
var pitch := -0.2
var rig: Node3D
var arm: SpringArm3D
var camera: Camera3D
var model: Node3D
var capsule: CapsuleShape3D
var col: CollisionShape3D
var marker: MeshInstance3D

var crouching := false
var crouch_blend := 0.0
var aiming := false
var torch_on := false
var jump_queued := false
var attack_t := -1.0
var model_yaw := 0.0
var spawn_pos := Vector3.ZERO
var audio = null
var step_dist := 0.0
var was_on_floor := true
var bob_phase := 0.0
var land_dip := 0.0
var roll := 0.0
var cam_h := 0.0
var stamina := 1.0
var exhausted := false

var focus := Vector3.ZERO
var top_follow := true
var top_len := 26.0
var move_target := Vector3.ZERO
var has_target := false
var stuck_t := 0.0


func _ready() -> void:
    floor_snap_length = 0.5
    floor_max_angle = deg_to_rad(55.0)
    floor_stop_on_slope = true
    wall_min_slide_angle = deg_to_rad(15.0)
    spawn_pos = position

    capsule = CapsuleShape3D.new()
    capsule.radius = 0.32
    capsule.height = STAND_H
    col = CollisionShape3D.new()
    col.shape = capsule
    col.position.y = STAND_H * 0.5
    add_child(col)

    model = HumanoidScript.new()
    add_child(model)
    model.build()

    _build_camera()
    _build_marker()


func _build_camera() -> void:
    rig = Node3D.new()
    add_child(rig)
    rig.top_level = true
    arm = SpringArm3D.new()
    var sph := SphereShape3D.new()
    sph.radius = 0.25
    arm.shape = sph
    arm.spring_length = 3.6
    arm.margin = 0.1
    rig.add_child(arm)
    arm.add_excluded_object(get_rid())
    camera = Camera3D.new()
    camera.near = 0.05
    camera.far = 700.0
    camera.fov = 70.0
    arm.add_child(camera)
    rig.global_position = global_position + Vector3(0, 1.5, 0)


func _build_marker() -> void:
    marker = MeshInstance3D.new()
    var cm := CylinderMesh.new()
    cm.top_radius = 0.6
    cm.bottom_radius = 0.6
    cm.height = 0.04
    var mt := StandardMaterial3D.new()
    mt.albedo_color = Color(1.0, 0.8, 0.2, 0.55)
    mt.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    mt.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    cm.material = mt
    marker.mesh = cm
    marker.top_level = true
    marker.visible = false
    add_child(marker)


func attach_hud(h) -> void:
    hud = h
    hud.jump_pressed.connect(queue_jump)
    hud.crouch_pressed.connect(toggle_crouch)
    hud.attack_pressed.connect(start_attack)
    hud.aim_pressed.connect(toggle_aim)
    hud.camera_pressed.connect(cycle_camera)
    hud.recenter_pressed.connect(recenter)
    hud.map_tap.connect(on_map_tap)
    _apply_mode()


# ---------- actions ----------

func queue_jump() -> void:
    jump_queued = true


func toggle_crouch() -> void:
    if crouching and not _can_stand():
        return
    crouching = not crouching
    hud.crouching = crouching


func toggle_aim() -> void:
    aiming = not aiming
    hud.aiming = aiming


func toggle_torch() -> void:
    torch_on = not torch_on
    model.set_torch(torch_on)
    if audio != null:
        audio.torch(torch_on)


func start_attack() -> void:
    if attack_t < 0.0:
        attack_t = 0.0
        if audio != null:
            audio.swing()


func recenter() -> void:
    top_follow = true


func cycle_camera() -> void:
    cam_mode = (cam_mode + 1) % 3
    _apply_mode()
    if audio != null:
        audio.click()


func _apply_mode() -> void:
    hud.set_mode(cam_mode)
    hud.cam_name = I18n.t(["cam_first", "cam_third", "cam_strategy"][cam_mode])
    has_target = false
    marker.visible = false
    if cam_mode == Cam.TOP:
        focus = global_position
        top_follow = true


func _can_stand() -> bool:
    var q := PhysicsRayQueryParameters3D.create(global_position + Vector3(0, 0.9, 0), global_position + Vector3(0, STAND_H + 0.1, 0))
    q.exclude = [get_rid()]
    var hit := get_world_3d().direct_space_state.intersect_ray(q)
    return hit.is_empty()


func on_map_tap(pos: Vector2) -> void:
    if cam_mode != Cam.TOP or not input_enabled:
        return
    var from := camera.project_ray_origin(pos)
    var to := from + camera.project_ray_normal(pos) * 500.0
    var q := PhysicsRayQueryParameters3D.create(from, to)
    q.exclude = [get_rid()]
    var hit := get_world_3d().direct_space_state.intersect_ray(q)
    if hit.is_empty():
        return
    var collider = hit["collider"]
    if collider == null or not collider.is_in_group("ground"):
        return
    move_target = hit["position"]
    has_target = true
    stuck_t = 0.0
    marker.global_position = move_target + Vector3(0, 0.05, 0)
    marker.visible = true


# ---------- per-frame ----------

func _keyboard_vec() -> Vector2:
    var v := Vector2.ZERO
    if Input.is_physical_key_pressed(KEY_A):
        v.x -= 1.0
    if Input.is_physical_key_pressed(KEY_D):
        v.x += 1.0
    if Input.is_physical_key_pressed(KEY_W):
        v.y -= 1.0
    if Input.is_physical_key_pressed(KEY_S):
        v.y += 1.0
    return v


func _process(delta: float) -> void:
    if hud == null:
        return
    if input_enabled:
        _camera_input()
    else:
        hud.consume_look()
        hud.consume_pan()
        hud.consume_zoom()
    _update_rig(delta)
    model.visible = cam_mode != Cam.FIRST

    if attack_t >= 0.0:
        attack_t += delta
        if attack_t >= ATTACK_LEN:
            attack_t = -1.0
    crouch_blend = move_toward(crouch_blend, 1.0 if crouching else 0.0, delta * 6.0)
    capsule.height = lerpf(STAND_H, CROUCH_H, crouch_blend)
    col.position.y = capsule.height * 0.5

    var hspeed := Vector2(velocity.x, velocity.z).length()
    var prog := -1.0
    if attack_t >= 0.0:
        prog = attack_t / ATTACK_LEN
    model.animate(delta, hspeed / WALK_SPEED, is_on_floor(), crouch_blend, prog)


func _camera_input() -> void:
    if cam_mode == Cam.TOP:
        var pan: Vector2 = hud.consume_pan()
        var zoom: float = hud.consume_zoom()
        hud.consume_look()
        if pan.length() > 0.0:
            top_follow = false
            var k := top_len * 0.0016
            focus += Vector3(-pan.x * k, 0.0, -pan.y * k).rotated(Vector3.UP, yaw)
        top_len = clampf(top_len + zoom * 0.06, 8.0, 70.0)
    else:
        var look: Vector2 = hud.consume_look()
        hud.consume_pan()
        hud.consume_zoom()
        var sens := LOOK_SENS * (0.6 if aiming else 1.0)
        yaw -= look.x * sens
        var hi := 1.2 if cam_mode == Cam.FIRST else 0.6
        pitch = clampf(pitch - look.y * sens, -1.2, hi)


func _update_rig(delta: float) -> void:
    var cb := crouch_blend
    var target_len := 0.0
    var target_fov := 70.0
    var hoff := 0.0
    var rig_pos := global_position
    var blend := minf(1.0, delta * 8.0)
    match cam_mode:
        Cam.FIRST:
            target_len = 0.0
            target_fov = 48.0 if aiming else 75.0
            rig_pos += Vector3(0, lerpf(1.62, 1.15, cb), 0)
            rig.rotation = Vector3(pitch, yaw, roll)
            rig.global_position = rig_pos
        Cam.THIRD:
            target_len = 2.4 if aiming else 3.6
            target_fov = 55.0 if aiming else 68.0
            hoff = 0.55
            rig_pos += Vector3(0, lerpf(1.55, 1.10, cb), 0)
            rig.rotation = Vector3(pitch, yaw, roll)
            rig.global_position = rig_pos
        Cam.TOP:
            target_len = top_len
            target_fov = 50.0
            if top_follow:
                focus = focus.lerp(global_position, minf(1.0, delta * 6.0))
            if height_fn.is_valid():
                focus.y = height_fn.call(focus.x, focus.z)
            rig.rotation = Vector3(-1.05, yaw, 0)
            rig.global_position = focus
    var hs := Vector2(velocity.x, velocity.z).length()
    if hs > 5.0 and cam_mode != Cam.TOP:
        target_fov += 6.0
    var bob_amt := 0.0
    if cam_mode == Cam.FIRST:
        bob_amt = 1.0
    elif cam_mode == Cam.THIRD:
        bob_amt = 0.25
    var moving := clampf(hs / WALK_SPEED, 0.0, 1.8)
    if is_on_floor():
        bob_phase += delta * hs * 2.4
    land_dip = move_toward(land_dip, 0.0, delta * 0.5)
    var roll_target := 0.0
    if cam_mode != Cam.TOP and hud != null:
        roll_target = -hud.move.x * 0.03 * moving
    roll = lerpf(roll, roll_target, blend)
    cam_h = lerpf(cam_h, hoff, blend)
    arm.spring_length = lerpf(arm.spring_length, target_len, blend)
    camera.fov = lerpf(camera.fov, target_fov, blend)
    camera.h_offset = cam_h + sin(bob_phase) * 0.016 * moving * bob_amt
    camera.v_offset = sin(bob_phase * 2.0) * 0.026 * moving * bob_amt - land_dip


func _physics_process(delta: float) -> void:
    if hud == null:
        return

    var inp := Vector2.ZERO
    var want_sprint := false
    if input_enabled:
        inp = hud.move + _keyboard_vec()
        inp = inp.limit_length(1.0)
        want_sprint = hud.sprint and not exhausted

    var cur_speed := Vector2(velocity.x, velocity.z).length()
    if want_sprint and cur_speed > 3.5:
        stamina = maxf(0.0, stamina - delta * 0.16)
        if stamina <= 0.0:
            exhausted = true
    else:
        stamina = minf(1.0, stamina + delta * 0.10)
        if exhausted and stamina > 0.3:
            exhausted = false
    hud.stamina = stamina

    var dir := Vector3.ZERO
    var strength := 0.0
    if inp.length() > 0.05 and cam_mode != Cam.TOP:
        has_target = false
        marker.visible = false
        dir = Vector3(inp.x, 0.0, inp.y).rotated(Vector3.UP, yaw)
        strength = inp.length()
    elif has_target:
        var to := move_target - global_position
        to.y = 0.0
        if to.length() < 0.7:
            has_target = false
            marker.visible = false
        else:
            dir = to.normalized()
            strength = 1.0

    var speed := WALK_SPEED
    if crouching:
        speed = CROUCH_SPEED
    elif want_sprint and cam_mode != Cam.TOP:
        speed = RUN_SPEED
    elif has_target:
        speed = 4.4
    if aiming:
        speed *= 0.6
    speed *= strength

    var accel := 18.0 if is_on_floor() else 5.0
    var target_v := dir * speed
    velocity.x = move_toward(velocity.x, target_v.x, accel * delta)
    velocity.z = move_toward(velocity.z, target_v.z, accel * delta)

    if not is_on_floor():
        velocity.y -= GRAVITY * delta
    elif jump_queued and not crouching and input_enabled:
        velocity.y = JUMP_VEL
    jump_queued = false

    var vy_before := velocity.y
    move_and_slide()

    var hspeed := Vector2(velocity.x, velocity.z).length()
    _footsteps(delta, hspeed, vy_before)
    if cam_mode == Cam.FIRST or aiming:
        model_yaw = lerp_angle(model_yaw, yaw, minf(1.0, delta * 14.0))
    elif hspeed > 0.3:
        var ty := atan2(-velocity.x, -velocity.z)
        model_yaw = lerp_angle(model_yaw, ty, minf(1.0, delta * 10.0))
    model.rotation.y = model_yaw

    if has_target:
        if hspeed < 0.4:
            stuck_t += delta
            if stuck_t > 1.0:
                has_target = false
                marker.visible = false
        else:
            stuck_t = 0.0

    if global_position.y < -30.0:
        respawn()


func _footsteps(delta: float, hspeed: float, vy_before: float) -> void:
    var floor_now := is_on_floor()
    if floor_now and not was_on_floor and vy_before < -4.0:
        land_dip = clampf(absf(vy_before) * 0.018, 0.04, 0.16)
        if audio != null:
            audio.land()
    was_on_floor = floor_now
    if audio == null:
        return
    if floor_now and hspeed > 0.5:
        step_dist += hspeed * delta
        var stride := 1.8
        var loud := 0.75
        if crouching:
            stride = 1.5
            loud = 0.4
        elif hspeed > 4.5:
            stride = 2.4
            loud = 1.0
        if step_dist >= stride:
            step_dist = 0.0
            audio.step(loud)


func respawn() -> void:
    global_position = spawn_pos
    velocity = Vector3.ZERO
