extends Node

const MenuScript = preload("res://scripts/menu.gd")
const WorldScript = preload("res://scripts/world.gd")
const I18n = preload("res://scripts/i18n.gd")

var current: Node = null


func _ready() -> void:
    Engine.max_fps = 60
    I18n.load_settings()
    _setup_font()
    _show_menu()


# System font with automatic fallback, so Arabic, Persian, Hindi, Chinese,
# Japanese and Korean text can be shown without bundling big font files.
func _setup_font() -> void:
    var f := SystemFont.new()
    f.font_names = PackedStringArray(["sans-serif"])
    f.allow_system_fallback = true
    ThemeDB.fallback_font = f
    ThemeDB.get_default_theme().default_font = f


func _clear() -> void:
    if current != null:
        current.queue_free()
        current = null


func _show_menu() -> void:
    _clear()
    var menu = MenuScript.new()
    menu.map_chosen.connect(_start_world)
    current = menu
    add_child(menu)


func _start_world(map_id: String) -> void:
    _clear()
    var world = WorldScript.new()
    world.map_id = map_id
    world.exit_requested.connect(_show_menu)
    current = world
    add_child(world)
