extends Node

# Boot with a self-check: every script is loaded dynamically, so a broken
# script shows a readable message on screen instead of a plain gray screen.

const SCRIPTS := [
    "i18n", "save", "maps", "humanoid", "terrain", "hut", "audio", "hud", "lens",
    "weather", "daynight", "survival", "camp", "player", "menu", "world",
]

var I18n = null
var Save = null
var MenuScript = null
var WorldScript = null
var current: Node = null
var test_world = null


func _ready() -> void:
    Engine.max_fps = 60
    var failed: Array = []
    for n in SCRIPTS:
        var s = load("res://scripts/%s.gd" % n)
        if s == null or not s.can_instantiate():
            failed.append(str(n) + ".gd")
    if not failed.is_empty():
        print("BOOT ERROR: scripts failed to load: ", failed)
        _show_error(failed)
        return

    I18n = load("res://scripts/i18n.gd")
    Save = load("res://scripts/save.gd")
    MenuScript = load("res://scripts/menu.gd")
    WorldScript = load("res://scripts/world.gd")
    I18n.load_settings()
    _setup_font()

    var args := OS.get_cmdline_user_args()
    if args.has("--autotest"):
        _run_autotest(args)
    else:
        _show_menu()


func _show_error(failed: Array) -> void:
    var bg := ColorRect.new()
    bg.color = Color(0.10, 0.02, 0.02)
    add_child(bg)
    bg.set_anchors_preset(Control.PRESET_FULL_RECT)
    var text := "SCRIPT ERROR\n\nThese files failed to load:\n"
    for f in failed:
        text += "  " + str(f) + "\n"
    text += "\nTake a screenshot of this screen and send it."
    var label := Label.new()
    label.text = text
    label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    label.add_theme_font_size_override("font_size", 30)
    add_child(label)
    label.set_anchors_preset(Control.PRESET_FULL_RECT)


# System font with automatic fallback, so Arabic, Persian, Hindi, Chinese,
# Japanese and Korean text can be shown without bundling big font files.
func _setup_font() -> void:
    var f := SystemFont.new()
    f.font_names = PackedStringArray(["sans-serif"])
    f.allow_system_fallback = true
    ThemeDB.fallback_font = f
    ThemeDB.get_default_theme().default_font = f


func _clear() -> void:
    if current != null:
        current.queue_free()
        current = null


func _show_menu() -> void:
    _clear()
    var menu = MenuScript.new()
    menu.map_chosen.connect(_start_world)
    menu.continue_chosen.connect(_continue_game)
    current = menu
    add_child(menu)


func _continue_game() -> void:
    var d: Dictionary = Save.read()
    if d.has("map"):
        _start_world(String(d["map"]), d)


func _start_world(map_id: String, data: Dictionary = {}, skip_intro: bool = false) -> void:
    _clear()
    var world = WorldScript.new()
    world.map_id = map_id
    world.load_data = data
    world.skip_intro = skip_intro
    world.exit_requested.connect(_show_menu)
    current = world
    add_child(world)
    test_world = world


# ---------- automatic smoke test (used by the GitHub build, not by players) ----------

func _run_autotest(args: PackedStringArray) -> void:
    var map_id := "savanna"
    for a in args:
        if a.begins_with("--map="):
            map_id = a.substr(6)
    print("AUTOTEST start map=", map_id)
    _start_world(map_id, {}, true)
    get_tree().create_timer(2.0).timeout.connect(_autotest_step)
    get_tree().create_timer(5.0).timeout.connect(_autotest_step)
    get_tree().create_timer(9.0).timeout.connect(_finish_autotest)


func _autotest_step() -> void:
    if test_world != null:
        test_world.autotest_actions()


func _finish_autotest() -> void:
    print("AUTOTEST done")
    get_tree().quit()
