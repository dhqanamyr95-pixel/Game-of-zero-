extends Node

# Boot with a visible progress trace. Every start-up stage is written on the
# screen, so if the game ever stops, the last message tells us where.
# All scripts are loaded dynamically: a broken script shows a red error screen
# with its name instead of a plain gray screen.

const SCRIPTS := [
    "i18n", "save", "maps", "humanoid", "terrain", "hut", "audio", "hud", "lens",
    "weather", "daynight", "survival", "camp", "player", "menu", "world",
]

var I18n = null
var Save = null
var MenuScript = null
var WorldScript = null
var current: Node = null
var test_world = null
var status_layer: CanvasLayer = null
var status_label: Label = null


func _ready() -> void:
    Engine.max_fps = 60
    await _stage("SoulKeen\n\nStarting...")

    var failed: Array = []
    for n in SCRIPTS:
        var s = load("res://scripts/%s.gd" % n)
        if s == null or not s.can_instantiate():
            failed.append(str(n) + ".gd")
    if not failed.is_empty():
        print("BOOT ERROR: scripts failed to load: ", failed)
        _show_error(failed)
        return

    await _stage("SoulKeen\n\nScripts OK. Loading language...")
    I18n = load("res://scripts/i18n.gd")
    Save = load("res://scripts/save.gd")
    MenuScript = load("res://scripts/menu.gd")
    WorldScript = load("res://scripts/world.gd")
    I18n.load_settings()

    var args := OS.get_cmdline_user_args()
    if args.has("--autotest"):
        _run_autotest(args)
        return

    await _stage("SoulKeen\n\nLanguage: " + str(I18n.current) + "\nOpening menu...")
    _show_menu()
    await get_tree().create_timer(1.5).timeout
    if current is Control and current.size.x > 100.0:
        _hide_status()
    else:
        status_label.text += "\n\nMenu problem. size=" + str(current)
        print("BOOT: menu has no size")


func _stage(text: String) -> void:
    if status_layer == null:
        status_layer = CanvasLayer.new()
        status_layer.layer = 100
        add_child(status_layer)
        var bg := ColorRect.new()
        bg.color = Color(0.07, 0.06, 0.05)
        status_layer.add_child(bg)
        bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
        status_label = Label.new()
        status_label.add_theme_font_size_override("font_size", 34)
        status_label.add_theme_color_override("font_color", Color(0.95, 0.75, 0.35))
        status_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
        status_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
        status_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
        status_layer.add_child(status_label)
        status_label.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    status_label.text = text
    print("STAGE: ", text.replace("\n", " "))
    await get_tree().process_frame
    await get_tree().process_frame


func _hide_status() -> void:
    if status_layer != null:
        status_layer.queue_free()
        status_layer = null
        status_label = null


func _show_error(failed: Array) -> void:
    var text := "SCRIPT ERROR\n\nThese files failed to load:\n"
    for f in failed:
        text += "  " + str(f) + "\n"
    text += "\nTake a screenshot of this screen and send it."
    status_label.text = text
    status_label.add_theme_color_override("font_color", Color(1.0, 0.45, 0.4))


func _clear() -> void:
    if current != null:
        current.queue_free()
        current = null


func _show_menu() -> void:
    _clear()
    var menu = MenuScript.new()
    menu.map_chosen.connect(_start_world)
    menu.continue_chosen.connect(_continue_game)
    current = menu
    add_child(menu)


func _continue_game() -> void:
    var d: Dictionary = Save.read()
    if d.has("map"):
        _start_world(String(d["map"]), d)


func _start_world(map_id: String, data: Dictionary = {}, skip_intro: bool = false) -> void:
    _clear()
    _hide_status()
    var world = WorldScript.new()
    world.map_id = map_id
    world.load_data = data
    world.skip_intro = skip_intro
    world.exit_requested.connect(_show_menu)
    current = world
    add_child(world)
    test_world = world


# ---------- automatic smoke test (used by the GitHub build, not by players) ----------

func _run_autotest(args: PackedStringArray) -> void:
    var map_id := "savanna"
    for a in args:
        if a.begins_with("--map="):
            map_id = a.substr(6)
    print("AUTOTEST start map=", map_id)
    _start_world(map_id, {}, true)
    get_tree().create_timer(2.0).timeout.connect(_autotest_step)
    get_tree().create_timer(5.0).timeout.connect(_autotest_step)
    get_tree().create_timer(9.0).timeout.connect(_finish_autotest)


func _autotest_step() -> void:
    if test_world != null:
        test_world.autotest_actions()


func _finish_autotest() -> void:
    print("AUTOTEST done")
    get_tree().quit()
