extends RefCounted

# Player settings (saved in user://settings.cfg) and the graphics quality tiers.
#   level 0 = high, 1 = medium, 2 = low, 3 = very low
#   mode  "auto" starts from the saved level and lowers itself when the game is slow.

const PATH := "user://settings.cfg"

static var mode: String = "auto"
static var level: int = 1


static func load_all() -> void:
    var cfg := ConfigFile.new()
    if cfg.load(PATH) == OK:
        mode = String(cfg.get_value("graphics", "mode", "auto"))
        level = int(cfg.get_value("graphics", "level", 1))
    _sync_level()


static func _sync_level() -> void:
    if mode == "high":
        level = 0
    elif mode == "medium":
        level = 1
    elif mode == "low":
        level = 2
    level = clampi(level, 0, 3)


static func _save_value(section: String, key: String, value) -> void:
    var cfg := ConfigFile.new()
    cfg.load(PATH)
    cfg.set_value(section, key, value)
    cfg.save(PATH)


static func set_mode(m: String) -> void:
    mode = m
    if m == "auto" and level == 0:
        level = 1
    _sync_level()
    _save_value("graphics", "mode", mode)
    _save_value("graphics", "level", level)


# Called by the automatic quality control. Returns true when the level changed.
static func downgrade() -> bool:
    if level >= 3:
        return false
    level += 1
    _save_value("graphics", "level", level)
    return true


static func tutorial_done() -> bool:
    var cfg := ConfigFile.new()
    if cfg.load(PATH) == OK:
        return bool(cfg.get_value("game", "tutorial_done", false))
    return false


static func set_tutorial_done(v: bool) -> void:
    _save_value("game", "tutorial_done", v)


# ---------- what each quality level means ----------

# Height of the 3D render in "virtual pixels". 0 = full native resolution.
static func base_height() -> int:
    match level:
        0:
            return 0
        1:
            return 720
        2:
            return 540
    return 432


# Switch between the sharp menu mode and the faster in-game render resolution.
static func apply_window(win: Window, in_game: bool) -> void:
    var h := base_height()
    if (not in_game) or h == 0:
        win.content_scale_mode = Window.CONTENT_SCALE_MODE_CANVAS_ITEMS
        win.content_scale_size = Vector2i(1280, 720)
    else:
        win.content_scale_mode = Window.CONTENT_SCALE_MODE_VIEWPORT
        win.content_scale_size = Vector2i(int(round(float(h) * 16.0 / 9.0)), h)
    win.content_scale_aspect = Window.CONTENT_SCALE_ASPECT_EXPAND


# The buttons are designed for a 720 pixel high screen, so they are scaled to keep
# the same physical size when the game renders at a lower resolution.
static func ui_scale(in_game: bool) -> float:
    var h := base_height()
    if (not in_game) or h == 0:
        return 1.0
    return float(h) / 720.0


static func shadows() -> bool:
    return level <= 1


static func shadow_atlas() -> int:
    if level == 0:
        return 2048
    return 1024


static func terrain_segs() -> int:
    match level:
        0:
            return 160
        1:
            return 128
        2:
            return 96
    return 80


static func density() -> float:
    match level:
        0:
            return 1.0
        1:
            return 0.85
        2:
            return 0.6
    return 0.4


static func lens_effects() -> bool:
    return level <= 1


static func fancy_post() -> bool:
    return level <= 1


# Cheaper materials on weaker phones (same look, less work for the GPU).
static func tune(m: StandardMaterial3D) -> void:
    if level >= 2:
        m.shading_mode = BaseMaterial3D.SHADING_MODE_PER_VERTEX
        m.specular_mode = BaseMaterial3D.SPECULAR_DISABLED
        m.diffuse_mode = BaseMaterial3D.DIFFUSE_LAMBERT
    elif level == 1:
        m.specular_mode = BaseMaterial3D.SPECULAR_DISABLED
        m.diffuse_mode = BaseMaterial3D.DIFFUSE_LAMBERT
