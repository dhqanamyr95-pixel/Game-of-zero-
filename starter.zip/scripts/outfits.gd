extends RefCounted

# The wardrobe catalogue: 100 tops, 100 pants, 80 shoes, 100 hats and 100 masks,
# generated from shapes x colours. The 10 natural colours are free (they unlock
# one after another during the first 10 game days), the 10 vivid colours with
# gold trim are premium and cost gems.

const I18n = preload("res://scripts/i18n.gd")

const CATS := ["shirt", "pants", "shoes", "hat", "mask"]
const SHAPES := {
    "shirt": ["tunic", "vest", "longsleeve", "hooded", "cloak"],
    "pants": ["shorts", "loincloth", "trousers", "baggy", "leggings"],
    "shoes": ["sandals", "boots", "wraps", "highboots"],
    "hat": ["cap", "straw", "headband", "furhat", "helmet"],
    "mask": ["bone", "tribal", "wooden", "fox", "skull"],
}
const COLOR_IDS := [
    "brown", "tan", "gray", "olive", "sand", "charcoal", "moss", "clay", "bone", "slate",
    "crimson", "gold", "royalblue", "emerald", "purple", "pink", "turquoise", "orange", "white", "black",
]
const COLORS := [
    Color(0.45, 0.30, 0.18), Color(0.76, 0.62, 0.42), Color(0.50, 0.50, 0.52), Color(0.42, 0.45, 0.22),
    Color(0.82, 0.72, 0.50), Color(0.20, 0.20, 0.22), Color(0.28, 0.38, 0.20), Color(0.62, 0.36, 0.24),
    Color(0.90, 0.87, 0.78), Color(0.32, 0.40, 0.48),
    Color(0.78, 0.10, 0.15), Color(0.92, 0.72, 0.20), Color(0.15, 0.30, 0.80), Color(0.10, 0.62, 0.35),
    Color(0.50, 0.20, 0.70), Color(0.95, 0.50, 0.70), Color(0.10, 0.70, 0.72), Color(0.95, 0.50, 0.12),
    Color(0.97, 0.97, 0.97), Color(0.07, 0.07, 0.08),
]
const BASE_PRICE := {"shirt": 40, "pants": 30, "shoes": 25, "hat": 50, "mask": 80}
const SKINS := [
    Color(0.96, 0.80, 0.68), Color(0.87, 0.68, 0.52), Color(0.78, 0.57, 0.40),
    Color(0.66, 0.46, 0.30), Color(0.52, 0.35, 0.22), Color(0.38, 0.25, 0.16),
]
const HAIR_COLORS := [
    Color(0.06, 0.05, 0.05), Color(0.15, 0.09, 0.05), Color(0.30, 0.18, 0.09), Color(0.45, 0.20, 0.10),
    Color(0.78, 0.63, 0.28), Color(0.60, 0.60, 0.62), Color(0.90, 0.90, 0.90), Color(0.55, 0.12, 0.08),
]
const HAIR_STYLES := 6
const BEARD_STYLES := 4
const NOUN_FIRST_LANGS := ["es", "fr", "it", "pt", "id", "ar", "fa"]

static var _cache: Dictionary = {}


static func catalog(cat: String) -> Array:
    if _cache.has(cat):
        return _cache[cat]
    var out: Array = []
    var shapes: Array = SHAPES[cat]
    var free_i := 0
    for s in shapes.size():
        for c in COLOR_IDS.size():
            var premium := c >= 10
            var price := 0
            var day := 0
            if premium:
                price = int(BASE_PRICE[cat]) + (c - 10) * 6 + s * 8
            else:
                day = 1 + int(free_i / 5)
                free_i += 1
            out.append({
                "id": "%s_%d_%d" % [cat, s, c], "cat": cat, "shape": s, "color": c,
                "premium": premium, "price": price, "day": day,
            })
    _cache[cat] = out
    return out


static func find(id: String) -> Dictionary:
    var parts := id.split("_")
    if parts.size() != 3:
        return {}
    var cat: String = parts[0]
    if not SHAPES.has(cat):
        return {}
    var list: Array = catalog(cat)
    var idx: int = int(parts[1]) * COLOR_IDS.size() + int(parts[2])
    if idx < 0 or idx >= list.size():
        return {}
    return list[idx]


static func color_of(item: Dictionary) -> Color:
    return COLORS[int(item["color"])]


# Gold trim for premium pieces, nothing for free ones.
static func trim_of(item: Dictionary) -> Color:
    if bool(item["premium"]):
        var c: Color = COLORS[int(item["color"])]
        if c.get_luminance() > 0.7:
            return Color(0.55, 0.40, 0.10)
        return Color(0.95, 0.80, 0.30)
    return Color(0.0, 0.0, 0.0, 0.0)


static func item_name(item: Dictionary) -> String:
    var cat: String = String(item["cat"])
    var shapes: Array = SHAPES[cat]
    var shape_id: String = String(shapes[int(item["shape"])])
    var color_id: String = String(COLOR_IDS[int(item["color"])])
    var sw: String = I18n.t("shp_%s_%s" % [cat, shape_id])
    var cw: String = I18n.t("col_" + color_id)
    if NOUN_FIRST_LANGS.has(I18n.current):
        return sw + " " + cw
    return cw + " " + sw


# A random free piece (used to dress the bots).
static func random_free(rng: RandomNumberGenerator, cat: String) -> String:
    var list: Array = catalog(cat)
    for tries in 20:
        var it: Dictionary = list[rng.randi() % list.size()]
        if not bool(it["premium"]):
            return String(it["id"])
    return ""
