extends RefCounted

# Translations for 15 languages. Own tiny system (no import step needed).
# NOTE: translations are first drafts; have native speakers review before release.

const LANGS := [
    ["en", "English"],
    ["es", "Español"],
    ["fr", "Français"],
    ["de", "Deutsch"],
    ["it", "Italiano"],
    ["pt", "Português"],
    ["ru", "Русский"],
    ["tr", "Türkçe"],
    ["id", "Bahasa Indonesia"],
    ["zh", "中文"],
    ["ja", "日本語"],
    ["ko", "한국어"],
    ["hi", "हिन्दी"],
    ["ar", "العربية"],
    ["fa", "فارسی"],
]
const RTL_LANGS := ["ar", "fa"]

static var current: String = "en"
static var _tables: Dictionary = {}


static func _supported(code: String) -> bool:
    for l in LANGS:
        if l[0] == code:
            return true
    return false


static func load_settings() -> void:
    var cfg := ConfigFile.new()
    var code := ""
    if cfg.load("user://settings.cfg") == OK:
        code = String(cfg.get_value("game", "lang", ""))
    if code == "":
        code = OS.get_locale_language()
    if _supported(code):
        current = code
    else:
        current = "en"


static func set_lang(code: String) -> void:
    if not _supported(code):
        return
    current = code
    var cfg := ConfigFile.new()
    cfg.load("user://settings.cfg")
    cfg.set_value("game", "lang", code)
    cfg.save("user://settings.cfg")


static func is_rtl() -> bool:
    return RTL_LANGS.has(current)


static func native_name() -> String:
    for l in LANGS:
        if l[0] == current:
            return String(l[1])
    return "English"


static func t(key: String) -> String:
    if _tables.is_empty():
        _build()
    var tbl: Dictionary = _tables.get(current, {})
    if tbl.has(key):
        return String(tbl[key])
    var en: Dictionary = _tables["en"]
    return String(en.get(key, key))


static func _build() -> void:
    _tables = {
        "en": _en(), "es": _es(), "fr": _fr(), "de": _de(), "it": _it(),
        "pt": _pt(), "ru": _ru(), "tr": _tr(), "id": _id(), "zh": _zh(),
        "ja": _ja(), "ko": _ko(), "hi": _hi(), "ar": _ar(), "fa": _fa(),
    }


static func _en() -> Dictionary:
    return {
        "choose_world": "Choose your world",
        "language": "Language",
        "map_savanna": "Savanna - Year Zero",
        "map_savanna_d": "Warm plains, acacia trees, rocky outcrops. Where it all begins.",
        "map_forest": "Ancient Forest",
        "map_forest_d": "Dense woodland, thick fog, deep green valleys.",
        "map_iceage": "Ice Age",
        "map_iceage_d": "Frozen tundra, snow, pine trees and bitter wind.",
        "map_desert": "Burning Desert",
        "map_desert_d": "Endless dunes, scorching sun, almost no shelter.",
        "map_volcanic": "Volcanic Island",
        "map_volcanic_d": "Black rock, ash sky and glowing lava seas.",
        "cam_first": "FIRST PERSON",
        "cam_third": "THIRD PERSON",
        "cam_strategy": "STRATEGY VIEW",
        "hint_strategy": "Tap: walk    Drag: move map    Pinch: zoom",
        "act_drink": "Drink water",
        "act_eat": "Eat berries",
        "died": "You died",
        "continue": "Continue",
        "need_materials": "Need 3 wood and 2 stone",
        "fire_built": "Campfire built - you will respawn here",
        "cant_build": "Can't build here",
        "pickup_wood": "Pick up wood",
        "pickup_stone": "Pick up stone",
        "loot_bag": "Retrieve your items",
        "saved": "Saved",
    }


static func _es() -> Dictionary:
    return {
        "choose_world": "Elige tu mundo",
        "language": "Idioma",
        "map_savanna": "Sabana - Año Cero",
        "map_savanna_d": "Llanuras cálidas, acacias y rocas. Aquí empieza todo.",
        "map_forest": "Bosque ancestral",
        "map_forest_d": "Bosque denso, niebla espesa y valles verdes.",
        "map_iceage": "Edad de Hielo",
        "map_iceage_d": "Tundra helada, nieve, pinos y viento cortante.",
        "map_desert": "Desierto ardiente",
        "map_desert_d": "Dunas infinitas, sol abrasador y casi sin refugio.",
        "map_volcanic": "Isla volcánica",
        "map_volcanic_d": "Roca negra, cielo de ceniza y mares de lava.",
        "cam_first": "PRIMERA PERSONA",
        "cam_third": "TERCERA PERSONA",
        "cam_strategy": "VISTA ESTRATÉGICA",
        "hint_strategy": "Toca: caminar    Arrastra: mover mapa    Pellizca: zoom",
        "act_drink": "Beber agua",
        "act_eat": "Comer bayas",
        "died": "Has muerto",
        "continue": "Continuar",
        "need_materials": "Necesitas 3 madera y 2 piedras",
        "fire_built": "Fogata construida: reaparecerás aquí",
        "cant_build": "No puedes construir aquí",
        "pickup_wood": "Recoger madera",
        "pickup_stone": "Recoger piedra",
        "loot_bag": "Recuperar tus objetos",
        "saved": "Guardado",
    }


static func _fr() -> Dictionary:
    return {
        "choose_world": "Choisis ton monde",
        "language": "Langue",
        "map_savanna": "Savane - Année Zéro",
        "map_savanna_d": "Plaines chaudes, acacias et rochers. Tout commence ici.",
        "map_forest": "Forêt ancienne",
        "map_forest_d": "Forêt dense, brouillard épais et vallées verdoyantes.",
        "map_iceage": "Âge de glace",
        "map_iceage_d": "Toundra gelée, neige, pins et vent glacial.",
        "map_desert": "Désert brûlant",
        "map_desert_d": "Dunes sans fin, soleil de plomb et presque aucun abri.",
        "map_volcanic": "Île volcanique",
        "map_volcanic_d": "Roche noire, ciel de cendres et mers de lave.",
        "cam_first": "PREMIÈRE PERSONNE",
        "cam_third": "TROISIÈME PERSONNE",
        "cam_strategy": "VUE STRATÉGIQUE",
        "hint_strategy": "Toucher : marcher    Glisser : déplacer la carte    Pincer : zoom",
        "act_drink": "Boire de l'eau",
        "act_eat": "Manger des baies",
        "died": "Tu es mort",
        "continue": "Continuer",
        "need_materials": "Il faut 3 bois et 2 pierres",
        "fire_built": "Feu de camp construit : tu réapparaîtras ici",
        "cant_build": "Impossible de construire ici",
        "pickup_wood": "Ramasser du bois",
        "pickup_stone": "Ramasser une pierre",
        "loot_bag": "Récupérer tes objets",
        "saved": "Sauvegardé",
    }


static func _de() -> Dictionary:
    return {
        "choose_world": "Wähle deine Welt",
        "language": "Sprache",
        "map_savanna": "Savanne - Jahr Null",
        "map_savanna_d": "Warme Ebenen, Akazien und Felsen. Hier beginnt alles.",
        "map_forest": "Uralter Wald",
        "map_forest_d": "Dichter Wald, dicker Nebel und tiefgrüne Täler.",
        "map_iceage": "Eiszeit",
        "map_iceage_d": "Gefrorene Tundra, Schnee, Kiefern und bitterer Wind.",
        "map_desert": "Brennende Wüste",
        "map_desert_d": "Endlose Dünen, sengende Sonne und kaum Schutz.",
        "map_volcanic": "Vulkaninsel",
        "map_volcanic_d": "Schwarzer Fels, Aschehimmel und glühende Lavameere.",
        "cam_first": "ERSTE PERSON",
        "cam_third": "DRITTE PERSON",
        "cam_strategy": "STRATEGIEANSICHT",
        "hint_strategy": "Tippen: gehen    Ziehen: Karte bewegen    Zwei Finger: Zoom",
        "act_drink": "Wasser trinken",
        "act_eat": "Beeren essen",
        "died": "Du bist gestorben",
        "continue": "Weiter",
        "need_materials": "Benötigt 3 Holz und 2 Steine",
        "fire_built": "Lagerfeuer gebaut - hier wirst du wiedergeboren",
        "cant_build": "Hier kann man nicht bauen",
        "pickup_wood": "Holz aufheben",
        "pickup_stone": "Stein aufheben",
        "loot_bag": "Gegenstände holen",
        "saved": "Gespeichert",
    }


static func _it() -> Dictionary:
    return {
        "choose_world": "Scegli il tuo mondo",
        "language": "Lingua",
        "map_savanna": "Savana - Anno Zero",
        "map_savanna_d": "Pianure calde, acacie e rocce. Qui inizia tutto.",
        "map_forest": "Foresta antica",
        "map_forest_d": "Bosco fitto, nebbia densa e valli verdi.",
        "map_iceage": "Era glaciale",
        "map_iceage_d": "Tundra ghiacciata, neve, pini e vento gelido.",
        "map_desert": "Deserto ardente",
        "map_desert_d": "Dune infinite, sole cocente e quasi nessun riparo.",
        "map_volcanic": "Isola vulcanica",
        "map_volcanic_d": "Roccia nera, cielo di cenere e mari di lava.",
        "cam_first": "PRIMA PERSONA",
        "cam_third": "TERZA PERSONA",
        "cam_strategy": "VISTA STRATEGICA",
        "hint_strategy": "Tocca: cammina    Trascina: sposta mappa    Pizzica: zoom",
        "act_drink": "Bevi acqua",
        "act_eat": "Mangia bacche",
        "died": "Sei morto",
        "continue": "Continua",
        "need_materials": "Servono 3 legna e 2 pietre",
        "fire_built": "Falò costruito: rinascerai qui",
        "cant_build": "Non puoi costruire qui",
        "pickup_wood": "Raccogli legna",
        "pickup_stone": "Raccogli pietra",
        "loot_bag": "Recupera i tuoi oggetti",
        "saved": "Salvato",
    }


static func _pt() -> Dictionary:
    return {
        "choose_world": "Escolha seu mundo",
        "language": "Idioma",
        "map_savanna": "Savana - Ano Zero",
        "map_savanna_d": "Planícies quentes, acácias e rochas. Aqui tudo começa.",
        "map_forest": "Floresta antiga",
        "map_forest_d": "Mata densa, neblina espessa e vales verdes.",
        "map_iceage": "Era do Gelo",
        "map_iceage_d": "Tundra congelada, neve, pinheiros e vento gelado.",
        "map_desert": "Deserto ardente",
        "map_desert_d": "Dunas sem fim, sol escaldante e quase nenhum abrigo.",
        "map_volcanic": "Ilha vulcânica",
        "map_volcanic_d": "Rocha negra, céu de cinzas e mares de lava.",
        "cam_first": "PRIMEIRA PESSOA",
        "cam_third": "TERCEIRA PESSOA",
        "cam_strategy": "VISÃO ESTRATÉGICA",
        "hint_strategy": "Toque: andar    Arraste: mover mapa    Pinça: zoom",
        "act_drink": "Beber água",
        "act_eat": "Comer frutas silvestres",
        "died": "Você morreu",
        "continue": "Continuar",
        "need_materials": "Precisa de 3 madeiras e 2 pedras",
        "fire_built": "Fogueira construída - você renascerá aqui",
        "cant_build": "Não dá para construir aqui",
        "pickup_wood": "Pegar madeira",
        "pickup_stone": "Pegar pedra",
        "loot_bag": "Recuperar seus itens",
        "saved": "Salvo",
    }


static func _ru() -> Dictionary:
    return {
        "choose_world": "Выбери свой мир",
        "language": "Язык",
        "map_savanna": "Саванна - Нулевой год",
        "map_savanna_d": "Тёплые равнины, акации и скалы. Здесь всё начинается.",
        "map_forest": "Древний лес",
        "map_forest_d": "Густой лес, плотный туман и тёмно-зелёные долины.",
        "map_iceage": "Ледниковый период",
        "map_iceage_d": "Замёрзшая тундра, снег, сосны и ледяной ветер.",
        "map_desert": "Жаркая пустыня",
        "map_desert_d": "Бесконечные дюны, палящее солнце и почти нет укрытий.",
        "map_volcanic": "Вулканический остров",
        "map_volcanic_d": "Чёрные скалы, пепельное небо и моря лавы.",
        "cam_first": "ОТ ПЕРВОГО ЛИЦА",
        "cam_third": "ОТ ТРЕТЬЕГО ЛИЦА",
        "cam_strategy": "СТРАТЕГИЧЕСКИЙ ВИД",
        "hint_strategy": "Касание: идти    Перетаскивание: двигать карту    Щипок: масштаб",
        "act_drink": "Пить воду",
        "act_eat": "Есть ягоды",
        "died": "Ты погиб",
        "continue": "Продолжить",
        "need_materials": "Нужно 3 дерева и 2 камня",
        "fire_built": "Костёр построен - здесь ты возродишься",
        "cant_build": "Здесь нельзя строить",
        "pickup_wood": "Взять дерево",
        "pickup_stone": "Взять камень",
        "loot_bag": "Забрать вещи",
        "saved": "Сохранено",
    }


static func _tr() -> Dictionary:
    return {
        "choose_world": "Dünyanı seç",
        "language": "Dil",
        "map_savanna": "Savan - Sıfır Yılı",
        "map_savanna_d": "Sıcak ovalar, akasya ağaçları ve kayalıklar. Her şey burada başlar.",
        "map_forest": "Kadim Orman",
        "map_forest_d": "Sık orman, yoğun sis ve koyu yeşil vadiler.",
        "map_iceage": "Buz Çağı",
        "map_iceage_d": "Donmuş tundra, kar, çam ağaçları ve keskin rüzgâr.",
        "map_desert": "Yakıcı Çöl",
        "map_desert_d": "Sonsuz kum tepeleri, kavurucu güneş ve neredeyse hiç barınak yok.",
        "map_volcanic": "Yanardağ Adası",
        "map_volcanic_d": "Siyah kayalar, kül dolu gökyüzü ve parlayan lav denizleri.",
        "cam_first": "BİRİNCİ ŞAHIS",
        "cam_third": "ÜÇÜNCÜ ŞAHIS",
        "cam_strategy": "STRATEJİ GÖRÜNÜMÜ",
        "hint_strategy": "Dokun: yürü    Sürükle: haritayı kaydır    Kıstır: yakınlaştır",
        "act_drink": "Su iç",
        "act_eat": "Meyve ye",
        "died": "Öldün",
        "continue": "Devam et",
        "need_materials": "3 odun ve 2 taş gerekli",
        "fire_built": "Kamp ateşi kuruldu - burada yeniden doğacaksın",
        "cant_build": "Burada inşa edilemez",
        "pickup_wood": "Odun al",
        "pickup_stone": "Taş al",
        "loot_bag": "Eşyalarını al",
        "saved": "Kaydedildi",
    }


static func _id() -> Dictionary:
    return {
        "choose_world": "Pilih duniamu",
        "language": "Bahasa",
        "map_savanna": "Sabana - Tahun Nol",
        "map_savanna_d": "Dataran hangat, pohon akasia, dan bebatuan. Di sinilah semuanya dimulai.",
        "map_forest": "Hutan Purba",
        "map_forest_d": "Hutan lebat, kabut tebal, dan lembah hijau yang dalam.",
        "map_iceage": "Zaman Es",
        "map_iceage_d": "Tundra beku, salju, pohon pinus, dan angin yang menusuk.",
        "map_desert": "Gurun Membara",
        "map_desert_d": "Bukit pasir tak berujung, matahari menyengat, hampir tanpa tempat berteduh.",
        "map_volcanic": "Pulau Vulkanik",
        "map_volcanic_d": "Batu hitam, langit abu, dan lautan lava yang menyala.",
        "cam_first": "ORANG PERTAMA",
        "cam_third": "ORANG KETIGA",
        "cam_strategy": "TAMPILAN STRATEGI",
        "hint_strategy": "Ketuk: jalan    Seret: geser peta    Cubit: zoom",
        "act_drink": "Minum air",
        "act_eat": "Makan beri",
        "died": "Kamu mati",
        "continue": "Lanjutkan",
        "need_materials": "Butuh 3 kayu dan 2 batu",
        "fire_built": "Api unggun dibuat - kamu akan bangkit di sini",
        "cant_build": "Tidak bisa membangun di sini",
        "pickup_wood": "Ambil kayu",
        "pickup_stone": "Ambil batu",
        "loot_bag": "Ambil barangmu",
        "saved": "Tersimpan",
    }


static func _zh() -> Dictionary:
    return {
        "choose_world": "选择你的世界",
        "language": "语言",
        "map_savanna": "稀树草原 - 元年",
        "map_savanna_d": "温暖的平原、金合欢树和岩石。一切从这里开始。",
        "map_forest": "古老森林",
        "map_forest_d": "茂密的树林、浓雾和深绿色的山谷。",
        "map_iceage": "冰河时代",
        "map_iceage_d": "冰冻的苔原、积雪、松树和刺骨的寒风。",
        "map_desert": "炎热沙漠",
        "map_desert_d": "无尽的沙丘，灼热的太阳，几乎没有遮蔽。",
        "map_volcanic": "火山岛",
        "map_volcanic_d": "黑色岩石、灰烬天空和炽热的岩浆海。",
        "cam_first": "第一人称",
        "cam_third": "第三人称",
        "cam_strategy": "战略视角",
        "hint_strategy": "点击：行走    拖动：移动地图    双指：缩放",
        "act_drink": "喝水",
        "act_eat": "吃浆果",
        "died": "你死了",
        "continue": "继续",
        "need_materials": "需要3根木头和2块石头",
        "fire_built": "营火已建好，你将在此重生",
        "cant_build": "这里不能建造",
        "pickup_wood": "捡木头",
        "pickup_stone": "捡石头",
        "loot_bag": "取回物品",
        "saved": "已保存",
    }


static func _ja() -> Dictionary:
    return {
        "choose_world": "世界を選ぼう",
        "language": "言語",
        "map_savanna": "サバンナ - 元年",
        "map_savanna_d": "暖かい平原、アカシアの木、岩場。すべてはここから始まる。",
        "map_forest": "太古の森",
        "map_forest_d": "深い森、濃い霧、緑の谷。",
        "map_iceage": "氷河期",
        "map_iceage_d": "凍てつくツンドラ、雪、松の木、厳しい風。",
        "map_desert": "灼熱の砂漠",
        "map_desert_d": "果てしない砂丘、焼けつく太陽、身を隠す場所はほとんどない。",
        "map_volcanic": "火山島",
        "map_volcanic_d": "黒い岩、灰色の空、輝く溶岩の海。",
        "cam_first": "一人称",
        "cam_third": "三人称",
        "cam_strategy": "戦略ビュー",
        "hint_strategy": "タップ：移動    ドラッグ：マップ移動    ピンチ：ズーム",
        "act_drink": "水を飲む",
        "act_eat": "ベリーを食べる",
        "died": "あなたは死んだ",
        "continue": "続ける",
        "need_materials": "木材3個と石2個が必要",
        "fire_built": "焚き火を作った。ここで復活します",
        "cant_build": "ここには建てられない",
        "pickup_wood": "木を拾う",
        "pickup_stone": "石を拾う",
        "loot_bag": "持ち物を回収",
        "saved": "保存しました",
    }


static func _ko() -> Dictionary:
    return {
        "choose_world": "세계를 선택하세요",
        "language": "언어",
        "map_savanna": "사바나 - 원년",
        "map_savanna_d": "따뜻한 평원, 아카시아 나무, 바위 지대. 모든 것이 여기서 시작됩니다.",
        "map_forest": "고대의 숲",
        "map_forest_d": "울창한 숲, 짙은 안개, 깊고 푸른 계곡.",
        "map_iceage": "빙하기",
        "map_iceage_d": "얼어붙은 툰드라, 눈, 소나무, 매서운 바람.",
        "map_desert": "불타는 사막",
        "map_desert_d": "끝없는 모래언덕, 작열하는 태양, 거의 없는 쉼터.",
        "map_volcanic": "화산섬",
        "map_volcanic_d": "검은 바위, 재로 뒤덮인 하늘, 이글거리는 용암 바다.",
        "cam_first": "1인칭",
        "cam_third": "3인칭",
        "cam_strategy": "전략 시점",
        "hint_strategy": "탭: 이동    드래그: 지도 이동    핀치: 확대/축소",
        "act_drink": "물 마시기",
        "act_eat": "열매 먹기",
        "died": "당신은 죽었습니다",
        "continue": "계속하기",
        "need_materials": "나무 3개와 돌 2개가 필요합니다",
        "fire_built": "모닥불을 만들었습니다. 여기서 부활합니다",
        "cant_build": "여기에는 지을 수 없습니다",
        "pickup_wood": "나무 줍기",
        "pickup_stone": "돌 줍기",
        "loot_bag": "물건 되찾기",
        "saved": "저장됨",
    }


static func _hi() -> Dictionary:
    return {
        "choose_world": "अपनी दुनिया चुनें",
        "language": "भाषा",
        "map_savanna": "सवाना - वर्ष शून्य",
        "map_savanna_d": "गर्म मैदान, बबूल के पेड़ और चट्टानें। यहीं से सब कुछ शुरू होता है।",
        "map_forest": "प्राचीन जंगल",
        "map_forest_d": "घना जंगल, गहरा कोहरा और हरी घाटियाँ।",
        "map_iceage": "हिमयुग",
        "map_iceage_d": "जमा हुआ टुंड्रा, बर्फ़, चीड़ के पेड़ और कड़कती हवा।",
        "map_desert": "तपता रेगिस्तान",
        "map_desert_d": "अंतहीन रेत के टीले, झुलसाती धूप और लगभग कोई आश्रय नहीं।",
        "map_volcanic": "ज्वालामुखी द्वीप",
        "map_volcanic_d": "काली चट्टानें, राख भरा आसमान और दहकते लावा के समुद्र।",
        "cam_first": "प्रथम व्यक्ति",
        "cam_third": "तृतीय व्यक्ति",
        "cam_strategy": "रणनीति दृश्य",
        "hint_strategy": "टैप: चलें    ड्रैग: नक्शा हिलाएँ    पिंच: ज़ूम",
        "act_drink": "पानी पिएँ",
        "act_eat": "बेरी खाएँ",
        "died": "आप मर गए",
        "continue": "जारी रखें",
        "need_materials": "3 लकड़ी और 2 पत्थर चाहिए",
        "fire_built": "अलाव बनाया, आप यहीं दोबारा जन्म लेंगे",
        "cant_build": "यहाँ निर्माण नहीं हो सकता",
        "pickup_wood": "लकड़ी उठाएँ",
        "pickup_stone": "पत्थर उठाएँ",
        "loot_bag": "अपना सामान वापस लें",
        "saved": "सहेजा गया",
    }


static func _ar() -> Dictionary:
    return {
        "choose_world": "اختر عالمك",
        "language": "اللغة",
        "map_savanna": "السافانا - السنة صفر",
        "map_savanna_d": "سهول دافئة وأشجار السنط وصخور بارزة. من هنا تبدأ كل القصة.",
        "map_forest": "الغابة القديمة",
        "map_forest_d": "غابة كثيفة وضباب كثيف ووديان خضراء عميقة.",
        "map_iceage": "العصر الجليدي",
        "map_iceage_d": "تندرا متجمدة وثلج وأشجار الصنوبر ورياح قارسة.",
        "map_desert": "الصحراء الملتهبة",
        "map_desert_d": "كثبان لا نهاية لها وشمس حارقة وبالكاد يوجد مأوى.",
        "map_volcanic": "الجزيرة البركانية",
        "map_volcanic_d": "صخور سوداء وسماء من الرماد وبحار من الحمم المتوهجة.",
        "cam_first": "منظور الشخص الأول",
        "cam_third": "منظور الشخص الثالث",
        "cam_strategy": "عرض الاستراتيجية",
        "hint_strategy": "اللمس: المشي    السحب: تحريك الخريطة    القرص: تكبير",
        "act_drink": "اشرب الماء",
        "act_eat": "كُل التوت",
        "died": "لقد متّ",
        "continue": "متابعة",
        "need_materials": "تحتاج 3 أخشاب وحجرين",
        "fire_built": "تم بناء نار المخيم، ستعود للحياة هنا",
        "cant_build": "لا يمكن البناء هنا",
        "pickup_wood": "التقط الخشب",
        "pickup_stone": "التقط الحجر",
        "loot_bag": "استعد أغراضك",
        "saved": "تم الحفظ",
    }


static func _fa() -> Dictionary:
    return {
        "choose_world": "جهان خود را انتخاب کن",
        "language": "زبان",
        "map_savanna": "ساوانا - سال صفر",
        "map_savanna_d": "دشت‌های گرم، درختان اقاقیا و صخره‌ها. جایی که همه‌چیز آغاز می‌شود.",
        "map_forest": "جنگل باستانی",
        "map_forest_d": "جنگل انبوه، مه غلیظ و دره‌های سرسبز.",
        "map_iceage": "عصر یخبندان",
        "map_iceage_d": "دشت یخ‌زده، برف، درختان کاج و باد سرد.",
        "map_desert": "بیابان سوزان",
        "map_desert_d": "تپه‌های بی‌پایان، آفتاب سوزان و تقریباً بدون پناهگاه.",
        "map_volcanic": "جزیره‌ی آتشفشانی",
        "map_volcanic_d": "سنگ سیاه، آسمان خاکستری و دریای گدازه‌ی درخشان.",
        "cam_first": "اول‌شخص",
        "cam_third": "سوم‌شخص",
        "cam_strategy": "نمای استراتژی",
        "hint_strategy": "لمس: راه رفتن    کشیدن: جابه‌جایی نقشه    دو انگشت: زوم",
        "act_drink": "نوشیدن آب",
        "act_eat": "خوردن توت",
        "died": "مُردی",
        "continue": "ادامه",
        "need_materials": "۳ چوب و ۲ سنگ لازم است",
        "fire_built": "آتش اردو ساخته شد، اینجا دوباره متولد می‌شوی",
        "cant_build": "اینجا نمی‌شود ساخت",
        "pickup_wood": "برداشتن چوب",
        "pickup_stone": "برداشتن سنگ",
        "loot_bag": "برداشتن وسایلت",
        "saved": "ذخیره شد",
    }
