extends Node

# Seven seasons, 35 real minutes each (a full cycle is about 4 hours):
#   blossom (pink), spring, summer, autumn, winter, storm, fog.
# A season changes the ground colour, the tree leaves, the weather and the light.

const I18n = preload("res://scripts/i18n.gd")

const SEASON_LEN := 2100.0

const SEASONS := [
    {"id": "blossom", "weather": "petals", "canopy": Color(0.98, 0.66, 0.78), "leafless": false, "leaf_mix": 0.75,
        "tint": Color(1.06, 0.96, 1.0), "mix_col": Color(0.96, 0.74, 0.82), "mix": 0.20, "sun": 1.0, "fog": 1.0},
    {"id": "spring", "weather": "clear", "canopy": Color(0.42, 0.78, 0.26), "leafless": false, "leaf_mix": 0.45,
        "tint": Color(0.92, 1.12, 0.90), "mix_col": Color(0.55, 0.85, 0.40), "mix": 0.15, "sun": 1.0, "fog": 1.0},
    {"id": "summer", "weather": "clear", "canopy": Color(0.20, 0.50, 0.13), "leafless": false, "leaf_mix": 0.25,
        "tint": Color(1.12, 1.04, 0.82), "mix_col": Color(0.85, 0.75, 0.35), "mix": 0.12, "sun": 1.2, "fog": 0.8},
    {"id": "autumn", "weather": "leaves", "canopy": Color(0.88, 0.46, 0.12), "leafless": false, "leaf_mix": 0.85,
        "tint": Color(1.15, 0.88, 0.68), "mix_col": Color(0.62, 0.36, 0.16), "mix": 0.28, "sun": 0.95, "fog": 1.2},
    {"id": "winter", "weather": "snow", "canopy": Color(0.85, 0.9, 0.95), "leafless": true, "leaf_mix": 0.9,
        "tint": Color(1.0, 1.0, 1.0), "mix_col": Color(0.95, 0.97, 1.0), "mix": 0.85, "sun": 0.8, "fog": 1.3},
    {"id": "storm", "weather": "storm", "canopy": Color(0.18, 0.38, 0.14), "leafless": false, "leaf_mix": 0.35,
        "tint": Color(0.82, 0.88, 0.84), "mix_col": Color(0.3, 0.38, 0.32), "mix": 0.15, "sun": 0.9, "fog": 1.0},
    {"id": "fog", "weather": "fog", "canopy": Color(0.30, 0.50, 0.28), "leafless": false, "leaf_mix": 0.3,
        "tint": Color(0.92, 0.96, 0.96), "mix_col": Color(0.7, 0.78, 0.78), "mix": 0.12, "sun": 0.9, "fog": 1.0},
]

var idx := 0
var t := 0.0
var world = null
var terrain = null
var weather = null
var daynight = null
var hud = null


func setup(w, tr, we, dn) -> void:
    world = w
    terrain = tr
    weather = we
    daynight = dn
    apply()


func force(i: int) -> void:
    idx = i % SEASONS.size()
    t = 0.0
    apply()


func apply() -> void:
    var s: Dictionary = SEASONS[idx]
    weather.set_kind(String(s["weather"]))
    terrain.recolor(s["tint"], s["mix_col"], float(s["mix"]))
    terrain.set_foliage(s["canopy"], float(s["leaf_mix"]))
    daynight.sun_mul = float(s["sun"])
    daynight.season_fog = float(s["fog"])


func _process(delta: float) -> void:
    t += delta
    if t >= SEASON_LEN:
        t = 0.0
        idx = (idx + 1) % SEASONS.size()
        apply()
    if hud != null:
        hud.season_text = I18n.t("season_" + String(SEASONS[idx]["id"]))


func to_dict() -> Dictionary:
    return {"idx": idx, "t": t}


func from_dict(d: Dictionary) -> void:
    idx = int(d.get("idx", 0)) % SEASONS.size()
    t = float(d.get("t", 0.0))
    apply()
