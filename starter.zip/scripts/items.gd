extends RefCounted

# Item data. Recipes unlock on a given game day (one day = 10 real minutes):
#   day 1: campfire, stone axe     day 2: pickaxe, sword     day 10: bow and arrows

const RECIPES := [
    {"id": "campfire", "day": 1, "cost": {"wood": 3, "stone": 2}},
    {"id": "axe", "day": 1, "cost": {"wood": 3, "stone": 2}},
    {"id": "pickaxe", "day": 2, "cost": {"wood": 3, "stone": 3}},
    {"id": "sword", "day": 2, "cost": {"wood": 2, "stone": 3}},
    {"id": "bow", "day": 10, "cost": {"wood": 4, "fiber": 4}},
    {"id": "arrow", "day": 10, "cost": {"wood": 1, "stone": 1}},
]

const TOOL_IDS := ["axe", "pickaxe", "sword", "bow"]
const MATERIAL_IDS := ["wood", "stone", "fiber", "sapling", "arrow"]


static func recipe(id: String) -> Dictionary:
    for r in RECIPES:
        if r["id"] == id:
            return r
    return {}
