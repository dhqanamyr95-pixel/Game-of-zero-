extends RefCounted

# What the player owns and wears. Saved in user://profile.cfg (separate from the
# game save, so gems and clothes survive when a new game is started).

const Outfits = preload("res://scripts/outfits.gd")

const PATH := "user://profile.cfg"

static var gems: int = 0
static var owned: Dictionary = {}
static var equipped: Dictionary = {"shirt": "shirt_0_0", "pants": "pants_1_0", "shoes": "", "hat": "", "mask": ""}
static var look: Dictionary = {"skin": 1, "hair": 3, "hair_color": 2, "beard": 2}


static func load_all() -> void:
    var cfg := ConfigFile.new()
    if cfg.load(PATH) != OK:
        return
    gems = int(cfg.get_value("wallet", "gems", 0))
    owned = {}
    var list: Array = cfg.get_value("wallet", "owned", [])
    for id in list:
        owned[String(id)] = true
    for cat in Outfits.CATS:
        equipped[cat] = String(cfg.get_value("equipped", cat, equipped[cat]))
    for k in ["skin", "hair", "hair_color", "beard"]:
        look[k] = int(cfg.get_value("look", k, look[k]))


static func save_all() -> void:
    var cfg := ConfigFile.new()
    cfg.set_value("wallet", "gems", gems)
    cfg.set_value("wallet", "owned", owned.keys())
    for cat in Outfits.CATS:
        cfg.set_value("equipped", cat, equipped[cat])
    for k in look.keys():
        cfg.set_value("look", k, look[k])
    cfg.save(PATH)


static func is_owned(item: Dictionary, day: int) -> bool:
    if bool(item["premium"]):
        return owned.has(String(item["id"]))
    return day >= int(item["day"])


# Returns "ok", "already" or "no_gems".
static func buy(item: Dictionary) -> String:
    var id: String = String(item["id"])
    if owned.has(id):
        return "already"
    var price: int = int(item["price"])
    if gems < price:
        return "no_gems"
    gems -= price
    owned[id] = true
    save_all()
    return "ok"


static func get_look() -> Dictionary:
    return look


static func get_equipped() -> Dictionary:
    return equipped
